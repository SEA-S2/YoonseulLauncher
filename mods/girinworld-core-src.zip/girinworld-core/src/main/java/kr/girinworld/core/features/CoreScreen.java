package kr.girinworld.core.features;

import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public abstract class CoreScreen extends Screen {
   protected CoreScreen(Component title) {
      super(title);
   }

   public boolean mouseReleased(MouseButtonEvent event) {
      boolean handled = super.mouseReleased(event);
      if (!(this.getFocused() instanceof EditBox)) {
         this.setFocused(null);
      }

      return handled;
   }

   @Override
   public void removed() {
      kr.girinworld.core.ClientCompat.coreScreenRemoved(this);
      super.removed();
   }
}
