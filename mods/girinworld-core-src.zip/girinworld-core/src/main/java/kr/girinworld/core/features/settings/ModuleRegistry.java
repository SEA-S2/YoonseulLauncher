package kr.girinworld.core.features.settings;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;
import kr.girinworld.core.Config;
import kr.girinworld.core.features.calc.CalcScreen;
import kr.girinworld.core.features.camera.PhotoModeController;
import kr.girinworld.core.features.control.ToggleSprintController;
import kr.girinworld.core.features.hud.HudLayoutScreen;
import kr.girinworld.core.features.hud.HudUtil;
import kr.girinworld.core.features.hud.InfoElement;
import kr.girinworld.core.features.hud.InfoHud;
import kr.girinworld.core.features.timer.TimerScreen;
import kr.girinworld.core.features.visual.BrightnessController;
import kr.girinworld.core.features.visual.CustomTimeController;
import kr.girinworld.core.features.visual.FontScaleController;
import kr.girinworld.core.features.whisper.WhisperScreen;
import kr.girinworld.core.features.world.BeamFilterScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

final class ModuleRegistry {
   private static final String[] DIRECTION = new String[]{"세로", "가로"};
   private static final String[] SPEED_UNITS = new String[]{"블록/초", "km/h"};
   private static final String[] HELD_PRESETS = new String[]{"자유 배치", "조준선 아래", "핫바 위"};
   private static final String[] TIME_FORMATS = new String[]{"14:59", "14:59:30", "오후 2:59"};
   private static final String[] TIME_MODES = new String[]{"고정 시각", "실시간 연동"};
   private static final String[] BEAM_STYLES = new String[]{"신호기 빔", "파티클"};
   private static final String[] HEALTH_TARGETS = new String[]{"몹", "플레이어", "둘 다"};
   private static final String[] BEAM_COLOR_MODES = new String[]{"아이템 등급 자동", "지정 색"};
   private static final String[] BEAM_FILTERS = new String[]{"전체", "화이트리스트", "블랙리스트"};

   private static Opt factor(String label, DoubleSupplier get, DoubleConsumer set) {
      return Opt.slider(label, 0.3, 2.0, 0.05, get, set, () -> Math.round(get.getAsDouble() * 100.0) + "%");
   }

   private ModuleRegistry() {
   }

   static List<ClientModule> all() {
      List<ClientModule> out = new ArrayList<>();
      out.add(
         new ClientModule("calc", "계산기", "사칙연산·괄호·K/M/B 단위 계산", "도구")
            .key(c -> c.keys.calc)
            .quick(c -> c.modules.quickCalc, (c, v) -> c.modules.quickCalc = v)
            .opts(
               () -> List.of(
                  Opt.toggle("천 단위 쉼표", () -> Config.get().calc.thousandsSeparator, v -> Config.get().calc.thousandsSeparator = v),
                  Opt.toggle("K/M/B 단위 표기", () -> Config.get().calc.kmbNotation, v -> Config.get().calc.kmbNotation = v)
               )
            )
            .action(() -> "계산기 열기", () -> open(new CalcScreen(kr.girinworld.core.ClientCompat.screen(Minecraft.getInstance()))))
      );
      out.add(
         new ClientModule("timer", "타이머", "카운트다운·스톱워치 + 화면 HUD", "도구")
            .key(c -> c.keys.timer)
            .quick(c -> c.modules.quickTimer, (c, v) -> c.modules.quickTimer = v)
            .opts(
               () -> List.of(
                  Opt.toggle("HUD 표시", () -> Config.get().timer.hudEnabled, v -> Config.get().timer.hudEnabled = v),
                  Opt.slider(
                     "투명도",
                     0.1,
                     1.0,
                     0.0,
                     () -> Config.get().timer.hudOpacity,
                     v -> Config.get().timer.hudOpacity = HudUtil.clampOpacity(v),
                     () -> Math.round(Config.get().timer.hudOpacity * 100.0) + "%"
                  ),
                  Opt.toggle("알림음", () -> Config.get().timer.sound, v -> Config.get().timer.sound = v),
                  Opt.slider(
                     "알림 시간",
                     1.0,
                     60.0,
                     1.0,
                     () -> Config.get().timer.alarmSeconds,
                     v -> Config.get().timer.alarmSeconds = (int)Math.round(v),
                     () -> Config.get().timer.alarmSeconds + "초"
                  ),
                  Opt.percent("알림 크기", () -> Config.get().timer.alarmVolume, v -> Config.get().timer.alarmVolume = v),
                  Opt.action("위치·크기 조절", ModuleRegistry::openHudLayout)
               )
            )
            .action(() -> "타이머 열기", () -> open(new TimerScreen(kr.girinworld.core.ClientCompat.screen(Minecraft.getInstance()))))
      );
      out.add(
         new ClientModule("whisper", "귓속말", "whisper 플러그인을 쓰는 서버에서 귓속말을 별도 창으로 모아보기", "채팅")
            .key(c -> c.keys.whisper)
            .quick(c -> c.modules.quickWhisper, (c, v) -> c.modules.quickWhisper = v)
            .action(() -> "귓속말 열기", () -> open(new WhisperScreen(kr.girinworld.core.ClientCompat.screen(Minecraft.getInstance()))))
      );
      out.add(
         new ClientModule("chat", "사용자 지정 채팅창", "채팅창 폭·높이·글자 크기와 타임스탬프 (표시만 바꿉니다)", "채팅")
            .toggle(c -> c.chat.enabled, (c, v) -> c.chat.enabled = v)
            .opts(
               () -> List.of(
                  factor("폭", () -> Config.get().chat.width, v -> Config.get().chat.width = v),
                  factor("높이 (열림)", () -> Config.get().chat.heightFocused, v -> Config.get().chat.heightFocused = v),
                  factor("높이 (닫힘)", () -> Config.get().chat.heightUnfocused, v -> Config.get().chat.heightUnfocused = v),
                  factor("글자 크기", () -> Config.get().chat.scale, v -> Config.get().chat.scale = v),
                  Opt.toggle("타임스탬프", () -> Config.get().chat.timestamp, v -> Config.get().chat.timestamp = v),
                  Opt.cycle("타임스탬프 형식", TIME_FORMATS, () -> Config.get().chat.timeFormat, v -> Config.get().chat.timeFormat = v)
               )
            )
      );
      out.add(
         new ClientModule("camera", "프리뷰 카메라", "독립 오빗 카메라 포토 모드", "카메라")
            .key(c -> c.keys.photoToggle)
            .toggle(c -> PhotoModeController.isActive(), (c, v) -> {
               kr.girinworld.core.ClientCompat.setScreen(Minecraft.getInstance(), null);
               PhotoModeController.setActive(v);
            })
            .quick(c -> c.modules.quickCamera, (c, v) -> c.modules.quickCamera = v)
            .opts(
               () -> List.of(
                  Opt.slider("포토 모드 FOV", 10.0, 90.0, 1.0, () -> Config.get().photo.zoomFov, v -> Config.get().photo.zoomFov = v, null),
                  Opt.toggle("부드러운 따라가기", () -> Config.get().photo.smoothFollow, v -> Config.get().photo.smoothFollow = v),
                  Opt.toggle("HUD 숨기기", () -> Config.get().photo.hideHud, v -> Config.get().photo.hideHud = v),
                  Opt.toggle("구도선 기본 켜기", () -> Config.get().photo.gridlinesDefault, v -> Config.get().photo.gridlinesDefault = v)
               )
            )
      );
      out.add(
         new ClientModule("zoom", "줌", "키를 누르는 동안 시야 확대 (기본 Z · 조작 설정에서 변경)", "카메라")
            .key(c -> c.keys.zoom)
            .toggle(c -> c.modules.zoom, (c, v) -> c.modules.zoom = v)
      );
      out.add(
         new ClientModule("autosprint", "자동 달리기", "토글 키로 자동 전진 달리기 (W 홀드 불필요)", "조작")
            .key(c -> c.keys.autoSprint)
            .toggle(c -> ToggleSprintController.isActive(), (c, v) -> ToggleSprintController.setActive(v))
      );
      out.add(
         new ClientModule("brightness", "밝기 조절", "토글 키로 추가 밝기 — 과한 밝기는 서버 지침을 확인하세요", "시각")
            .key(c -> c.keys.brightness)
            .toggle(c -> BrightnessController.isActive(), (c, v) -> BrightnessController.setActive(v))
            .opts(
               () -> List.of(
                  Opt.slider(
                        "밝기 세기",
                        -150.0,
                        1000.0,
                        10.0,
                        () -> Config.get().brightness.level,
                        v -> Config.get().brightness.level = v,
                        () -> (Config.get().brightness.level > 0.0 ? "+" : "") + Math.round(Config.get().brightness.level)
                     )
                     .usableWhen(BrightnessController::isActive)
               )
            )
      );
      out.add(
         new ClientModule("time", "사용자 지정 시간", "내 화면의 시간대만 바꿉니다 — 서버 시간은 그대로 (서버 규정 확인 필요)", "시각")
            .key(c -> c.keys.timePreset)
            .toggle(c -> c.time.enabled, (c, v) -> c.time.enabled = v)
            .opts(
               () -> List.of(
                  Opt.cycle("모드", TIME_MODES, () -> Config.get().time.mode, v -> Config.get().time.mode = v),
                  Opt.cycle("프리셋", CustomTimeController.PRESET_NAMES, () -> Math.max(0, CustomTimeController.presetIndex()), v -> {
                     Config.get().time.mode = 0;
                     Config.get().time.fixed = CustomTimeController.PRESET_TICKS[v];
                  }),
                  Opt.slider("고정 시각", 0.0, 23999.0, 100.0, () -> Config.get().time.fixed, v -> {
                     Config.get().time.mode = 0;
                     Config.get().time.fixed = (int)Math.round(v);
                  }, CustomTimeController::display)
               )
            )
      );
      out.add(
         new ClientModule("font", "글꼴 크기", "글꼴별로 크기를 조절합니다 — 큰 글꼴 때문에 서버 UI가 밀릴 때", "시각")
            .toggle(c -> c.font.enabled, (c, v) -> c.font.enabled = v)
            .opts(ModuleRegistry::fontOpts)
      );
      out.add(
         new ClientModule("beam", "떨어진 아이템 광선", "바닥에 떨어진 아이템 위로 색 광선을 띄웁니다 (바닐라 파티클)", "시각")
            .toggle(c -> c.beam.enabled, (c, v) -> c.beam.enabled = v)
            .opts(
               () -> {
                  List<Opt> o = new ArrayList<>();
                  o.add(Opt.cycle("렌더 방식", BEAM_STYLES, () -> Config.get().beam.style, v -> Config.get().beam.style = v));
                  o.add(
                     Opt.slider(
                        "높이",
                        0.5,
                        10.0,
                        0.1,
                        () -> Config.get().beam.height,
                        v -> Config.get().beam.height = v,
                        () -> String.format("%.1f블록", Config.get().beam.height)
                     )
                  );
                  o.add(
                     Opt.slider(
                        "굵기",
                        0.01,
                        0.5,
                        0.01,
                        () -> Config.get().beam.thickness,
                        v -> Config.get().beam.thickness = v,
                        () -> String.format("%.2f", Config.get().beam.thickness)
                     )
                  );
                  o.add(
                     Opt.slider(
                        "진하기",
                        0.2,
                        4.0,
                        0.2,
                        () -> Config.get().beam.density,
                        v -> Config.get().beam.density = v,
                        () -> String.format("%.1f", Config.get().beam.density)
                     )
                  );
                  o.add(Opt.cycle("색상", BEAM_COLOR_MODES, () -> Config.get().beam.colorMode, v -> Config.get().beam.colorMode = v));
                  o.add(Opt.color("지정 색", () -> Config.get().beam.color, v -> Config.get().beam.color = v));
                  o.add(Opt.cycle("필터", BEAM_FILTERS, () -> Config.get().beam.filterMode, v -> Config.get().beam.filterMode = v));
                  o.add(Opt.action("필터 목록 편집", () -> {
                     Minecraft mc = Minecraft.getInstance();
                     kr.girinworld.core.ClientCompat.setScreen(mc, new BeamFilterScreen(kr.girinworld.core.ClientCompat.screen(mc)));
                  }));
                  o.add(Opt.toggle("아이템 이름 표시 (바라보거나 웅크릴 때)", () -> Config.get().hud.itemName.enabled, v -> Config.get().hud.itemName.enabled = v));
                  o.add(
                     Opt.slider(
                        "거리 컷오프",
                        4.0,
                        96.0,
                        4.0,
                        () -> Config.get().beam.distance,
                        v -> Config.get().beam.distance = (int)Math.round(v),
                        () -> Config.get().beam.distance + "블록"
                     )
                  );
                  o.add(
                     Opt.slider(
                        "개수 상한",
                        4.0,
                        256.0,
                        4.0,
                        () -> Config.get().beam.maxItems,
                        v -> Config.get().beam.maxItems = (int)Math.round(v),
                        () -> Config.get().beam.maxItems + "개"
                     )
                  );
                  o.add(Opt.action("이름 위치·크기 조절", ModuleRegistry::openHudLayout));
                  return o;
               }
            )
      );
      out.add(
         new ClientModule("noDarkness", "어둠 효과 제거", "워든·스컬크 비명체의 어둠 효과(화면 맥동·짙은 안개)를 지웁니다 — 서버 규정 확인", "시각")
            .toggle(c -> c.visual.noDarkness, (c, v) -> c.visual.noDarkness = v)
      );
      out.add(
         new ClientModule("enchantColors", "인챈트 만렙 색상", "아이템 설명의 인챈트 이름: 최대 레벨은 노랑, 그 외 초록 (저주는 빨강 그대로)", "시각")
            .toggle(c -> c.visual.enchantColors, (c, v) -> c.visual.enchantColors = v)
      );
      out.add(
         new ClientModule("advancementDetails", "발전과제 자세히 보기", "발전과제를 클릭하면 조건마다 완료/남음을 보여 줍니다 (예: 모험의 시간 남은 바이옴)", "시각")
            .toggle(c -> c.visual.advancementDetails, (c, v) -> c.visual.advancementDetails = v)
      );
      out.add(
         new ClientModule("healthTag", "남은 체력 표시", "엔티티 머리 위에 남은 체력을 띄웁니다 (서버 점수 줄이 있으면 그쪽 우선)", "시각")
            .toggle(c -> c.healthTag.enabled, (c, v) -> c.healthTag.enabled = v)
            .opts(
               () -> List.of(
                  Opt.cycle("대상", HEALTH_TARGETS, () -> Config.get().healthTag.target, v -> Config.get().healthTag.target = v),
                  Opt.slider(
                     "거리",
                     4.0,
                     64.0,
                     4.0,
                     () -> Config.get().healthTag.distance,
                     v -> Config.get().healthTag.distance = (int)Math.round(v),
                     () -> Config.get().healthTag.distance + "블록"
                  )
               )
            )
      );
      out.add(
         new ClientModule("fishing", "낚시 조절", "다른 사람 입질음은 끄고, 내 입질음만 거리와 무관하게 일정한 크기로", "편의")
            .toggle(c -> c.modules.fishing, (c, v) -> c.modules.fishing = v)
            .opts(() -> List.of(Opt.percent("내 입질음 볼륨", () -> Config.get().fishing.myBiteVolume, v -> Config.get().fishing.myBiteVolume = v)))
      );
      out.add(hud("FPS 표시", "초당 프레임을 HUD에 표시", InfoElement.FPS));
      out.add(hud("실시간 시계", "현실 시각을 HUD에 표시", InfoElement.CLOCK));
      out.add(hud("인게임 시각", "게임 내 시각과 낮/밤을 HUD에 표시", InfoElement.GAME_TIME));
      out.add(hud("핑 표시", "서버 응답 시간(ms)을 HUD에 표시", InfoElement.PING));
      out.add(hud("시스템 표시", "메모리 사용량과 CPU 부하를 HUD에 표시", InfoElement.SYSTEM));
      out.add(hud("물약 효과", "적용 중인 물약 효과와 남은 시간을 표시 (바닐라 표시는 숨김)", InfoElement.POTION));
      out.add(hud("장비 내구도", "투구·흉갑·각반·부츠의 아이콘과 남은 내구도를 HUD에 표시", InfoElement.ARMOR));
      out.add(hud("도구 내구도", "오른손·왼손에 든 도구의 아이콘과 남은 내구도를 HUD에 표시", InfoElement.TOOL));
      out.add(
         new ClientModule("inventory", "인벤토리 HUD", "인벤토리 27칸과 남은 슬롯·화살 수를 HUD에 표시", "정보")
            .key(c -> c.keys.invHold)
            .toggle(ModuleRegistry::invAnyOn, ModuleRegistry::invSetAll)
            .opts(ModuleRegistry::inventoryOpts)
      );
      out.add(
         hud("이동 속도", "수평 이동 속도를 HUD에 표시 (낙하 속도는 제외)", InfoElement.SPEED)
            .opts(
               () -> withHudOpts(
                  InfoElement.SPEED,
                  Opt.cycle("단위", SPEED_UNITS, () -> Config.get().hud.speed.unit, v -> Config.get().hud.speed.unit = v),
                  Opt.slider("소수 자릿수", 0.0, 2.0, 1.0, () -> Config.get().hud.speed.decimals, v -> Config.get().hud.speed.decimals = (int)Math.round(v), null),
                  Opt.toggle("단위 표시", () -> Config.get().hud.speed.showUnit, v -> Config.get().hud.speed.showUnit = v)
               )
            )
      );
      out.add(
         hud("아이템 개수", "손에 든 아이템의 인벤토리 전체 합계를 표시", InfoElement.HELD_COUNT)
            .opts(
               () -> withHudOpts(
                  InfoElement.HELD_COUNT,
                  Opt.cycle("기본 위치", HELD_PRESETS, () -> Config.get().hud.heldCount.preset, ModuleRegistry::applyHeldPreset),
                  Opt.toggle("증감 표시 (+64 / -32)", () -> Config.get().hud.heldCount.showDelta, v -> Config.get().hud.heldCount.showDelta = v)
               )
            )
      );
      out.add(
         new ClientModule("hud_keystrokes", "키입력 표시", "WASD·스페이스·웅크리기·달리기·마우스(CPS)를 HUD에 표시", "정보")
            .toggle(c -> c.hud.keystrokes.enabled, (c, v) -> c.hud.keystrokes.enabled = v)
            .opts(() -> keystrokeOpts())
      );
      return out;
   }

   private static void applyHeldPreset(int preset) {
      Config.Hud.Held c = Config.get().hud.heldCount;
      c.preset = preset;
      if (preset == 1) {
         c.x = 0.5;
         c.y = 0.55;
      } else if (preset == 2) {
         c.x = 0.5;
         c.y = 0.86;
      }
   }

   private static List<Opt> fontOpts() {
      List<Opt> out = new ArrayList<>();

      for (String id : FontScaleController.knownFonts()) {
         out.add(
            Opt.slider(
               shortFontName(id),
               FontScaleController.min(),
               FontScaleController.max(),
               0.05,
               () -> FontScaleController.scaleOf(id),
               v -> FontScaleController.setScale(id, v),
               () -> Math.round(FontScaleController.scaleOf(id) * 100.0) + "%"
            )
         );
      }

      if (out.isEmpty()) {
         out.add(Opt.action("아직 인식된 글꼴이 없습니다", () -> {}));
      }

      out.add(Opt.action("적용 (리소스 다시 읽기)", FontScaleController::applyNow));
      return out;
   }

   private static String shortFontName(String id) {
      int i = id.indexOf(58);
      return i < 0 ? id : id.substring(i + 1);
   }

   private static List<Opt> keystrokeOpts() {
      Supplier<Config.Hud.Keystrokes> c = () -> Config.get().hud.keystrokes;
      List<Opt> out = new ArrayList<>();
      out.add(Opt.toggle("WASD", () -> c.get().wasd, v -> c.get().wasd = v));
      out.add(Opt.toggle("마우스 좌·우클릭", () -> c.get().mouse, v -> c.get().mouse = v));
      out.add(Opt.toggle("CPS 숫자", () -> c.get().cps, v -> c.get().cps = v));
      out.add(Opt.toggle("스페이스", () -> c.get().space, v -> c.get().space = v));
      out.add(Opt.toggle("웅크리기", () -> c.get().sneak, v -> c.get().sneak = v));
      out.add(Opt.toggle("달리기 (달리는 중 표시)", () -> c.get().sprint, v -> c.get().sprint = v));
      out.add(Opt.color("배경색", () -> c.get().bgColor, v -> c.get().bgColor = v));
      out.add(Opt.color("눌림색", () -> c.get().pressColor, v -> c.get().pressColor = v));
      out.add(Opt.color("글자색", () -> c.get().textColor, v -> c.get().textColor = v));
      out.addAll(elemOpts(() -> Config.get().hud.keystrokes));
      return out;
   }

   private static List<Config.Hud.Elem> invParts() {
      Config.Hud h = Config.get().hud;
      return List.of(h.inventory, h.slots);
   }

   private static boolean invAnyOn(Config c) {
      return invParts().stream().anyMatch(e -> e.enabled);
   }

   private static void invSetAll(Config c, boolean on) {
      invParts().forEach(e -> e.enabled = on);
   }

   private static List<Opt> inventoryOpts() {
      List<Opt> out = new ArrayList<>();
      out.add(Opt.toggle("인벤토리 27칸", () -> Config.get().hud.inventory.enabled, v -> Config.get().hud.inventory.enabled = v));
      out.add(Opt.toggle("남은 슬롯 · 화살 수", () -> Config.get().hud.slots.enabled, v -> Config.get().hud.slots.enabled = v));
      out.add(Opt.toggle("홀드 키 모드 (조작 설정에서 키 지정)", () -> Config.get().hud.invHoldOnly, v -> Config.get().hud.invHoldOnly = v));
      out.add(
         Opt.slider(
            "글자 투명도",
            0.1,
            1.0,
            0.0,
            () -> Config.get().hud.inventory.opacity,
            v -> invParts().forEach(e -> e.opacity = HudUtil.clampOpacity(v)),
            () -> Math.round(HudUtil.clampOpacity(Config.get().hud.inventory.opacity) * 100.0) + "%"
         )
      );
      out.add(Opt.toggle("배경", () -> Config.get().hud.inventory.bgEnabled, v -> invParts().forEach(e -> e.bgEnabled = v)));
      out.add(
         Opt.slider(
            "배경 투명도",
            0.0,
            1.0,
            0.0,
            () -> Config.get().hud.inventory.bgOpacity,
            v -> invParts().forEach(e -> e.bgOpacity = v),
            () -> Math.round(Config.get().hud.inventory.bgOpacity * 100.0) + "%"
         )
      );
      out.add(Opt.action("위치·크기 조절", ModuleRegistry::openHudLayout));
      return out;
   }

   private static List<Opt> withHudOpts(InfoElement e, Opt... own) {
      List<Opt> out = new ArrayList<>(List.of(own));
      out.addAll(hudOpts(e));
      return out;
   }

   private static ClientModule hud(String name, String desc, InfoElement e) {
      return new ClientModule(e.moduleId(), name, desc, "정보").toggle(c -> e.cfg().enabled, (c, v) -> e.cfg().enabled = v).onEnable(() -> {
         if (e.autoStacks()) {
            InfoHud.autoPlace(e);
         }
      }).opts(() -> hudOpts(e));
   }

   private static List<Opt> hudOpts(InfoElement e) {
      List<Opt> out = new ArrayList<>(elemOpts(e::cfg));
      if (e.supportsLayout()) {
         out.add(out.size() - 1, Opt.cycle("방향", DIRECTION, () -> e.cfg().horizontal ? 1 : 0, v -> e.cfg().horizontal = v == 1));
      }

      return out;
   }

   private static List<Opt> elemOpts(Supplier<Config.Hud.Elem> cfg) {
      List<Opt> out = new ArrayList<>();
      out.add(
         Opt.slider(
            "글자 투명도",
            0.1,
            1.0,
            0.0,
            () -> cfg.get().opacity,
            v -> cfg.get().opacity = HudUtil.clampOpacity(v),
            () -> Math.round(HudUtil.clampOpacity(cfg.get().opacity) * 100.0) + "%"
         )
      );
      out.add(Opt.toggle("배경", () -> cfg.get().bgEnabled, v -> cfg.get().bgEnabled = v));
      out.add(Opt.slider("배경 투명도", 0.0, 1.0, 0.0, () -> cfg.get().bgOpacity, v -> cfg.get().bgOpacity = v, () -> Math.round(cfg.get().bgOpacity * 100.0) + "%"));
      out.add(Opt.action("위치·크기 조절", ModuleRegistry::openHudLayout));
      return out;
   }

   private static void openHudLayout() {
      Minecraft mc = Minecraft.getInstance();
      kr.girinworld.core.ClientCompat.setScreen(mc, new HudLayoutScreen(kr.girinworld.core.ClientCompat.screen(mc)));
   }

   private static void open(Screen screen) {
      kr.girinworld.core.ClientCompat.setScreen(Minecraft.getInstance(), screen);
   }
}
