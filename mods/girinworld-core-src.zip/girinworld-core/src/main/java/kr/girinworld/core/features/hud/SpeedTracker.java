package kr.girinworld.core.features.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;

public final class SpeedTracker {
   private static final int WINDOW = 4;
   private static final double MAX_TICK_DELTA = 5.0;
   private static final double[] SAMPLES = new double[4];
   private static int index;
   private static int filled;
   private static int lastEntityId = Integer.MIN_VALUE;
   private static double lastX;
   private static double lastZ;

   private SpeedTracker() {
   }

   public static void tick() {
      Minecraft mc = Minecraft.getInstance();
      if (mc != null && mc.player != null && mc.level != null) {
         Entity e = (Entity)(mc.player.isPassenger() ? mc.player.getVehicle() : mc.player);
         if (e == null) {
            e = mc.player;
         }

         if (e.getId() != lastEntityId) {
            lastEntityId = e.getId();
            lastX = e.getX();
            lastZ = e.getZ();
            reset();
         } else {
            double dx = e.getX() - lastX;
            double dz = e.getZ() - lastZ;
            lastX = e.getX();
            lastZ = e.getZ();
            double d = Math.sqrt(dx * dx + dz * dz);
            if (!(d > 5.0)) {
               SAMPLES[index] = d;
               index = (index + 1) % 4;
               if (filled < 4) {
                  filled++;
               }
            }
         }
      } else {
         reset();
      }
   }

   public static double blocksPerSecond() {
      if (filled == 0) {
         return 0.0;
      }

      double sum = 0.0;

      for (int i = 0; i < filled; i++) {
         sum += SAMPLES[i];
      }

      return sum / filled * 20.0;
   }

   private static void reset() {
      index = 0;
      filled = 0;
   }
}
