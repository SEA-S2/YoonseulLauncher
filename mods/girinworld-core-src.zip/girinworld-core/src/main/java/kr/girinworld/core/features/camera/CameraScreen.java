package kr.girinworld.core.features.camera;

import kr.girinworld.core.Config;
import kr.girinworld.core.features.CoreScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class CameraScreen extends CoreScreen {
   private static final String[] KEY_GUIDE = new String[]{
      "지정 키  : 프리뷰 카메라 켜기/끄기 (조작 설정)",
      "ESC      : 프리뷰 카메라 끄기",
      "마우스   : 카메라 각도 (플레이어 고정)",
      "스크롤   : 오빗 거리 1~15",
      "WASD     : 카메라 기준 이동",
      "Z 홀드   : 줌",
      "G        : 3분할 구도선"
   };
   private final Screen parent;

   public CameraScreen(Screen parent) {
      super(Component.literal("프리뷰 카메라"));
      this.parent = parent;
   }

   protected void init() {
      int w = 200;
      int left = this.width / 2 - w / 2;
      int y = this.height / 2 + 40;
      this.addRenderableWidget(Button.builder(Component.literal("프리뷰 카메라 시작"), b -> this.startPhoto()).bounds(left, y, w, 20).build());
      this.addRenderableWidget(Button.builder(Component.literal("닫기"), b -> this.onClose()).bounds(left, y + 24, w, 20).build());
   }

   private void startPhoto() {
      Minecraft.getInstance().setScreen(null);
      if (!PhotoModeController.isActive()) {
         PhotoModeController.toggle();
      }
   }

   public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
      super.extractRenderState(graphics, mouseX, mouseY, partialTick);
      Font f = this.font;
      String title = this.getTitle().getString();
      graphics.text(f, title, this.width / 2 - f.width(title) / 2, this.height / 2 - 88, -1);
      Config.Photo p = Config.get().photo;
      String state = "줌 FOV " + (int)p.zoomFov + " | 구도선 기본 " + (p.gridlinesDefault ? "on" : "off");
      int left = this.width / 2 - 100;
      graphics.text(f, state, left, this.height / 2 - 74, -5592406);
      int gy = this.height / 2 - 58;

      for (String line : KEY_GUIDE) {
         graphics.text(f, line, left, gy, -2236963);
         gy += 11;
      }
   }

   public void onClose() {
      Minecraft.getInstance().setScreen(this.parent);
   }
}
