package kr.girinworld.core.features.account;

import com.mojang.authlib.minecraft.UserApiService;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import java.io.InputStream;
import java.lang.ProcessBuilder.Redirect;
import java.net.Proxy;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kr.girinworld.core.CoreLog;
import net.minecraft.client.Minecraft;

public final class TokenRefresher {
   private static final long MARGIN_SEC = 240L;
   private static final long CHECK_MS = 60000L;
   private static final long RETRY_MS = 300000L;
   private static final Pattern EXP = Pattern.compile("\"exp\"\\s*:\\s*(\\d+)");
   private static volatile String token;
   private static volatile UserApiService api;
   private static volatile long expiresAt = -1L;
   private static volatile long nextCheckMs;
   private static volatile boolean running;

   private TokenRefresher() {
   }

   public static void tick(Minecraft mc) {
      long now = System.currentTimeMillis();
      if (!running && now >= nextCheckMs) {
         nextCheckMs = now + 60000L;
         String exe = System.getProperty("girinworld.launcherExe");
         if (exe != null) {
            if (expiresAt < 0L) {
               expiresAt = jwtExp(mc.getUser().getAccessToken());
            }

            if (expiresAt != 0L && now / 1000L >= expiresAt - 240L) {
               running = true;
               UUID id = mc.getUser().getProfileId();
               Thread t = new Thread(() -> refresh(exe, id), "girinworld-token");
               t.setDaemon(true);
               t.start();
            }
         }
      }
   }

   private static void refresh(String exe, UUID id) {
      try {
         List<String> cmd = new ArrayList<>();
         cmd.add(exe);
         String script = System.getProperty("girinworld.launcherScript");
         if (script != null) {
            cmd.add(script);
         }

         cmd.add("--mc-token");
         cmd.add(id.toString());
         Process p = new ProcessBuilder(cmd).redirectError(Redirect.DISCARD).start();
         if (!p.waitFor(120L, TimeUnit.SECONDS)) {
            p.destroyForcibly();
            fail("launcher timed out");
            return;
         }

         String out;
         try (InputStream in = p.getInputStream()) {
            out = new String(in.readAllBytes(), StandardCharsets.US_ASCII).trim();
         }

         long exp = jwtExp(out);
         if (p.exitValue() == 0 && exp > expiresAt) {
            api = new YggdrasilAuthenticationService(Proxy.NO_PROXY).createUserApiService(out);
            token = out;
            expiresAt = exp;
            CoreLog.info("access token refreshed, valid for " + (exp - System.currentTimeMillis() / 1000L) / 3600L + "h");
            return;
         }

         fail("launcher exit=" + p.exitValue() + (exp <= expiresAt ? " (no newer token)" : ""));
      } catch (Throwable t) {
         CoreLog.error("access token refresh failed", t);
         nextCheckMs = System.currentTimeMillis() + 300000L;
         return;
      } finally {
         running = false;
      }
   }

   private static void fail(String why) {
      CoreLog.error("access token refresh failed: " + why, null);
      nextCheckMs = System.currentTimeMillis() + 300000L;
   }

   public static String accessToken(String original) {
      String t = token;
      return t != null ? t : original;
   }

   public static UserApiService profileKeyApi(UserApiService original) {
      UserApiService a = api;
      return a != null ? a : original;
   }

   static long jwtExp(String jwt) {
      if (jwt == null) {
         return 0L;
      }

      String[] parts = jwt.trim().split("\\.");
      if (parts.length < 2) {
         return 0L;
      }

      try {
         Matcher m = EXP.matcher(new String(Base64.getUrlDecoder().decode(parts[1]), StandardCharsets.UTF_8));
         return m.find() ? Long.parseLong(m.group(1)) : 0L;
      } catch (IllegalArgumentException e) {
         return 0L;
      }
   }
}
