package kr.girinworld.core.features.camera;

import kr.girinworld.core.Config;

public final class ZoomController {
   private static final double MIN_FOV = 10.0;
   private static final double MAX_FOV = 50.0;
   private static final double SCROLL_STEP = 2.0;
   private static final long EASE_NANOS = 200000000L;
   private static volatile boolean zoomActive = false;
   private static double targetFov = 30.0;
   private static double factor = 0.0;
   private static long lastNanos = 0L;
   private static boolean initialized = false;

   private ZoomController() {
   }

   public static void setZoomActive(boolean active) {
      if (!initialized) {
         targetFov = clampFov(Config.get().photo.zoomFov);
         initialized = true;
      }

      zoomActive = active && Config.get().modules.zoom;
   }

   public static boolean isZoomActive() {
      return zoomActive;
   }

   public static boolean onScroll(double yScroll) {
      if (!zoomActive) {
         return false;
      }

      targetFov = clampFov(targetFov - yScroll * 2.0);
      return true;
   }

   public static float modifyFov(float vanillaFov) {
      long now = System.nanoTime();
      if (lastNanos == 0L) {
         lastNanos = now;
      }

      double step = Math.min(1.0, (now - lastNanos) / 2.0E8);
      lastNanos = now;
      double target = zoomActive ? 1.0 : 0.0;
      factor = moveToward(factor, target, step);
      if (factor <= 1.0E-4 && !zoomActive) {
         return vanillaFov;
      }

      double eased = smoothstep(factor);
      return (float)(vanillaFov + (clampFov(targetFov) - vanillaFov) * eased);
   }

   private static double moveToward(double from, double to, double maxDelta) {
      double d = to - from;
      return Math.abs(d) <= maxDelta ? to : from + Math.copySign(maxDelta, d);
   }

   private static double smoothstep(double t) {
      double c = Math.max(0.0, Math.min(1.0, t));
      return c * c * (3.0 - 2.0 * c);
   }

   private static double clampFov(double v) {
      return Math.max(10.0, Math.min(50.0, v));
   }
}
