package kr.girinworld.core.agent;

import java.nio.file.Path;
import kr.girinworld.core.CoreLog;

final class KnotExposure {
   private static volatile boolean done = false;

   private KnotExposure() {
   }

   static void ensureExposed(ClassLoader loader) {
      if (!done && loader != null) {
         if (loader.getClass().getName().toLowerCase().contains("knot")) {
            done = true;

            try {
               Path jar = Path.of(KnotExposure.class.getProtectionDomain().getCodeSource().getLocation().toURI());
               Class<?> base = Class.forName("net.fabricmc.loader.impl.launch.FabricLauncherBase", false, loader);
               Object launcher = base.getMethod("getLauncher").invoke(null);
               launcher.getClass().getMethod("addToClassPath", Path.class, String[].class).invoke(launcher, jar, new String[0]);
               CoreLog.info("exposed core jar to Knot classpath: " + jar);
            } catch (Throwable t) {
               CoreLog.error("failed to expose core jar to Knot (Fabric)", t);
            }
         }
      }
   }
}
