package kr.girinworld.core;

import com.mojang.authlib.minecraft.UserApiService;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.vertex.PoseStack;
import java.lang.reflect.Field;
import java.util.function.Predicate;
import kr.girinworld.core.features.account.TokenRefresher;
import kr.girinworld.core.features.calc.CalcScreen;
import kr.girinworld.core.features.camera.GridlinesHud;
import kr.girinworld.core.features.camera.PhotoModeController;
import kr.girinworld.core.features.camera.ZoomController;
import kr.girinworld.core.features.chat.ChatController;
import kr.girinworld.core.features.control.ToggleSprintController;
import kr.girinworld.core.features.fishing.FishingController;
import kr.girinworld.core.features.hud.CpsCounter;
import kr.girinworld.core.features.hud.InfoElement;
import kr.girinworld.core.features.hud.Widgets;
import kr.girinworld.core.features.macro.MacroController;
import kr.girinworld.core.features.quickmenu.QuickMenuScreen;
import kr.girinworld.core.features.settings.ModuleSettingsScreen;
import kr.girinworld.core.features.timer.TimerManager;
import kr.girinworld.core.features.timer.TimerScreen;
import kr.girinworld.core.features.visual.AdvancementDetails;
import kr.girinworld.core.features.visual.BrightnessController;
import kr.girinworld.core.features.visual.CustomTimeController;
import kr.girinworld.core.features.visual.FontScaleController;
import kr.girinworld.core.features.visual.HealthTagController;
import kr.girinworld.core.features.whisper.WhisperScreen;
import kr.girinworld.core.features.whisper.WhisperService;
import kr.girinworld.core.features.world.ItemBeamController;
import net.minecraft.ChatFormatting;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.DisplayInfo;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.advancements.AdvancementWidget;
import net.minecraft.client.gui.screens.advancements.AdvancementsScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.MouseButtonInfo;
import net.minecraft.client.multiplayer.chat.GuiMessageSource;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.KeyboardInput;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LightmapRenderStateExtractor;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.fog.environment.DarknessFogEnvironment;
import net.minecraft.client.renderer.fog.environment.MobEffectFogEnvironment;
import net.minecraft.client.renderer.state.LightmapRenderState;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.EnchantmentTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.phys.Vec2;

public final class Hooks {
   private static final int GLFW_RELEASE = 0;
   private static final int GLFW_PRESS = 1;
   private static final int GLFW_KEY_ESCAPE = 256;
   private static volatile int quickmenuKeyCache = Integer.MIN_VALUE;
   private static volatile int zoomKeyCache = Integer.MIN_VALUE;
   private static volatile int photoKeyCache = Integer.MIN_VALUE;
   private static volatile int gridlinesKeyCache = Integer.MIN_VALUE;
   private static volatile boolean loggedClassloaders = false;
   private static long extractStart;
   private static long lightmapDiagAt;
   private static int lightmapClockBase;
   private static int lightmapClockReads;
   private static int lightmapSampled;
   private static int lightmapSkipped;
   private static Field accumulatedDX;
   private static Field accumulatedDY;
   private static boolean reflectionInitialized = false;
   private static Field moveVectorField;
   private static boolean moveReflectionInitialized = false;
   private static Field lightmapNeedsUpdate;
   private static boolean lightmapReflectionInit;
   private static boolean brightnessWasOn;

   private static void logLightmapDiag(LightmapRenderState state) {
      if (CustomTimeController.enabled()) {
         lightmapClockReads = lightmapClockReads + (CustomTimeController.overrideCount() - lightmapClockBase);
         if (state != null && state.needsUpdate) {
            lightmapSampled++;
         } else {
            lightmapSkipped++;
         }

         long now = System.nanoTime();
         if (lightmapDiagAt == 0L || now - lightmapDiagAt >= 5000000000L) {
            lightmapDiagAt = now;
            CoreLog.info(
               "lightmap: clockReadsInside="
                  + lightmapClockReads
                  + " sampled="
                  + lightmapSampled
                  + " skipped="
                  + lightmapSkipped
                  + " target="
                  + CustomTimeController.display()
                  + (state == null ? " state=null" : " skyFactor=" + state.skyFactor + " brightness=" + state.brightness)
            );
            lightmapClockReads = 0;
            lightmapSampled = 0;
            lightmapSkipped = 0;
            CustomTimeController.resetOverrideCount();
         }
      }
   }

   private Hooks() {
   }

   public static boolean onKeyPress(long window, int action, KeyEvent event) {
      try {
         if (event == null) {
            return false;
         }

         int key = event.key();
         Minecraft mc = Minecraft.getInstance();
         if (action == 1 && key == 256 && PhotoModeController.isActive()) {
            PhotoModeController.toggle();
            return true;
         }

         if (key == zoomGlfwKey()) {
            if (action == 1) {
               if (idleInGame(mc)) {
                  ZoomController.setZoomActive(true);
               }
            } else if (action == 0) {
               ZoomController.setZoomActive(false);
            }

            return false;
         } else if (action == 1 && KeyBindings.matchesPhotoToggle(event)) {
            if (PhotoModeController.isActive() || idleInGame(mc)) {
               PhotoModeController.toggle();
            }

            return false;
         } else {
            if (action == 1 && key == gridlinesGlfwKey() && PhotoModeController.isActive()) {
               PhotoModeController.toggleGridlines();
               return false;
            }

            if (action == 1 && KeyBindings.matchesSettings(event)) {
               if (!idleInGame(mc)) {
                  return false;
               }

               mc.setScreen(new ModuleSettingsScreen());
               return true;
            } else if (action == 1 && KeyBindings.matchesQuickmenu(event)) {
               if (!idleInGame(mc)) {
                  return false;
               }

               logClassloadersOnce(mc);
               mc.setScreen(new QuickMenuScreen());
               return true;
            } else if (action == 1 && KeyBindings.matchesCalc(event) && idleInGame(mc)) {
               mc.setScreen(new CalcScreen(null));
               return true;
            } else if (action == 1 && KeyBindings.matchesTimer(event) && idleInGame(mc)) {
               mc.setScreen(new TimerScreen(null));
               return true;
            } else if (action == 1 && KeyBindings.matchesWhisper(event) && idleInGame(mc)) {
               mc.setScreen(new WhisperScreen(null));
               return true;
            } else if (action == 1 && KeyBindings.matchesMacro(event) && idleInGame(mc)) {
               mc.setScreen(new ModuleSettingsScreen(2));
               return true;
            } else if (action == 1 && KeyBindings.matchesTimerRecent(event) && idleInGame(mc)) {
               TimerManager.startRecent();
               return true;
            } else if (action == 1 && idleInGame(mc) && MacroController.tryRun(event)) {
               return true;
            } else if (action == 1 && KeyBindings.matchesAutoSprint(event) && idleInGame(mc)) {
               ToggleSprintController.toggle();
               return false;
            } else if (action == 1 && KeyBindings.matchesBrightness(event) && idleInGame(mc)) {
               BrightnessController.toggle();
               return false;
            } else if (action == 1 && KeyBindings.matchesTimePreset(event) && mc != null && mc.level != null && mc.screen == null) {
               CustomTimeController.cyclePreset();
               return false;
            } else {
               return false;
            }
         }
      } catch (Throwable t) {
         CoreLog.error("onKeyPress failed", t);
         return false;
      }
   }

   private static boolean runPressBinds(Minecraft mc, Predicate<String> hit) {
      if (!idleInGame(mc)) {
         return false;
      } else if (hit.test("settings")) {
         mc.setScreen(new ModuleSettingsScreen());
         return true;
      } else if (hit.test("quickmenu")) {
         mc.setScreen(new QuickMenuScreen());
         return true;
      } else if (hit.test("calc")) {
         mc.setScreen(new CalcScreen(null));
         return true;
      } else if (hit.test("timer")) {
         mc.setScreen(new TimerScreen(null));
         return true;
      } else if (hit.test("whisper")) {
         mc.setScreen(new WhisperScreen(null));
         return true;
      } else if (hit.test("timer_recent")) {
         TimerManager.startRecent();
         return true;
      } else if (hit.test("camera")) {
         PhotoModeController.toggle();
         return true;
      } else if (hit.test("autosprint")) {
         ToggleSprintController.toggle();
         return true;
      } else if (hit.test("brightness")) {
         BrightnessController.toggle();
         return true;
      } else if (hit.test("time")) {
         CustomTimeController.cyclePreset();
         return true;
      } else {
         return false;
      }
   }

   private static boolean idleInGame(Minecraft mc) {
      return mc != null && mc.player != null && mc.level != null && mc.screen == null;
   }

   public static float modifyFov(float vanillaFov) {
      try {
         return ZoomController.modifyFov(vanillaFov);
      } catch (Throwable t) {
         CoreLog.error("modifyFov failed", t);
         return vanillaFov;
      }
   }

   public static float modifyFishingVolume(float vanillaVolume, SoundInstance instance) {
      long t0 = HookProfiler.start();

      try {
         return FishingController.modifyVolume(vanillaVolume, instance);
      } catch (Throwable t) {
         CoreLog.error("modifyFishingVolume failed", t);
         return vanillaVolume;
      } finally {
         HookProfiler.end("H13.sound", t0);
      }
   }

   public static SoundInstance prepareSound(SoundInstance instance) {
      long t0 = HookProfiler.start();

      try {
         return FishingController.prepareVolume(instance);
      } catch (Throwable t) {
         CoreLog.error("prepareSound failed", t);
         return instance;
      } finally {
         HookProfiler.end("H15.soundPlay", t0);
      }
   }

   public static boolean onScroll(long window, double xScroll, double yScroll) {
      try {
         return PhotoModeController.isActive() ? PhotoModeController.onScroll(yScroll) : ZoomController.onScroll(yScroll);
      } catch (Throwable t) {
         CoreLog.error("onScroll failed", t);
         return false;
      }
   }

   public static boolean onTurnPlayer(MouseHandler self, double partialTick) {
      try {
         if (!PhotoModeController.isActive()) {
            return false;
         }

         initTurnReflection();
         if (accumulatedDX != null && accumulatedDY != null && self != null) {
            double dx = accumulatedDX.getDouble(self);
            double dy = accumulatedDY.getDouble(self);
            accumulatedDX.setDouble(self, 0.0);
            accumulatedDY.setDouble(self, 0.0);
            PhotoModeController.applyMouseDelta(dx, dy);
         }

         return true;
      } catch (Throwable t) {
         CoreLog.error("onTurnPlayer failed", t);
         return false;
      }
   }

   public static float photoYaw(float original) {
      try {
         return PhotoModeController.isActive() ? PhotoModeController.camYaw() : original;
      } catch (Throwable t) {
         return original;
      }
   }

   public static float photoPitch(float original) {
      try {
         return PhotoModeController.isActive() ? PhotoModeController.camPitch() : original;
      } catch (Throwable t) {
         return original;
      }
   }

   public static float photoOrbitDistance(float original) {
      try {
         return PhotoModeController.isActive() ? PhotoModeController.orbitDistance() : original;
      } catch (Throwable t) {
         return original;
      }
   }

   private static void initTurnReflection() {
      if (!reflectionInitialized) {
         reflectionInitialized = true;

         try {
            accumulatedDX = MouseHandler.class.getDeclaredField("accumulatedDX");
            accumulatedDX.setAccessible(true);
            accumulatedDY = MouseHandler.class.getDeclaredField("accumulatedDY");
            accumulatedDY.setAccessible(true);
         } catch (Throwable t) {
            CoreLog.error("turnPlayer field reflection failed", t);
         }
      }
   }

   private static void initMoveReflection() {
      if (!moveReflectionInitialized) {
         moveReflectionInitialized = true;

         try {
            moveVectorField = ClientInput.class.getDeclaredField("moveVector");
            moveVectorField.setAccessible(true);
         } catch (Throwable t) {
            CoreLog.error("moveVector field reflection failed", t);
         }
      }
   }

   public static int gridlinesGlfwKey() {
      int c = gridlinesKeyCache;
      if (c == Integer.MIN_VALUE) {
         try {
            c = InputConstants.getKey(Config.get().keys.gridlines).getValue();
         } catch (Throwable t) {
            CoreLog.error("gridlines key resolve failed, defaulting to G(71)", t);
            c = 71;
         }

         gridlinesKeyCache = c;
      }

      return c;
   }

   public static boolean onMouseButton(long window, MouseButtonInfo info, int action) {
      try {
         Minecraft mc = Minecraft.getInstance();
         if (info != null && action == 1 && runPressBinds(mc, id -> KeyBindings.matchesMouse(id, info))) {
            return true;
         }

         if (info != null && action == 1 && idleInGame(mc)) {
            CpsCounter.onClick(info.button());
         }

         return false;
      } catch (Throwable t) {
         CoreLog.error("onMouseButton failed", t);
         return false;
      }
   }

   public static void onClientTick() {
      long t0 = HookProfiler.start();

      try {
         ClassPreloader.ensurePreloaded();
         TimerManager.update();
         long a = HookProfiler.start();
         Widgets.tick();
         HookProfiler.end("H2.widgetTick", a);
         PhotoModeController.tick();
         Minecraft mc = Minecraft.getInstance();
         if (mc != null) {
            a = HookProfiler.start();
            KeyBindings.tick(mc);
            HookProfiler.end("H2.keyBinds", a);
            ToggleSprintController.tick(mc);
            a = HookProfiler.start();
            FishingController.tick(mc);
            HookProfiler.end("tick.fishing", a);
            TokenRefresher.tick(mc);
         }
      } catch (Throwable t) {
         CoreLog.error("onClientTick failed", t);
      } finally {
         HookProfiler.end("H2.tick", t0);
      }
   }

   public static boolean onLightmapExtractBegin(LightmapRenderStateExtractor self, LightmapRenderState state, float partialTick) {
      try {
         lightmapClockBase = CustomTimeController.overrideCount();
         CustomTimeController.beginTimedRender();
         if (CustomTimeController.enabled()) {
            forceLightmapResample(self);
         }
      } catch (Throwable t) {
         CoreLog.error("onLightmapExtractBegin failed", t);
      }

      return false;
   }

   private static void forceLightmapResample(LightmapRenderStateExtractor extractor) {
      if (!lightmapReflectionInit) {
         lightmapReflectionInit = true;

         try {
            lightmapNeedsUpdate = LightmapRenderStateExtractor.class.getDeclaredField("needsUpdate");
            lightmapNeedsUpdate.setAccessible(true);
         } catch (Throwable t) {
            CoreLog.error("lightmap needsUpdate reflection failed", t);
         }
      }

      if (lightmapNeedsUpdate != null && extractor != null) {
         try {
            lightmapNeedsUpdate.setBoolean(extractor, true);
         } catch (Throwable var2) {
         }
      }
   }

   public static void onLightmapExtract(LightmapRenderState state) {
      long t0 = HookProfiler.start();

      try {
         CustomTimeController.endTimedRender();
         logLightmapDiag(state);
         if (state != null) {
            boolean on = BrightnessController.isActive();
            if (on) {
               state.brightness = BrightnessController.targetBrightness();
               state.needsUpdate = true;
            } else if (brightnessWasOn) {
               state.needsUpdate = true;
            }

            brightnessWasOn = on;
            if (Config.get().visual.noDarkness) {
               state.darknessEffectScale = 0.0F;
            }
         }
      } catch (Throwable t) {
         CoreLog.error("onLightmapExtract failed", t);
      } finally {
         HookProfiler.end("H12.lightmap", t0);
      }
   }

   public static void onHudRender(GuiGraphicsExtractor graphics) {
      long t0 = HookProfiler.start();

      try {
         Widgets.renderAll(graphics);
         long a = HookProfiler.start();
         GridlinesHud.render(graphics);
         HookProfiler.end("H3.gridlines", a);
      } catch (Throwable t) {
         CoreLog.error("onHudRender failed", t);
      } finally {
         HookProfiler.end("H3.hudRender", t0);
      }
   }

   public static boolean onExtractEffects(GuiGraphicsExtractor graphics, DeltaTracker delta) {
      try {
         return InfoElement.POTION.cfg().enabled;
      } catch (Throwable t) {
         CoreLog.error("onExtractEffects failed", t);
         return false;
      }
   }

   public static boolean onExtractBegin(DeltaTracker delta, boolean renderLevel) {
      try {
         extractStart = HookProfiler.start();
         CustomTimeController.beginTimedRender();
      } catch (Throwable t) {
         CoreLog.error("onExtractBegin failed", t);
      }

      return false;
   }

   public static void onExtractEnd() {
      try {
         CustomTimeController.endTimedRender();
      } catch (Throwable t) {
         CoreLog.error("onExtractEnd failed", t);
      } finally {
         HookProfiler.end(CustomTimeController.enabled() ? "H19.extract.timeON" : "H19.extract.timeOFF", extractStart);
      }
   }

   public static long skyClockTime(long vanillaTicks) {
      try {
         return CustomTimeController.clockTime(vanillaTicks);
      } catch (Throwable t) {
         return vanillaTicks;
      }
   }

   public static void onSubmitEntities(PoseStack pose, SubmitNodeCollector collector) {
      long t0 = HookProfiler.start();

      try {
         ItemBeamController.submitBeams(pose, collector);
      } catch (Throwable t) {
         CoreLog.error("onSubmitEntities failed", t);
      } finally {
         HookProfiler.end("H23.itemBeams", t0);
      }
   }

   public static boolean fogApplicable(boolean applicable, MobEffectFogEnvironment self) {
      return applicable && (!Config.get().visual.noDarkness || !(self instanceof DarknessFogEnvironment));
   }

   public static Component enchantName(Component name, Holder<Enchantment> holder, int level) {
      try {
         if (Config.get().visual.enchantColors && name instanceof MutableComponent m && !holder.is(EnchantmentTags.CURSE)) {
            m.withStyle(level >= ((Enchantment)holder.value()).getMaxLevel() ? ChatFormatting.YELLOW : ChatFormatting.GREEN);
         }
      } catch (Throwable t) {
         CoreLog.error("enchantName failed", t);
      }

      return name;
   }

   public static UserApiService profileKeyApi(UserApiService original) {
      try {
         return TokenRefresher.profileKeyApi(original);
      } catch (Throwable t) {
         CoreLog.error("profileKeyApi failed", t);
         return original;
      }
   }

   public static String accessToken(String original) {
      try {
         return TokenRefresher.accessToken(original);
      } catch (Throwable t) {
         CoreLog.error("accessToken failed", t);
         return original;
      }
   }

   public static boolean onAdvancementProgress(AdvancementWidget widget, AdvancementProgress progress) {
      try {
         AdvancementDetails.onProgress(widget, progress);
      } catch (Throwable t) {
         CoreLog.error("onAdvancementProgress failed", t);
      }

      return false;
   }

   public static void onAdvancementHover(AdvancementWidget widget, GuiGraphicsExtractor g, int x, int y, float fade, int left, int top) {
      AdvancementDetails.onHover(widget);
   }

   public static void onAdvancementWidget(AdvancementWidget widget, DisplayInfo display) {
      try {
         AdvancementDetails.onCreate(widget, display);
      } catch (Throwable t) {
         CoreLog.error("onAdvancementWidget failed", t);
      }
   }

   public static void onAdvancementsScreenCreate(AdvancementsScreen screen, Screen openedFrom) {
      try {
         AdvancementDetails.onScreenCreate(screen, openedFrom);
      } catch (Throwable t) {
         CoreLog.error("onAdvancementsScreenCreate failed", t);
      }
   }

   public static boolean onAdvancementsClick(boolean handled, MouseButtonEvent e) {
      try {
         return AdvancementDetails.onMouseClicked(handled, e);
      } catch (Throwable t) {
         CoreLog.error("onAdvancementsClick failed", t);
         return handled;
      }
   }

   public static boolean onAdvancementsRelease(boolean handled, MouseButtonEvent e) {
      try {
         return AdvancementDetails.onMouseReleased(handled, e);
      } catch (Throwable t) {
         CoreLog.error("onAdvancementsRelease failed", t);
         return handled;
      }
   }

   public static void onAdvancementsScreen(GuiGraphicsExtractor g, int mouseX, int mouseY) {
      try {
         AdvancementDetails.onScreenRender(g, mouseX, mouseY);
      } catch (Throwable t) {
         CoreLog.error("onAdvancementsScreen failed", t);
      }
   }

   public static void onEntityExtract(Entity entity, EntityRenderState state, float partialTick) {
      try {
         HealthTagController.apply(entity, state, partialTick);
      } catch (Throwable t) {
         CoreLog.error("onEntityExtract failed", t);
      }
   }

   public static float fontSize(float size, Identifier location) {
      try {
         return FontScaleController.apply(size, location);
      } catch (Throwable t) {
         CoreLog.error("fontSize failed", t);
         return size;
      }
   }

   public static void onFrameEnd() {
      long t0 = HookProfiler.start();

      try {
         CustomTimeController.clearFlag();
      } catch (Throwable t) {
         CoreLog.error("onFrameEnd failed", t);
      } finally {
         HookProfiler.end("H10.frameEnd", t0);
      }
   }

   public static void onChatMessage(Component message, GuiMessageSource source) {
      try {
         if (message == null || source != GuiMessageSource.SYSTEM_SERVER) {
            return;
         }

         WhisperService.onChatLine(ChatController.undecorate(message.getString()));
      } catch (Throwable t) {
         CoreLog.error("onChatMessage failed", t);
      }
   }

   public static int chatWidth(int vanilla) {
      try {
         return ChatController.width(vanilla);
      } catch (Throwable t) {
         return vanilla;
      }
   }

   public static int chatHeight(int vanilla) {
      try {
         return ChatController.height(vanilla);
      } catch (Throwable t) {
         return vanilla;
      }
   }

   public static double chatScale(double vanilla) {
      try {
         return ChatController.scale(vanilla);
      } catch (Throwable t) {
         return vanilla;
      }
   }

   public static Component decorateChatLine(Component line) {
      try {
         return ChatController.decorate(line);
      } catch (Throwable t) {
         CoreLog.error("decorateChatLine failed", t);
         return line;
      }
   }

   public static void onMovementInput(KeyboardInput self) {
      try {
         if (!PhotoModeController.isActive() || self == null) {
            return;
         }

         Minecraft mc = Minecraft.getInstance();
         if (mc == null || mc.player == null) {
            return;
         }

         LocalPlayer player = mc.player;
         if (player.isSwimming() || player.isFallFlying() || player.isPassenger()) {
            return;
         }

         initMoveReflection();
         if (moveVectorField == null) {
            return;
         }

         Vec2 v = (Vec2)moveVectorField.get(self);
         if (v == null || v.x == 0.0F && v.y == 0.0F) {
            return;
         }

         double delta = Math.toRadians(PhotoModeController.camYaw() - player.getYRot());
         double cos = Math.cos(delta);
         double sin = Math.sin(delta);
         float nx = (float)(v.x * cos - v.y * sin);
         float ny = (float)(v.x * sin + v.y * cos);
         moveVectorField.set(self, new Vec2(nx, ny));
      } catch (Throwable t) {
         CoreLog.error("onMovementInput failed", t);
      }
   }

   public static int quickmenuGlfwKey() {
      int c = quickmenuKeyCache;
      if (c == Integer.MIN_VALUE) {
         try {
            c = InputConstants.getKey(Config.get().keys.quickmenu).getValue();
         } catch (Throwable t) {
            CoreLog.error("quickmenu key resolve failed, defaulting to C(67)", t);
            c = 67;
         }

         quickmenuKeyCache = c;
      }

      return c;
   }

   public static void invalidateKeyCaches() {
      quickmenuKeyCache = Integer.MIN_VALUE;
      zoomKeyCache = Integer.MIN_VALUE;
      photoKeyCache = Integer.MIN_VALUE;
      gridlinesKeyCache = Integer.MIN_VALUE;
   }

   public static int zoomGlfwKey() {
      int c = zoomKeyCache;
      if (c == Integer.MIN_VALUE) {
         try {
            c = InputConstants.getKey(Config.get().keys.zoom).getValue();
         } catch (Throwable t) {
            CoreLog.error("zoom key resolve failed, defaulting to Z(90)", t);
            c = 90;
         }

         zoomKeyCache = c;
      }

      return c;
   }

   public static int photoToggleGlfwKey() {
      int c = photoKeyCache;
      if (c == Integer.MIN_VALUE) {
         try {
            c = InputConstants.getKey(Config.get().keys.photoToggle).getValue();
         } catch (Throwable t) {
            CoreLog.error("photo toggle key resolve failed, defaulting to LEFT_ALT(342)", t);
            c = 342;
         }

         photoKeyCache = c;
      }

      return c;
   }

   private static void logClassloadersOnce(Minecraft mc) {
      if (!loggedClassloaders) {
         loggedClassloaders = true;
         CoreLog.info("classloaders - Minecraft=" + mc.getClass().getClassLoader() + " Hooks=" + Hooks.class.getClassLoader());
      }
   }
}
