package kr.girinworld.core.features.world;

import kr.girinworld.core.Config;
import kr.girinworld.core.features.CoreScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;

public final class BeamFilterScreen extends CoreScreen {
   private static final int PANEL_W = 280;
   private static final int GLFW_ENTER = 257;
   private static final int GLFW_KP_ENTER = 335;
   private final Screen parent;
   private EditBox box;
   private int left;
   private int titleY;
   private int labelY;
   private int hintY;

   public BeamFilterScreen(Screen parent) {
      super(Component.literal("광선 필터 목록"));
      this.parent = parent;
   }

   protected void init() {
      this.left = this.width / 2 - 140;
      int y = this.height / 2 - 46;
      this.titleY = y;
      y += 15;
      this.labelY = y;
      y += 11;
      int boxY = y;
      y += 26;
      this.hintY = y;
      y += 14;
      int btnY = y;
      this.box = new EditBox(this.font, this.left, boxY, 280, 20, Component.literal(""));
      this.box.setMaxLength(512);
      this.box.setValue(Config.get().beam.filter);
      this.addRenderableWidget(this.box);
      this.setInitialFocus(this.box);
      int half = 136;
      this.addRenderableWidget(Button.builder(Component.literal("저장"), b -> this.submit()).bounds(this.left, btnY, half, 20).build());
      this.addRenderableWidget(Button.builder(Component.literal("취소"), b -> this.onClose()).bounds(this.left + half + 8, btnY, half, 20).build());
   }

   private void submit() {
      Config c = Config.get();
      c.beam.filter = this.box.getValue().trim();
      c.save();
      this.onClose();
   }

   public boolean keyPressed(KeyEvent event) {
      if ((event.key() == 257 || event.key() == 335) && this.getFocused() == this.box) {
         this.submit();
         return true;
      } else {
         return super.keyPressed(event);
      }
   }

   public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
      super.extractRenderState(g, mouseX, mouseY, partialTick);
      Font f = this.font;
      g.text(f, "광선 필터 목록", this.left, this.titleY, -1);
      g.text(f, "아이템 id 를 쉼표로 구분", this.left, this.labelY, -5592406);
      g.text(f, "예: diamond, netherite_ingot, ancient_debris", this.left, this.hintY, -7829368);
   }

   public void onClose() {
      kr.girinworld.core.ClientCompat.setScreen(Minecraft.getInstance(), this.parent);
   }
}
