package kr.girinworld.core.features.settings;

import java.util.ArrayList;
import java.util.List;
import kr.girinworld.core.KeyBindings;
import kr.girinworld.core.features.hud.HudUtil;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

final class Ng {
   static final int SCRIM = -1945827572;
   static final int PANEL = -1072951530;
   static final int SIDEBAR = 570425344;
   static final int PANEL_HI = 352321535;
   static final int EDGE = 822083583;
   static final int EDGE_SOFT = 352321535;
   static final int CARD = 352321535;
   static final int CARD_HOVER = 654311423;
   static final int NAV_SEL = 587202559;
   static final int ACCENT = -218103809;
   static final int TEXT_STRONG = -218103809;
   static final int TEXT_BODY = -855638017;
   static final int TEXT_MUTED = -1929379841;
   static final int TEXT_FAINT = 1442840575;
   static final int TOGGLE_W = 24;
   static final int TOGGLE_H = 13;

   private Ng() {
   }

   static int withAlpha(int argb, float a) {
      int src = argb >>> 24 & 0xFF;
      return Math.round(src * clamp01(a)) << 24 | argb & 16777215;
   }

   static int lerpColor(int a, int b, float t) {
      t = clamp01(t);
      int aa = a >>> 24 & 0xFF;
      int ar = a >> 16 & 0xFF;
      int ag = a >> 8 & 0xFF;
      int ab = a & 0xFF;
      int ba = b >>> 24 & 0xFF;
      int br = b >> 16 & 0xFF;
      int bg = b >> 8 & 0xFF;
      int bb = b & 0xFF;
      return Math.round(aa + (ba - aa) * t) << 24 | Math.round(ar + (br - ar) * t) << 16 | Math.round(ag + (bg - ag) * t) << 8 | Math.round(ab + (bb - ab) * t);
   }

   static float clamp01(float v) {
      return v < 0.0F ? 0.0F : (v > 1.0F ? 1.0F : v);
   }

   static float easeOut(float t) {
      t = clamp01(t);
      float u = 1.0F - t;
      return 1.0F - u * u * u;
   }

   static void card(GuiGraphicsExtractor g, int x, int y, int w, int h, int fill) {
      HudUtil.roundedRect(g, x, y, w, h, fill);
   }

   static void cardBordered(GuiGraphicsExtractor g, int x, int y, int w, int h, int fill, int edge) {
      card(g, x, y, w, h, edge);
      card(g, x + 1, y + 1, w - 2, h - 2, fill);
   }

   static void toggle(GuiGraphicsExtractor g, int x, int y, float p) {
      cardBordered(g, x, y, 24, 13, lerpColor(570425344, 822083583, p), lerpColor(352321535, 822083583, p));
      int kx = Math.round(x + 3 + 11.0F * clamp01(p));
      card(g, kx, y + 3, 7, 7, lerpColor(1728053247, -218103809, p));
   }

   static boolean in(double mx, double my, int x, int y, int w, int h) {
      return mx >= x && mx < x + w && my >= y && my < y + h;
   }

   static List<String> wrap(Font f, String s, int maxW, int maxLines) {
      List<String> out = new ArrayList<>();
      String[] words = s.split(" ");
      StringBuilder line = new StringBuilder();

      for (int i = 0; i < words.length; i++) {
         String candidate = line.isEmpty() ? words[i] : line + " " + words[i];
         if (f.width(candidate) > maxW && !line.isEmpty()) {
            if (out.size() == maxLines - 1) {
               StringBuilder rest = new StringBuilder(line);

               for (int k = i; k < words.length; k++) {
                  rest.append(' ').append(words[k]);
               }

               out.add(fit(f, rest.toString(), maxW));
               return out;
            }

            out.add(fit(f, line.toString(), maxW));
            line.setLength(0);
            line.append(words[i]);
         } else {
            line.setLength(0);
            line.append(candidate);
         }
      }

      if (!line.isEmpty()) {
         out.add(fit(f, line.toString(), maxW));
      }

      return out;
   }

   static String fit(Font f, String s, int maxW) {
      if (f.width(s) <= maxW) {
         return s;
      }

      while (s.length() > 1 && f.width(s + "…") > maxW) {
         s = s.substring(0, s.length() - 1);
      }

      return s + "…";
   }

   static String keyLabel(String cfg) {
      return KeyBindings.keyName(cfg);
   }
}
