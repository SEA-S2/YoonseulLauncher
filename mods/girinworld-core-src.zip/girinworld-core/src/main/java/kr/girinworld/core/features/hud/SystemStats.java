package kr.girinworld.core.features.hud;

import com.sun.management.OperatingSystemMXBean;
import java.lang.management.ManagementFactory;
import kr.girinworld.core.Config;

public final class SystemStats {
   private static final long SAMPLE_MS = 1000L;
   private static final double SMOOTH = 0.3;
   private static volatile double cpuAvg = -1.0;
   private static volatile long usedMb;
   private static volatile long maxMb;
   private static volatile boolean workerWanted;
   private static Thread worker;

   private SystemStats() {
   }

   public static void tick() {
      if (!Config.get().hud.system.enabled) {
         workerWanted = false;
      } else {
         Runtime rt = Runtime.getRuntime();
         maxMb = rt.maxMemory() / 1048576L;
         usedMb = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
         ensureWorker();
      }
   }

   private static synchronized void ensureWorker() {
      workerWanted = true;
      if (worker == null || !worker.isAlive()) {
         worker = new Thread(() -> {
            while (workerWanted) {
               double load = readCpu();
               if (load >= 0.0) {
                  double cur = cpuAvg;
                  cpuAvg = cur < 0.0 ? load : cur + (load - cur) * 0.3;
               }

               try {
                  Thread.sleep(1000L);
               } catch (InterruptedException e) {
                  Thread.currentThread().interrupt();
                  return;
               }
            }
         }, "core-sysstats");
         worker.setDaemon(true);
         worker.start();
      }
   }

   private static double readCpu() {
      try {
         if (ManagementFactory.getOperatingSystemMXBean() instanceof OperatingSystemMXBean sun) {
            return sun.getProcessCpuLoad();
         }
      } catch (Throwable var2) {
      }

      return -1.0;
   }

   public static long usedMb() {
      return usedMb;
   }

   public static long maxMb() {
      return maxMb;
   }

   public static int cpuPercent() {
      double v = cpuAvg;
      return v < 0.0 ? -1 : (int)Math.round(v * 100.0);
   }
}
