package kr.girinworld.core.features.whisper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class WhisperStore {
   public static final int MAX_MESSAGES = 200;
   public static final int MAX_ROOMS = 100;
   private final Map<String, WhisperStore.Conversation> rooms = new LinkedHashMap<>();

   public synchronized WhisperStore.Conversation getOrCreate(String key, String displayName) {
      WhisperStore.Conversation c = this.rooms.get(key);
      if (c == null) {
         c = new WhisperStore.Conversation(key, displayName != null ? displayName : key);
         this.rooms.put(key, c);
         this.evictIfOverCap(key);
      } else if (displayName != null) {
         c.displayName = displayName;
      }

      return c;
   }

   private void evictIfOverCap(String keepKey) {
      if (this.rooms.size() > 100) {
         String oldest = null;
         long oldestTime = Long.MAX_VALUE;

         for (WhisperStore.Conversation c : this.rooms.values()) {
            if (!c.key.equals(keepKey) && c.lastActivity < oldestTime) {
               oldestTime = c.lastActivity;
               oldest = c.key;
            }
         }

         if (oldest != null) {
            this.rooms.remove(oldest);
         }
      }
   }

   public synchronized WhisperStore.Conversation get(String key) {
      return this.rooms.get(key);
   }

   public synchronized void add(String key, String displayName, Direction dir, String text, long now, boolean muted) {
      WhisperStore.Conversation c = this.getOrCreate(key, displayName);
      c.messages.add(new WhisperMessage(dir, text, now));
      this.trim(c);
      c.lastActivity = now;
      if (dir == Direction.INCOMING && !muted) {
         c.unread++;
      }
   }

   public synchronized void addSystem(String key, String text, long now) {
      WhisperStore.Conversation c = this.rooms.get(key);
      if (c != null) {
         c.messages.add(new WhisperMessage(Direction.SYSTEM, text, now));
         this.trim(c);
         c.lastActivity = now;
      }
   }

   public synchronized void merge(String fromKey, String toKey, String toDisplay) {
      if (fromKey.equals(toKey)) {
         if (toDisplay != null) {
            WhisperStore.Conversation c = this.rooms.get(toKey);
            if (c != null) {
               c.displayName = toDisplay;
            }
         }
      } else {
         WhisperStore.Conversation from = this.rooms.remove(fromKey);
         WhisperStore.Conversation to = this.rooms.get(toKey);
         if (from == null) {
            if (to != null && toDisplay != null) {
               to.displayName = toDisplay;
            }
         } else if (to == null) {
            from.key = toKey;
            if (toDisplay != null) {
               from.displayName = toDisplay;
            }

            this.rooms.put(toKey, from);
         } else {
            to.messages.addAll(from.messages);
            to.messages.sort(Comparator.comparingLong(WhisperMessage::timeMillis));
            this.trim(to);
            to.unread = to.unread + from.unread;
            to.lastActivity = Math.max(to.lastActivity, from.lastActivity);
            if (toDisplay != null) {
               to.displayName = toDisplay;
            }
         }
      }
   }

   public synchronized List<WhisperStore.Conversation> recent() {
      List<WhisperStore.Conversation> list = new ArrayList<>(this.rooms.values());
      list.sort(Comparator.<WhisperStore.Conversation>comparingLong(c -> c.lastActivity).reversed());
      return list;
   }

   public synchronized int totalUnread() {
      int t = 0;

      for (WhisperStore.Conversation c : this.rooms.values()) {
         t += c.unread;
      }

      return t;
   }

   public synchronized void clearUnread(String key) {
      WhisperStore.Conversation c = this.rooms.get(key);
      if (c != null) {
         c.unread = 0;
      }
   }

   private void trim(WhisperStore.Conversation c) {
      while (c.messages.size() > 200) {
         c.messages.remove(0);
      }
   }

   public static final class Conversation {
      public String key;
      public String displayName;
      public final List<WhisperMessage> messages = new ArrayList<>();
      public int unread;
      public long lastActivity;

      Conversation(String key, String displayName) {
         this.key = key;
         this.displayName = displayName;
      }

      public WhisperMessage last() {
         return this.messages.isEmpty() ? null : this.messages.get(this.messages.size() - 1);
      }
   }
}
