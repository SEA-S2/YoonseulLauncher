package kr.girinworld.core.features.control;

import net.minecraft.client.Minecraft;

public final class ToggleSprintController {
   private static boolean active;
   private static boolean applied;

   private ToggleSprintController() {
   }

   public static boolean isActive() {
      return active;
   }

   public static void toggle() {
      active = !active;
   }

   public static void setActive(boolean on) {
      active = on;
   }

   public static void tick(Minecraft mc) {
      boolean on = active && mc != null && mc.player != null && mc.options != null && mc.screen == null;
      if (on) {
         apply(mc, true);
         applied = true;
      } else if (applied) {
         Minecraft m = Minecraft.getInstance();
         if (m != null && m.options != null) {
            apply(m, false);
         }

         applied = false;
      }
   }

   private static void apply(Minecraft mc, boolean down) {
      KeyHold.hold(mc.options.keyUp::isDown, mc.options.keyUp::setDown, down);
      KeyHold.hold(mc.options.keySprint::isDown, mc.options.keySprint::setDown, down);
   }
}
