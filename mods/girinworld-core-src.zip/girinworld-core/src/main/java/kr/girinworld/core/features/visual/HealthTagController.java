package kr.girinworld.core.features.visual;

import kr.girinworld.core.Config;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityAttachment;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public final class HealthTagController {
   private HealthTagController() {
   }

   public static void apply(Entity entity, EntityRenderState state, float partialTick) {
      Config.HealthTag c = Config.get().healthTag;
      if (c.enabled && entity instanceof LivingEntity living && !(entity instanceof ArmorStand) && state.scoreText == null) {
         Minecraft mc = Minecraft.getInstance();
         if (entity != mc.player && mc.player != null && !entity.isInvisibleTo(mc.player)) {
            boolean player = entity instanceof Player;
            if (player ? c.target != 0 : c.target != 1) {
               if (!(state.distanceToCameraSq > (double)c.distance * c.distance)) {
                  float hp = living.getHealth();
                  if (!(hp <= 0.0F)) {
                     if (state.nameTagAttachment == null) {
                        Vec3 at = entity.getAttachments().getNullable(EntityAttachment.NAME_TAG, 0, entity.getYRot(partialTick));
                        if (at == null) {
                           return;
                        }

                        state.nameTagAttachment = at;
                     }

                     state.scoreText = text(hp, living.getMaxHealth(), living.getAbsorptionAmount());
                  }
               }
            }
         }
      }
   }

   static Component text(float hp, float max, float absorption) {
      int cur = (int)Math.ceil(hp);
      int top = (int)Math.ceil(max);
      float ratio = max > 0.0F ? hp / max : 1.0F;
      ChatFormatting color = ratio > 0.5F ? ChatFormatting.GREEN : (ratio > 0.25F ? ChatFormatting.YELLOW : ChatFormatting.RED);
      String s = "♥ " + cur + (absorption > 0.0F ? "+" + (int)Math.ceil(absorption) : "") + "/" + top;
      return Component.literal(s).withStyle(color);
   }
}
