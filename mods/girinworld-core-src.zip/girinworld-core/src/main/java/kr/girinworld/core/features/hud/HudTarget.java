package kr.girinworld.core.features.hud;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public interface HudTarget {
   String label();

   String moduleId();

   boolean enabled();

   void setEnabled(boolean var1);

   default boolean visibleNow() {
      return true;
   }

   int[] size(Font var1);

   void draw(GuiGraphicsExtractor var1, Font var2, int var3, int var4);

   double x();

   double y();

   void setPos(double var1, double var3);

   double scale();

   void setScale(double var1);

   void resetLayout();
}
