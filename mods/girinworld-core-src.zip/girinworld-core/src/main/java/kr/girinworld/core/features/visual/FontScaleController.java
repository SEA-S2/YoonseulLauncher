package kr.girinworld.core.features.visual;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import kr.girinworld.core.Config;
import kr.girinworld.core.CoreLog;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public final class FontScaleController {
   private static final double MIN = 0.5;
   private static final double MAX = 1.5;
   private static final Set<String> seen = new LinkedHashSet<>();

   private FontScaleController() {
   }

   private static Config.Font cfg() {
      return Config.get().font;
   }

   public static float apply(float size, Identifier location) {
      String id = location == null ? "?" : location.toString();
      synchronized (seen) {
         seen.add(id);
      }

      if (!cfg().enabled) {
         return size;
      }

      double f = scaleOf(id);
      return f == 1.0 ? size : (float)(size * f);
   }

   public static double scaleOf(String fontId) {
      Double v = cfg().scale.get(fontId);
      return v == null ? 1.0 : clamp(v);
   }

   public static void setScale(String fontId, double value) {
      double v = clamp(value);
      if (v == 1.0) {
         cfg().scale.remove(fontId);
      } else {
         cfg().scale.put(fontId, v);
      }
   }

   public static List<String> knownFonts() {
      Set<String> all = new LinkedHashSet<>();
      synchronized (seen) {
         all.addAll(seen);
      }

      all.addAll(cfg().scale.keySet());
      return new ArrayList<>(all);
   }

   public static void applyNow() {
      try {
         Minecraft mc = Minecraft.getInstance();
         if (mc != null) {
            CoreLog.info("font scale: 리소스 리로드 요청");
            mc.reloadResourcePacks();
         }
      } catch (Throwable t) {
         CoreLog.error("font reload failed", t);
      }
   }

   static double clamp(double v) {
      return v < 0.5 ? 0.5 : (v > 1.5 ? 1.5 : v);
   }

   public static double min() {
      return 0.5;
   }

   public static double max() {
      return 1.5;
   }
}
