package kr.girinworld.core.features.timer;

import kr.girinworld.core.features.CoreScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public final class TimerSetupScreen extends CoreScreen {
   static final int[] PALETTE = new int[]{16777215, 5635925, 5609983, 16772693, 12618480, 5636095, 16755251, 16746700, 6750156};
   private static final int SW = 18;
   private static final int SW_GAP = 4;
   private static final int PANEL_W = 220;
   private static final int FIELD_W = 60;
   private static final int FIELD_GAP = 20;
   private final Screen parent;
   private final Timer editing;
   private EditBox nameBox;
   private EditBox hours;
   private EditBox minutes;
   private EditBox seconds;
   private Button modeButton;
   private int colorIndex;
   private boolean stopwatch;
   private int left;
   private int titleY;
   private int nameLabelY;
   private int hmsLabelY;
   private int colorLabelY;
   private int swatchY;
   private long origH;
   private long origM;
   private long origS;
   private boolean resetToZeroNext;

   public TimerSetupScreen(Screen parent) {
      this(parent, null);
   }

   public TimerSetupScreen(Screen parent, Timer editing) {
      super(Component.literal("타이머 설정"));
      this.parent = parent;
      this.editing = editing;
      if (editing != null) {
         this.colorIndex = nearest(editing.color());
         this.stopwatch = !editing.isCountdown();
      }
   }

   protected void init() {
      this.left = this.width / 2 - 110;
      int y = this.height / 2 - 101;
      this.titleY = y;
      y += 13;
      this.nameLabelY = y;
      y += 10;
      int nameBoxY = y;
      y += 28;
      this.hmsLabelY = y;
      y += 10;
      int fieldsY = y;
      y += 28;
      int presetY = y;
      y += 30;
      this.colorLabelY = y;
      y += 10;
      this.swatchY = y;
      y += 28;
      int modeStartY = y;
      y += 26;
      int backY = y;
      this.nameBox = new EditBox(this.font, this.left, nameBoxY, 220, 20, Component.literal(""));
      this.nameBox.setMaxLength(10);
      if (this.editing != null) {
         this.nameBox.setValue(this.editing.name());
      }

      this.addRenderableWidget(this.nameBox);
      this.hours = this.numberField(this.left, fieldsY, 60);
      this.minutes = this.numberField(this.left + 60 + 20, fieldsY, 60);
      this.seconds = this.numberField(this.left + 160, fieldsY, 60);
      if (this.editing != null && this.editing.isCountdown()) {
         long tot = this.editing.durationNanos() / 1000000000L;
         this.hours.setValue(Long.toString(tot / 3600L));
         this.minutes.setValue(Long.toString(tot % 3600L / 60L));
         this.seconds.setValue(Long.toString(tot % 60L));
      }

      this.addRenderableWidget(this.hours);
      this.addRenderableWidget(this.minutes);
      this.addRenderableWidget(this.seconds);
      this.origH = this.parse(this.hours);
      this.origM = this.parse(this.minutes);
      this.origS = this.parse(this.seconds);
      int pbw = 50;
      int pgap = 6;
      this.addRenderableWidget(Button.builder(Component.literal("+17분"), b -> this.addPreset(1020L)).bounds(this.left, presetY, pbw, 20).build());
      this.addRenderableWidget(Button.builder(Component.literal("+1시간"), b -> this.addPreset(3600L)).bounds(this.left + pbw + pgap, presetY, pbw, 20).build());
      this.addRenderableWidget(
         Button.builder(Component.literal("+6시간"), b -> this.addPreset(21600L)).bounds(this.left + 2 * (pbw + pgap), presetY, pbw, 20).build()
      );
      this.addRenderableWidget(Button.builder(Component.literal("리셋"), b -> this.onReset()).bounds(this.left + 3 * (pbw + pgap), presetY, pbw, 20).build());
      int half = 106;
      this.modeButton = Button.builder(this.modeLabel(), b -> this.toggleMode()).bounds(this.left, modeStartY, half, 20).build();
      this.addRenderableWidget(this.modeButton);
      this.addRenderableWidget(
         Button.builder(Component.literal(this.editing == null ? "시작" : "적용"), b -> this.start()).bounds(this.left + half + 8, modeStartY, half, 20).build()
      );
      this.addRenderableWidget(Button.builder(Component.literal("뒤로"), b -> this.onClose()).bounds(this.left, backY, 220, 20).build());
   }

   private EditBox numberField(int x, int y, int w) {
      EditBox box = new EditBox(this.font, x, y, w, 20, Component.literal(""));
      box.setMaxLength(6);
      box.setValue("0");
      return box;
   }

   private void toggleMode() {
      this.stopwatch = !this.stopwatch;
      this.modeButton.setMessage(this.modeLabel());
   }

   private Component modeLabel() {
      return Component.literal(this.stopwatch ? "모드: 스톱워치" : "모드: 타이머");
   }

   private void addPreset(long addSeconds) {
      long total = this.parse(this.hours) * 3600L + this.parse(this.minutes) * 60L + this.parse(this.seconds) + addSeconds;
      this.setFields(total / 3600L, total % 3600L / 60L, total % 60L);
      this.resetToZeroNext = false;
   }

   private void onReset() {
      if (!this.resetToZeroNext) {
         this.setFields(this.origH, this.origM, this.origS);
         if (this.editing != null) {
            this.editing.resetToFullPaused();
         }

         this.resetToZeroNext = true;
      } else {
         this.setFields(0L, 0L, 0L);
         if (this.editing != null) {
            TimerManager.remove(this.editing);
         }

         this.resetToZeroNext = false;
      }
   }

   private void setFields(long h, long m, long s) {
      this.hours.setValue(Long.toString(h));
      this.minutes.setValue(Long.toString(m));
      this.seconds.setValue(Long.toString(s));
   }

   private long parse(EditBox box) {
      try {
         return Math.max(0L, Long.parseLong(box.getValue().trim()));
      } catch (NumberFormatException e) {
         return 0L;
      }
   }

   private void start() {
      int color = PALETTE[this.colorIndex];
      String name = this.nameBox.getValue().trim();
      if (this.stopwatch) {
         TimerManager.add(false, 0L, name, color);
      } else {
         long secs = this.parse(this.hours) * 3600L + this.parse(this.minutes) * 60L + this.parse(this.seconds);
         if (secs <= 0L) {
            return;
         }

         TimerManager.add(true, secs * 1000000000L, name, color);
      }

      if (this.editing != null) {
         TimerManager.remove(this.editing);
      }

      this.onClose();
   }

   private static int nearest(int rgb) {
      rgb &= 16777215;

      for (int i = 0; i < PALETTE.length; i++) {
         if (PALETTE[i] == rgb) {
            return i;
         }
      }

      return 0;
   }

   private int swatchX(int i) {
      return this.left + i * 22;
   }

   public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
      if (event.button() == 0) {
         for (int i = 0; i < PALETTE.length; i++) {
            if (in(event.x(), event.y(), this.swatchX(i), this.swatchY, 18, 18)) {
               this.colorIndex = i;
               return true;
            }
         }
      }

      return super.mouseClicked(event, doubleClick);
   }

   public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
      super.extractRenderState(g, mouseX, mouseY, partialTick);
      Font f = this.font;
      g.text(f, this.editing == null ? "새 타이머" : "타이머 재설정", this.left, this.titleY, -1);
      g.text(f, "이름 (최대 10자)", this.left, this.nameLabelY, -5592406);
      g.text(f, "시", this.left + 30 - f.width("시") / 2, this.hmsLabelY, -5592406);
      g.text(f, "분", this.left + 110 - f.width("분") / 2, this.hmsLabelY, -5592406);
      g.text(f, "초", this.left + 190 - f.width("초") / 2, this.hmsLabelY, -5592406);
      g.text(f, "색상", this.left, this.colorLabelY, -5592406);

      for (int i = 0; i < PALETTE.length; i++) {
         int x = this.swatchX(i);
         g.fill(x, this.swatchY, x + 18, this.swatchY + 18, 0xFF000000 | PALETTE[i]);
         int edge = i == this.colorIndex ? -1 : 1426063360;
         g.fill(x, this.swatchY, x + 18, this.swatchY + 1, edge);
         g.fill(x, this.swatchY + 18 - 1, x + 18, this.swatchY + 18, edge);
         g.fill(x, this.swatchY, x + 1, this.swatchY + 18, edge);
         g.fill(x + 18 - 1, this.swatchY, x + 18, this.swatchY + 18, edge);
         if (i == this.colorIndex) {
            g.fill(x - 1, this.swatchY - 1, x + 18 + 1, this.swatchY, -1);
            g.fill(x - 1, this.swatchY + 18, x + 18 + 1, this.swatchY + 18 + 1, -1);
         }
      }
   }

   private static boolean in(double mx, double my, int x, int y, int w, int h) {
      return mx >= x && mx < x + w && my >= y && my < y + h;
   }

   public void onClose() {
      kr.girinworld.core.ClientCompat.setScreen(Minecraft.getInstance(), this.parent);
   }
}
