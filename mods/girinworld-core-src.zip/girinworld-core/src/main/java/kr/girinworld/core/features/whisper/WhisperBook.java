package kr.girinworld.core.features.whisper;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import kr.girinworld.core.CoreLog;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.BookViewScreen;
import net.minecraft.client.renderer.RenderPipelines;

final class WhisperBook {
   static final int W = 192;
   static final int H = 192;
   static final int INSET_X = 34;
   static final int CONTENT_WIDTH = 112;
   private static final DateTimeFormatter HHMM = DateTimeFormatter.ofPattern("HH:mm");

   private WhisperBook() {
   }

   static void drawAt(GuiGraphicsExtractor graphics, int x, int y) {
      try {
         graphics.blit(RenderPipelines.GUI_TEXTURED, BookViewScreen.BOOK_LOCATION, x, y, 0.0F, 0.0F, 192, 192, 256, 256);
      } catch (Throwable t) {
         CoreLog.error("book background blit failed (continuing without it)", t);
      }
   }

   static String hhmm(long millis) {
      return HHMM.format(Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()));
   }

   static String trimToWidth(Font font, String s, int maxWidth) {
      if (font.width(s) <= maxWidth) {
         return s;
      }

      String ellipsis = "…";
      int limit = maxWidth - font.width(ellipsis);
      StringBuilder sb = new StringBuilder();

      for (int i = 0; i < s.length() && font.width(sb.toString() + s.charAt(i)) <= limit; i++) {
         sb.append(s.charAt(i));
      }

      return sb + ellipsis;
   }
}
