package kr.girinworld.core.features.whisper;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class WhisperParser {
   private static final String SELF = "나";
   private static final char ARROW = '→';
   private static final Pattern WHISPER = Pattern.compile("^(.+?) → (.+?) \\| (.*)$");
   private static final Pattern NAME_REVEAL = Pattern.compile("^(.+?)의 진짜 이름 (\\S+)$");
   private static final Pattern SEND_FAIL = Pattern.compile("^Can't find player with this name! \\((.+)\\)$");

   private WhisperParser() {
   }

   public static WhisperParser.Parsed parse(String raw) {
      if (raw == null) {
         return WhisperParser.Ignored.INSTANCE;
      }

      String s = raw.stripLeading();
      if (s.indexOf(8594) >= 0) {
         Matcher m = WHISPER.matcher(s);
         if (m.matches()) {
            String from = m.group(1);
            String to = m.group(2);
            String text = m.group(3);
            if ("나".equals(to)) {
               return new WhisperParser.Whisper(from, Direction.INCOMING, text);
            }

            if ("나".equals(from)) {
               return new WhisperParser.Whisper(to, Direction.OUTGOING, text);
            }

            return WhisperParser.Ignored.INSTANCE;
         }
      }

      if (s.contains("의 진짜 이름 ")) {
         Matcher m = NAME_REVEAL.matcher(s);
         if (m.matches()) {
            return new WhisperParser.NameReveal(m.group(1), m.group(2));
         }
      }

      if (s.startsWith("Can't find player")) {
         Matcher m = SEND_FAIL.matcher(s);
         if (m.matches()) {
            return new WhisperParser.SendFail(m.group(1));
         }
      }

      return WhisperParser.Ignored.INSTANCE;
   }

   public enum Ignored implements WhisperParser.Parsed {
      INSTANCE;
   }

   public record NameReveal(String korean, String english) implements WhisperParser.Parsed {
   }

   public sealed interface Parsed permits WhisperParser.Whisper, WhisperParser.NameReveal, WhisperParser.SendFail, WhisperParser.Ignored {
   }

   public record SendFail(String attemptedName) implements WhisperParser.Parsed {
   }

   public record Whisper(String partner, Direction direction, String text) implements WhisperParser.Parsed {
   }
}
