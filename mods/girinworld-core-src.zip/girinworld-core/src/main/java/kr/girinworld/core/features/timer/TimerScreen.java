package kr.girinworld.core.features.timer;

import java.util.List;
import kr.girinworld.core.Config;
import kr.girinworld.core.features.CoreScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public final class TimerScreen extends CoreScreen {
   private static final int PANEL_W = 260;
   private static final int ROW_H = 24;
   private final Screen parent;
   private int left;
   private int top;
   private int recentsY;

   public TimerScreen(Screen parent) {
      super(Component.literal("타이머"));
      this.parent = parent;
   }

   private int runY(int i) {
      return this.top + 22 + i * 24;
   }

   protected void init() {
      this.left = this.width / 2 - 130;
      this.top = this.height / 2 - 96;
      int addY = this.runY(4) + 4;
      this.addRenderableWidget(
         Button.builder(Component.literal("＋ 타이머 추가"), b -> Minecraft.getInstance().setScreen(new TimerSetupScreen(this)))
            .bounds(this.left, addY, 260, 20)
            .build()
      );
      this.recentsY = addY + 34;
      int footY = this.recentsY + 30;
      int half = 126;
      this.addRenderableWidget(
         Button.builder(Component.literal("타이머 설정"), b -> Minecraft.getInstance().setScreen(new TimerSettingsScreen(this)))
            .bounds(this.left, footY, half, 20)
            .build()
      );
      this.addRenderableWidget(Button.builder(Component.literal("닫기"), b -> this.onClose()).bounds(this.left + half + 8, footY, half, 20).build());
   }

   private int settingsX() {
      return this.left + 260 - 62;
   }

   private int removeX() {
      return this.left + 260 - 20;
   }

   public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
      if (event.button() == 0) {
         double mx = event.x();
         double my = event.y();
         List<Timer> timers = TimerManager.timers();

         for (int i = 0; i < timers.size() && i < 4; i++) {
            int ry = this.runY(i);
            if (my >= ry && my < ry + 24 - 2 && mx >= this.left && mx < this.left + 260) {
               Timer t = timers.get(i);
               if (mx >= this.removeX()) {
                  TimerManager.remove(t);
               } else if (mx >= this.settingsX()) {
                  Minecraft.getInstance().setScreen(new TimerSetupScreen(this, t));
               } else {
                  t.togglePause();
               }

               return true;
            }
         }

         List<Config.Timer.Recent> recents = TimerManager.recents();
         int rx = this.left;

         for (Config.Timer.Recent r : recents) {
            int w = this.pillW(r);
            if (rx + w > this.left + 260) {
               break;
            }

            if (in(mx, my, rx, this.recentsY, w, 18)) {
               TimerManager.add(r.countdown, r.seconds * 1000000000L, r.name, r.color);
               return true;
            }

            rx += w + 4;
         }
      }

      return super.mouseClicked(event, doubleClick);
   }

   private int pillW(Config.Timer.Recent r) {
      return this.font.width(this.pillLabel(r)) + 14;
   }

   private String pillLabel(Config.Timer.Recent r) {
      return r.name.isEmpty() ? (r.countdown ? TimerHud.format(r.seconds * 1000000000L) : "스톱워치") : r.name;
   }

   public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
      super.extractRenderState(g, mouseX, mouseY, partialTick);
      Font f = this.font;
      g.text(f, "타이머", this.width / 2 - f.width("타이머") / 2, this.top - 16, -1);
      g.text(f, "실행 중 (" + TimerManager.timers().size() + "/4)", this.left, this.top + 10, -5592406);
      List<Timer> timers = TimerManager.timers();

      for (int i = 0; i < 4; i++) {
         int ry = this.runY(i);
         boolean hover = mouseY >= ry && mouseY < ry + 24 - 2 && mouseX >= this.left && mouseX < this.left + 260;
         g.fill(this.left, ry, this.left + 260, ry + 24 - 2, hover && i < timers.size() ? 872415231 : 570425344);
         if (i < timers.size()) {
            Timer t = timers.get(i);
            boolean fin = t.state() == Timer.State.FINISHED;
            int rgb = fin ? 16733525 : t.color() & 16777215;
            g.fill(this.left + 3, ry + 5, this.left + 6, ry + 24 - 7, 0xFF000000 | rgb);
            String nm = t.name().isEmpty() ? "(이름 없음)" : t.name();
            g.text(f, nm, this.left + 12, ry + 3, 0xFF000000 | rgb, false);
            String time = TimerHud.format(t.displayNanos()) + (t.state() == Timer.State.PAUSED ? " ⏸" : "");
            g.text(f, time, this.left + 12, ry + 13, -3158065, false);
            int by = ry + (22 - 9) / 2;
            g.text(f, "설정", this.settingsX(), by, -4204289, false);
            g.text(f, "✕", this.removeX(), by, -548704, false);
         } else {
            g.text(f, "— 비어 있음 —", this.left + 12, ry + 8, -10066330, false);
         }
      }

      g.text(f, "최근 타이머", this.left, this.recentsY - 12, -5592406);
      List<Config.Timer.Recent> recents = TimerManager.recents();
      if (recents.isEmpty()) {
         g.text(f, "최근 사용한 타이머가 없습니다", this.left, this.recentsY + 4, -10066330, false);
      }

      int rx = this.left;
      Config.Timer.Recent hovered = null;

      for (Config.Timer.Recent r : recents) {
         int w = this.pillW(r);
         if (rx + w > this.left + 260) {
            break;
         }

         boolean hov = in(mouseX, mouseY, rx, this.recentsY, w, 18);
         g.fill(rx, this.recentsY, rx + w, this.recentsY + 18, hov ? 1090519039 : 687865855);
         g.fill(rx, this.recentsY, rx + 3, this.recentsY + 18, 0xFF000000 | r.color & 16777215);
         g.text(f, this.pillLabel(r), rx + 7, this.recentsY + 5, -1118482, false);
         if (hov) {
            hovered = r;
         }

         rx += w + 4;
      }

      if (hovered != null) {
         String tip = (hovered.name.isEmpty() ? "(이름 없음)" : hovered.name)
            + " · "
            + (hovered.countdown ? TimerHud.format(hovered.seconds * 1000000000L) : "스톱워치");
         int tw = f.width(tip) + 8;
         int tx = Math.min(mouseX + 8, this.width - tw - 2);
         int ty = mouseY - 14;
         g.fill(tx, ty, tx + tw, ty + 12, -268435456);
         g.text(f, tip, tx + 4, ty + 2, -1, false);
      }
   }

   private static boolean in(double mx, double my, int x, int y, int w, int h) {
      return mx >= x && mx < x + w && my >= y && my < y + h;
   }

   public void onClose() {
      Minecraft.getInstance().setScreen(this.parent);
   }
}
