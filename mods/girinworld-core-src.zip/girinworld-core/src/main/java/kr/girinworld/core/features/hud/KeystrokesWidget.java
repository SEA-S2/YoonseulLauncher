package kr.girinworld.core.features.hud;

import java.util.ArrayList;
import java.util.List;
import kr.girinworld.core.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.joml.Matrix3x2fStack;

final class KeystrokesWidget extends Widget {
   private static final int BOX = 16;
   private static final int GAP = 2;
   private static final int W = 52;
   private static final int BAR_H = 12;
   private static final int MOUSE_H = 20;
   private static final int MOUSE_W = 25;

   @Override
   protected Config.Hud.Elem cfg(Config.Hud hud) {
      return hud.keystrokes;
   }

   private Config.Hud.Keystrokes ks() {
      return Config.get().hud.keystrokes;
   }

   @Override
   public String label() {
      return "키입력";
   }

   @Override
   public String moduleId() {
      return "hud_keystrokes";
   }

   private List<KeystrokesWidget.Row> rows() {
      Config.Hud.Keystrokes c = this.ks();
      List<KeystrokesWidget.Row> out = new ArrayList<>();
      if (c.wasd) {
         out.add(KeystrokesWidget.Row.WASD);
      }

      if (c.mouse) {
         out.add(KeystrokesWidget.Row.MOUSE);
      }

      if (c.space) {
         out.add(KeystrokesWidget.Row.SPACE);
      }

      if (c.sneak) {
         out.add(KeystrokesWidget.Row.SNEAK);
      }

      if (c.sprint) {
         out.add(KeystrokesWidget.Row.SPRINT);
      }

      return out;
   }

   private static int rowH(KeystrokesWidget.Row r) {
      return switch (r) {
         case WASD -> 34;
         case MOUSE -> 20;
         default -> 12;
      };
   }

   @Override
   public int[] size(Font font) {
      List<KeystrokesWidget.Row> rows = this.rows();
      if (rows.isEmpty()) {
         return new int[]{0, 0};
      }

      int h = -2;

      for (KeystrokesWidget.Row r : rows) {
         h += rowH(r) + 2;
      }

      float s = this.drawScale();
      return new int[]{Math.round(52.0F * s), Math.round(h * s)};
   }

   private static boolean blocked(Minecraft mc) {
      return mc == null || mc.options == null || mc.screen != null || mc.player == null;
   }

   @Override
   public void draw(GuiGraphicsExtractor graphics, Font font, int x, int y) {
      Minecraft mc = Minecraft.getInstance();
      List<KeystrokesWidget.Row> rows = this.rows();
      if (!rows.isEmpty()) {
         boolean off = blocked(mc);
         Options o = mc == null ? null : mc.options;
         int[] size = this.size(font);
         HudUtil.background(graphics, this.cfg(), x, y, size[0], size[1]);
         Matrix3x2fStack pose = graphics.pose();
         pose.pushMatrix();
         pose.translate(x, y);
         float s = this.drawScale();
         if (s != 1.0F) {
            pose.scale(s);
         }

         int cy = 0;

         for (KeystrokesWidget.Row r : rows) {
            switch (r) {
               case WASD:
                  this.key(graphics, font, 18, cy, 16, 16, "W", !off && o.keyUp.isDown());
                  int y2 = cy + 16 + 2;
                  this.key(graphics, font, 0, y2, 16, 16, "A", !off && o.keyLeft.isDown());
                  this.key(graphics, font, 18, y2, 16, 16, "S", !off && o.keyDown.isDown());
                  this.key(graphics, font, 36, y2, 16, 16, "D", !off && o.keyRight.isDown());
                  break;
               case MOUSE:
                  this.mouse(graphics, font, 0, cy, "LMB", 0, !off && o.keyAttack.isDown());
                  this.mouse(graphics, font, 27, cy, "RMB", 1, !off && o.keyUse.isDown());
                  break;
               case SPACE:
                  this.key(graphics, font, 0, cy, 52, 12, "SPACE", !off && o.keyJump.isDown());
                  break;
               case SNEAK:
                  this.key(graphics, font, 0, cy, 52, 12, "웅크리기", !off && o.keyShift.isDown());
                  break;
               case SPRINT:
                  this.key(graphics, font, 0, cy, 52, 12, "달리기", !off && mc.player.isSprinting());
            }

            cy += rowH(r) + 2;
         }

         pose.popMatrix();
      }
   }

   private void mouse(GuiGraphicsExtractor g, Font font, int x, int y, String label, int button, boolean pressed) {
      if (!this.ks().cps) {
         this.key(g, font, x, y, 25, 20, label, pressed);
      } else {
         this.box(g, x, y, 25, 20, pressed);
         int fg = this.fg(pressed);
         text(g, font, label, x, y + 2, 25, fg);
         text(g, font, CpsCounter.cps(button) + " CPS", x, y + 11, 25, fg);
      }
   }

   private void key(GuiGraphicsExtractor g, Font font, int x, int y, int w, int h, String label, boolean pressed) {
      this.box(g, x, y, w, h, pressed);
      text(g, font, label, x, y + (h - 9) / 2 + 1, w, this.fg(pressed));
   }

   private void box(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean pressed) {
      Config.Hud.Keystrokes c = this.ks();
      int rgb = (pressed ? c.pressColor : c.bgColor) & 16777215;
      HudUtil.roundedRect(g, x, y, w, h, this.alpha() << 24 | rgb);
   }

   private int fg(boolean pressed) {
      Config.Hud.Keystrokes c = this.ks();
      return 0xFF000000 | (pressed ? c.bgColor : c.textColor) & 16777215;
   }

   private static void text(GuiGraphicsExtractor g, Font font, String s, int x, int y, int w, int argb) {
      g.text(font, s, x + (w - font.width(s)) / 2, y, argb);
   }

   private enum Row {
      WASD,
      MOUSE,
      SPACE,
      SNEAK,
      SPRINT;
   }
}
