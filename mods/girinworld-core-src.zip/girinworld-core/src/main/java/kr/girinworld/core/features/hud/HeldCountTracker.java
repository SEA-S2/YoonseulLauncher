package kr.girinworld.core.features.hud;

import kr.girinworld.core.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class HeldCountTracker {
   private static final long DELTA_NANOS = 1500000000L;
   private static Item item;
   private static int total;
   private static int delta;
   private static long deltaAt;

   private HeldCountTracker() {
   }

   public static void tick() {
      Minecraft mc = Minecraft.getInstance();
      if (mc != null && mc.player != null && mc.level != null) {
         ItemStack held = mc.player.getInventory().getSelectedItem();
         if (held != null && !held.isEmpty()) {
            Item now = held.getItem();
            int sum = count(mc.player.getInventory(), now);
            if (now != item) {
               item = now;
               delta = 0;
            } else if (sum != total) {
               delta = sum - total;
               deltaAt = System.nanoTime();
            }

            total = sum;
         } else {
            item = null;
            total = 0;
         }
      } else {
         item = null;
         total = 0;
      }
   }

   private static int count(Inventory inv, Item want) {
      int sum = 0;

      for (int i = 0; i < inv.getContainerSize(); i++) {
         ItemStack s = inv.getItem(i);
         if (!s.isEmpty() && s.getItem() == want) {
            sum += s.getCount();
         }
      }

      return sum;
   }

   public static boolean hasItem() {
      return item != null;
   }

   public static int total() {
      return total;
   }

   public static int recentDelta() {
      if (delta != 0 && Config.get().hud.heldCount.showDelta) {
         return System.nanoTime() - deltaAt < 1500000000L ? delta : 0;
      } else {
         return 0;
      }
   }
}
