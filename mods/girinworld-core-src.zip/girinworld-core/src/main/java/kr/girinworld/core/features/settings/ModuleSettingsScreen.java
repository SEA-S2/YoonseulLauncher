package kr.girinworld.core.features.settings;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.InputConstants.Key;
import com.mojang.blaze3d.platform.InputConstants.Type;
import java.util.ArrayList;
import java.util.List;
import kr.girinworld.core.Config;
import kr.girinworld.core.KeyBindings;
import kr.girinworld.core.KeyMods;
import kr.girinworld.core.features.CoreScreen;
import kr.girinworld.core.features.camera.PhotoModeController;
import kr.girinworld.core.features.control.ToggleSprintController;
import kr.girinworld.core.features.hud.HudLayoutScreen;
import kr.girinworld.core.features.macro.MacroController;
import kr.girinworld.core.features.macro.MacroEditScreen;
import kr.girinworld.core.features.social.AddFriendScreen;
import kr.girinworld.core.features.social.SocialClient;
import kr.girinworld.core.features.social.SocialData;
import kr.girinworld.core.features.visual.BrightnessController;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public final class ModuleSettingsScreen extends CoreScreen {
   private static final String[] SECTIONS = new String[]{"소셜", "모드", "단축어", "스킨", "치장", "설정"};
   private static final boolean[] READY = new boolean[]{false, true, true, false, false, true};
   private static final int SOCIAL = 0;
   private static final int MOD = 1;
   public static final int MACRO = 2;
   private static final int SET = 5;
   private static final int SOC_HEADER_H = 15;
   private static final int SOC_ITEM_H = 19;
   private static final int SOC_BTN_H = 14;
   private static final int PANEL_W = 420;
   private static final int SB = 104;
   private static final int PAD = 12;
   private static final int GAP = 8;
   private static final int CARD_H = 58;
   private static final int CARD_W = 142;
   private static final int NAV_H = 24;
   private static final int MARGIN = 18;
   private static final long OPEN_NANOS = 190000000L;
   private static final String L_ACTIVE = "사용 중";
   private static final int FAV_X = 10;
   private static final int GLFW_ESC = 256;
   private static final int GLFW_BACKSPACE = 259;
   private static final int GLFW_DELETE = 261;
   private static final int WARN_COLOR = -34953;
   private static final int MODAL_W = 244;
   private static final int MODAL_HEAD = 66;
   private static final int MODAL_FOOT = 34;
   private static final int OPT_ROW = 22;
   private static final int OPT_SLIDER_ROW = 32;
   private static final int SWATCH = 12;
   private static final int MAC_ROW = 22;
   private final List<ClientModule> modules = ModuleRegistry.all();
   private final List<String> cats = new ArrayList<>();
   private final float[] favP;
   private final float[] hoverP;
   private final float[] navHoverP = new float[SECTIONS.length];
   private final float[] chipHoverP;
   private final SocialData social = new SocialData();
   private float socScroll;
   private float socMaxScroll;
   private float macScroll;
   private float macMaxScroll;
   private boolean awaitKey;
   private String keyConflict;
   private int section = 1;
   private int selectedCat;
   private int[] filtered = new int[0];
   private int modal = -1;
   private List<Opt> modalOpts = List.of();
   private List<String> modalDesc = List.of();
   private int modalDescFor = -1;
   private float modalScroll;
   private int draggingOpt = -1;
   private float scroll;
   private float maxScroll;
   private long openAt;
   private long lastFrame;
   private float openP;
   private long resetToastUntil;

   public ModuleSettingsScreen() {
      super(Component.literal("클라이언트 허브"));
      int n = this.modules.size();
      this.favP = new float[n];
      this.hoverP = new float[n];
      this.cats.add("사용 중");
      this.cats.add("전체");

      for (int i = 0; i < n; i++) {
         this.favP[i] = this.modules.get(i).isInQuick() ? 1.0F : 0.0F;
         if (!this.cats.contains(this.modules.get(i).category)) {
            this.cats.add(this.modules.get(i).category);
         }
      }

      this.chipHoverP = new float[this.cats.size()];
      this.selectedCat = 1;
      this.rebuildFilter();
   }

   public ModuleSettingsScreen(int section) {
      this();
      this.section = section;
   }

   public ModuleSettingsScreen(String moduleId) {
      this();

      for (int i = 0; i < this.modules.size(); i++) {
         if (this.modules.get(i).id.equals(moduleId)) {
            this.openModal(i);
            return;
         }
      }
   }

   private void rebuildFilter() {
      List<Integer> f = new ArrayList<>();
      String cat = this.cats.get(this.selectedCat);

      for (int i = 0; i < this.modules.size(); i++) {
         ClientModule m = this.modules.get(i);

         boolean show = switch (cat) {
            case "사용 중" -> this.isActive(m);
            case "전체" -> true;
            default -> m.category.equals(cat);
         };
         if (show) {
            f.add(i);
         }
      }

      this.filtered = new int[f.size()];

      for (int i = 0; i < f.size(); i++) {
         this.filtered[i] = f.get(i);
      }

      this.scroll = 0.0F;
   }

   private int panelH() {
      return Math.min(this.height - 36, 264);
   }

   private int panelX() {
      return (this.width - 420) / 2;
   }

   private int panelY() {
      return (this.height - this.panelH()) / 2 + Math.round((1.0F - this.openP) * 12.0F);
   }

   private int contentX() {
      return this.panelX() + 104;
   }

   private int contentW() {
      return 316;
   }

   private int navY(int k) {
      return this.panelY() + 34 + k * 24;
   }

   private int chipW(Font f, int k) {
      return f.width(this.cats.get(k)) + 14;
   }

   private int chipX(Font f, int k) {
      int x = this.contentX() + 12;

      for (int j = 0; j < k; j++) {
         x += this.chipW(f, j) + 5;
      }

      return x;
   }

   private int gridTop() {
      return this.panelY() + 38;
   }

   private int gridBottom() {
      return this.panelY() + this.panelH() - 12;
   }

   private int cardX(int k) {
      return this.contentX() + 12 + k % 2 * 150;
   }

   private int cardY(int k) {
      return this.gridTop() - Math.round(this.scroll) + k / 2 * 66;
   }

   public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
      super.extractRenderState(g, mouseX, mouseY, partialTick);
      this.tickAnim(mouseX, mouseY);
      Font f = this.font;
      int px = this.panelX();
      int py = this.panelY();
      int ph = this.panelH();
      g.fill(0, 0, this.width, this.height, Ng.withAlpha(-1945827572, this.openP));
      Ng.cardBordered(g, px, py, 420, ph, -1072951530, 822083583);
      g.fill(px + 3, py + 1, px + 420 - 3, py + 2, 352321535);
      g.fill(px + 1, py + 3, px + 104, py + ph - 3, 570425344);
      g.fill(px + 104, py + 6, px + 104 + 1, py + ph - 6, 352321535);
      g.text(f, "클라이언트 허브", px + 12, py + 13, -218103809, false);

      for (int k = 0; k < SECTIONS.length; k++) {
         this.drawNav(g, f, k);
      }

      g.text(f, "RShift 닫기", px + 12, py + ph - 15, 1442840575, false);
      if (this.section == 1) {
         this.drawModTab(g, f);
      } else if (this.section == 2) {
         this.drawMacroTab(g, f, mouseX, mouseY);
      } else if (this.section == 5) {
         this.drawSettingsTab(g, f, mouseX, mouseY);
      } else if (this.section == 0 && READY[0]) {
         this.drawSocialTab(g, f, mouseX, mouseY);
      } else {
         String msg = SECTIONS[this.section] + " · 준비 중";
         g.centeredText(f, msg, this.contentX() + this.contentW() / 2, py + ph / 2 - 8, -1929379841);
         g.centeredText(f, "곧 추가됩니다", this.contentX() + this.contentW() / 2, py + ph / 2 + 6, 1442840575);
      }

      if (this.modal >= 0) {
         this.drawModal(g, f, mouseX, mouseY);
      }
   }

   private int setX() {
      return this.contentX() + 12;
   }

   private int setW() {
      return this.contentW() - 24;
   }

   private int hudBtnY() {
      return this.panelY() + 56;
   }

   private int resetBtnY() {
      return this.panelY() + 88;
   }

   private void drawSettingsTab(GuiGraphicsExtractor g, Font f, int mouseX, int mouseY) {
      int cx = this.contentX();
      int sx = this.setX();
      int sw = this.setW();
      g.text(f, "설정", cx + 12, this.panelY() + 14, -218103809, false);
      g.fill(cx + 12, this.panelY() + 27, cx + this.contentW() - 12, this.panelY() + 28, 352321535);
      g.text(f, "모듈별 설정은 각 모드 카드를 눌러 조절하세요", sx, this.panelY() + 40, 1442840575, false);
      int hy = this.hudBtnY();
      boolean hudHov = Ng.in(mouseX, mouseY, sx, hy, sw, 20);
      Ng.cardBordered(g, sx, hy, sw, 20, hudHov ? 654311423 : 352321535, 352321535);
      g.centeredText(f, "HUD 배치 변경", sx + sw / 2, hy + 6, -855638017);
      int by = this.resetBtnY();
      boolean hov = Ng.in(mouseX, mouseY, sx, by, sw, 20);
      Ng.cardBordered(g, sx, by, sw, 20, hov ? 654311423 : 352321535, 352321535);
      g.centeredText(f, "설정 초기화", sx + sw / 2, by + 6, -855638017);
      if (System.currentTimeMillis() < this.resetToastUntil) {
         g.centeredText(f, "✓ 기본값으로 초기화되었습니다", cx + this.contentW() / 2, by + 26, -218103809);
      } else {
         g.centeredText(f, "모든 모드 설정을 기본값으로 되돌립니다", cx + this.contentW() / 2, by + 26, 1442840575);
      }
   }

   private int macTop() {
      return this.panelY() + 34;
   }

   private int macAddY() {
      return this.panelY() + this.panelH() - 12 - 20;
   }

   private int macBottom() {
      return this.macAddY() - 6;
   }

   private int macRowY(int i) {
      return this.macTop() - Math.round(this.macScroll) + i * 22;
   }

   private int macEditX() {
      return this.setX() + this.setW() - 62;
   }

   private int macRemoveX() {
      return this.setX() + this.setW() - 18;
   }

   private void drawMacroTab(GuiGraphicsExtractor g, Font f, int mouseX, int mouseY) {
      int cx = this.contentX();
      List<Config.Macro.Entry> list = MacroController.list();
      g.text(f, "단축어", cx + 12, this.panelY() + 14, -218103809, false);
      String count = list.size() + " / 30";
      g.text(f, count, cx + this.contentW() - 12 - f.width(count), this.panelY() + 14, 1442840575, false);
      g.fill(cx + 12, this.panelY() + 27, cx + this.contentW() - 12, this.panelY() + 28, 352321535);
      int top = this.macTop();
      int bottom = this.macBottom();
      if (list.isEmpty()) {
         g.centeredText(f, "저장된 단축어가 없습니다", cx + this.contentW() / 2, (top + bottom) / 2 - 4, -1929379841);
         this.macMaxScroll = 0.0F;
      } else {
         this.macMaxScroll = Math.max(0, list.size() * 22 - (bottom - top));
         this.macScroll = clamp(this.macScroll, 0.0F, this.macMaxScroll);
         g.enableScissor(cx, top, cx + this.contentW(), bottom);

         for (int i = 0; i < list.size(); i++) {
            int y = this.macRowY(i);
            if (y + 22 > top && y < bottom) {
               this.drawMacroRow(g, f, list.get(i), y, mouseX, mouseY, mouseY >= top && mouseY < bottom);
            }
         }

         g.disableScissor();
         if (this.macMaxScroll > 0.0F) {
            int trackH = bottom - top;
            int thumbH = Math.max(16, Math.round(trackH * ((float)trackH / (list.size() * 22))));
            int ty = top + Math.round((trackH - thumbH) * (this.macScroll / this.macMaxScroll));
            g.fill(cx + this.contentW() - 4, ty, cx + this.contentW() - 2, ty + thumbH, 822083583);
         }
      }

      boolean full = list.size() >= 30;
      int ay = this.macAddY();
      boolean hov = !full && Ng.in(mouseX, mouseY, this.setX(), ay, this.setW(), 20);
      Ng.cardBordered(g, this.setX(), ay, this.setW(), 20, hov ? 654311423 : 352321535, 352321535);
      g.centeredText(f, full ? "가득 참 (최대 30개)" : "＋ 단축어 추가", this.setX() + this.setW() / 2, ay + 6, full ? 1442840575 : -855638017);
   }

   private void drawMacroRow(GuiGraphicsExtractor g, Font f, Config.Macro.Entry e, int y, int mouseX, int mouseY, boolean inList) {
      int x = this.setX();
      int w = this.setW();
      boolean hov = inList && Ng.in(mouseX, mouseY, x, y, w, 20);
      Ng.card(g, x, y, w, 20, hov ? 654311423 : 352321535);
      String name = e.name.isBlank() ? e.text : e.name;
      Key k = MacroController.parse(e.key);
      String badge = k == null ? "키 미지정" : KeyMods.prefix(e.mods) + k.getDisplayName().getString();
      int badgeX = this.macEditX() - 8 - f.width(badge);
      g.text(f, badge, badgeX, y + 6, k == null ? 1442840575 : -218103809, false);
      int textW = Math.max(20, badgeX - 8 - (x + 7));
      g.text(f, Ng.fit(f, name, textW), x + 7, y + 1, -218103809, false);
      g.text(f, Ng.fit(f, e.text, textW), x + 7, y + 10, -1929379841, false);
      g.text(f, "편집", this.macEditX(), y + 6, -855638017, false);
      g.text(f, "✕", this.macRemoveX(), y + 6, -1929379841, false);
   }

   private boolean handleMacroClick(double mx, double my) {
      List<Config.Macro.Entry> list = MacroController.list();
      if (Ng.in(mx, my, this.setX(), this.macAddY(), this.setW(), 20)) {
         if (list.size() < 30) {
            Minecraft.getInstance().setScreen(new MacroEditScreen(this, -1));
         }

         return true;
      } else if (!(my < this.macTop()) && !(my >= this.macBottom())) {
         for (int i = 0; i < list.size(); i++) {
            int y = this.macRowY(i);
            if (!(my < y) && !(my >= y + 22 - 2) && !(mx < this.setX()) && !(mx >= this.setX() + this.setW())) {
               if (mx >= this.macRemoveX()) {
                  list.remove(i);
                  Config.get().save();
               } else if (mx >= this.macEditX()) {
                  Minecraft.getInstance().setScreen(new MacroEditScreen(this, i));
               } else {
                  MacroController.run(list.get(i));
                  Minecraft.getInstance().setScreen(null);
               }

               return true;
            }
         }

         return true;
      } else {
         return true;
      }
   }

   private void drawModTab(GuiGraphicsExtractor g, Font f) {
      int py = this.panelY();

      for (int k = 0; k < this.cats.size(); k++) {
         boolean sel = k == this.selectedCat;
         int cw = this.chipW(f, k);
         int cxp = this.chipX(f, k);
         Ng.card(g, cxp, py + 11, cw, 15, sel ? 587202559 : Ng.lerpColor(16777215, 352321535, this.chipHoverP[k]));
         g.text(f, this.cats.get(k), cxp + 7, py + 15, sel ? -218103809 : -1929379841, false);
      }

      g.fill(this.contentX() + 12, py + 32, this.contentX() + this.contentW() - 12, py + 33, 352321535);
      if (this.filtered.length == 0) {
         g.centeredText(f, "지금 켜져 있는 모드가 없습니다", this.contentX() + this.contentW() / 2, this.gridTop() + 12, 1442840575);
         this.maxScroll = 0.0F;
      } else {
         int rows = (this.filtered.length + 1) / 2;
         this.maxScroll = Math.max(0, rows * 66 - 8 - (this.gridBottom() - this.gridTop()));
         this.scroll = clamp(this.scroll, 0.0F, this.maxScroll);
         g.enableScissor(this.contentX(), this.gridTop(), this.contentX() + this.contentW(), this.gridBottom());

         for (int k = 0; k < this.filtered.length; k++) {
            int cy = this.cardY(k);
            if (cy + 58 > this.gridTop() && cy < this.gridBottom()) {
               this.drawCard(g, f, k);
            }
         }

         g.disableScissor();
         if (this.maxScroll > 0.0F) {
            int trackH = this.gridBottom() - this.gridTop();
            int thumbH = Math.max(16, Math.round(trackH * ((float)trackH / (rows * 66))));
            int ty = this.gridTop() + Math.round((trackH - thumbH) * (this.scroll / this.maxScroll));
            g.fill(this.contentX() + this.contentW() - 4, ty, this.contentX() + this.contentW() - 2, ty + thumbH, 822083583);
         }
      }
   }

   private void drawCard(GuiGraphicsExtractor g, Font f, int k) {
      int i = this.filtered[k];
      ClientModule m = this.modules.get(i);
      int x = this.cardX(k);
      int y = this.cardY(k);
      Ng.cardBordered(g, x, y, 142, 58, Ng.lerpColor(352321535, 654311423, this.hoverP[i]), 352321535);
      if (this.isActive(m)) {
         g.fill(x + 2, y + 8, x + 4, y + 58 - 8, -218103809);
      }

      g.text(f, m.name, x + 10, y + 8, -218103809, false);
      String key = m.keyDisplay();
      if (!key.isEmpty()) {
         g.text(f, "[" + key + "]", x + 10 + f.width(m.name) + 6, y + 8, 1442840575, false);
      }

      List<String> lines = Ng.wrap(f, m.desc, 122, 2);

      for (int li = 0; li < lines.size(); li++) {
         g.text(f, lines.get(li), x + 10, y + 21 + li * 9, -1929379841, false);
      }

      int by = y + 58 - 17;
      if (m.quickable()) {
         g.text(f, "★", x + 10, by + 3, Ng.lerpColor(1442840575, -218103809, this.favP[i]), false);
      }

      String hint = "설정 ›";
      g.text(f, hint, x + 142 - 10 - f.width(hint), by + 3, Ng.lerpColor(1442840575, -218103809, this.hoverP[i]), false);
   }

   private int socActionY() {
      return this.panelY() + 30;
   }

   private int socBannerY() {
      return this.panelY() + 50;
   }

   private boolean socBannerShown() {
      SocialData.Snapshot s = this.social.get();
      return s.state == SocialData.State.OK && s.prefsKnown && (!s.friendsEnabled || !s.acceptInvites);
   }

   private int socBodyTop() {
      return this.panelY() + (this.socBannerShown() ? 70 : 48);
   }

   private int socBodyBottom() {
      return this.panelY() + this.panelH() - 12 - 10;
   }

   private int socAddX() {
      return this.contentX() + 12;
   }

   private int socRefreshX() {
      return this.contentX() + this.contentW() - 12 - 52;
   }

   private int socEnableX() {
      return this.contentX() + this.contentW() - 12 - 44;
   }

   private int rowH(ModuleSettingsScreen.RT t) {
      return t == ModuleSettingsScreen.RT.ITEM ? 19 : 15;
   }

   private List<ModuleSettingsScreen.SRow> buildRows(SocialData.Snapshot s) {
      List<ModuleSettingsScreen.SRow> rows = new ArrayList<>();
      this.addSection(rows, "받은 요청", s.incoming, "incoming", "받은 친구 요청이 없어요");
      this.addSection(rows, "보낸 요청", s.outgoing, "outgoing", "보낸 친구 요청이 없어요");
      this.addSection(rows, "친구", s.friends, "friend", "아직 친구가 없어요 — 친구 추가로 요청을 보내보세요");
      return rows;
   }

   private void addSection(List<ModuleSettingsScreen.SRow> rows, String title, List<SocialData.Friend> people, String kind, String emptyMsg) {
      rows.add(new ModuleSettingsScreen.SRow(ModuleSettingsScreen.RT.HEADER, title + (people.isEmpty() ? "" : " · " + people.size()), null, null));
      if (people.isEmpty()) {
         rows.add(new ModuleSettingsScreen.SRow(ModuleSettingsScreen.RT.EMPTY, emptyMsg, null, null));
      } else {
         for (SocialData.Friend fr : people) {
            rows.add(new ModuleSettingsScreen.SRow(ModuleSettingsScreen.RT.ITEM, null, fr, kind));
         }
      }
   }

   private List<ModuleSettingsScreen.SBtn> itemButtons(ModuleSettingsScreen.SRow r, int y) {
      List<ModuleSettingsScreen.SBtn> out = new ArrayList<>();

      String[][] defs = switch (r.kind) {
         case "incoming" -> new String[][]{{"수락", "accept"}, {"거절", "remove"}};
         case "outgoing" -> new String[][]{{"취소", "remove"}};
         default -> new String[][]{{"삭제", "remove"}};
      };
      int right = this.contentX() + this.contentW() - 12;

      for (int i = defs.length - 1; i >= 0; i--) {
         int w = this.font.width(defs[i][0]) + 10;
         right -= w;
         out.add(0, new ModuleSettingsScreen.SBtn(defs[i][0], defs[i][1], r.friend.profileId(), right, y + 2, w, 14));
         right -= 4;
      }

      return out;
   }

   private void drawSocialTab(GuiGraphicsExtractor g, Font f, int mouseX, int mouseY) {
      int cx = this.contentX();
      int py = this.panelY();
      g.text(f, "소셜", cx + 12, py + 13, -218103809, false);
      g.fill(cx + 12, py + 26, cx + this.contentW() - 12, py + 27, 352321535);
      this.socButton(g, f, this.socAddX(), this.socActionY(), 76, "＋ 친구 추가", mouseX, mouseY);
      this.socButton(g, f, this.socRefreshX(), this.socActionY(), 52, "새로고침", mouseX, mouseY);
      if (this.socBannerShown()) {
         g.text(f, "친구 기능이 꺼져 있어요", cx + 12, this.socBannerY() + 4, -1929379841, false);
         this.socButton(g, f, this.socEnableX(), this.socBannerY(), 44, "켜기", mouseX, mouseY);
      }

      SocialData.Snapshot s = this.social.get();
      int top = this.socBodyTop();
      int bottom = this.socBodyBottom();
      if (s.state != SocialData.State.OK) {
         String msg = switch (s.state) {
            case LOADING -> "불러오는 중…";
            case ERROR -> s.message.isEmpty() ? "친구 정보를 불러오지 못했어요." : s.message;
            default -> "새로고침을 눌러 친구 목록을 불러오세요.";
         };
         g.centeredText(f, Ng.fit(f, msg, this.contentW() - 24), cx + this.contentW() / 2, (top + bottom) / 2, -1929379841);
      } else {
         this.drawSocialList(g, f, s, top, bottom, mouseX, mouseY);
      }

      String toast = this.social.toast();
      if (!toast.isEmpty()) {
         g.centeredText(f, Ng.fit(f, toast, this.contentW() - 24), cx + this.contentW() / 2, py + this.panelH() - 12 - 7, -218103809);
      }
   }

   private void drawSocialList(GuiGraphicsExtractor g, Font f, SocialData.Snapshot s, int top, int bottom, int mouseX, int mouseY) {
      int cx = this.contentX();
      List<ModuleSettingsScreen.SRow> rows = this.buildRows(s);
      int total = 0;

      for (ModuleSettingsScreen.SRow r : rows) {
         total += this.rowH(r.type);
      }

      this.socMaxScroll = Math.max(0, total - (bottom - top));
      this.socScroll = clamp(this.socScroll, 0.0F, this.socMaxScroll);
      g.enableScissor(cx, top, cx + this.contentW(), bottom);
      int y = top - Math.round(this.socScroll);

      for (ModuleSettingsScreen.SRow r : rows) {
         int h = this.rowH(r.type);
         if (y + h > top && y < bottom) {
            this.drawSRow(g, f, r, y, mouseX, mouseY);
         }

         y += h;
      }

      g.disableScissor();
      if (this.socMaxScroll > 0.0F) {
         int trackH = bottom - top;
         int thumbH = Math.max(16, Math.round(trackH * ((float)trackH / total)));
         int ty = top + Math.round((trackH - thumbH) * (this.socScroll / this.socMaxScroll));
         g.fill(cx + this.contentW() - 4, ty, cx + this.contentW() - 2, ty + thumbH, 822083583);
      }
   }

   private void drawSRow(GuiGraphicsExtractor g, Font f, ModuleSettingsScreen.SRow r, int y, int mouseX, int mouseY) {
      int cx = this.contentX();
      if (r.type == ModuleSettingsScreen.RT.HEADER) {
         g.text(f, r.text, cx + 12, y + 5, -1929379841, false);
      } else if (r.type == ModuleSettingsScreen.RT.EMPTY) {
         g.text(f, Ng.fit(f, r.text, this.contentW() - 24), cx + 12, y + 3, 1442840575, false);
      } else {
         List<ModuleSettingsScreen.SBtn> btns = this.itemButtons(r, y);
         int rightLimit = btns.isEmpty() ? cx + this.contentW() - 12 : btns.get(0).x - 6;
         String pres = r.kind.equals("friend") ? this.social.presenceOf(r.friend.profileId()) : null;
         if (pres != null) {
            String pt = "● " + pres;
            int pw = f.width(pt);
            g.text(f, pt, rightLimit - pw, y + 5, -218103809, false);
            rightLimit -= pw + 8;
         }

         String name = r.friend.name().isEmpty() ? r.friend.profileId() : r.friend.name();
         g.text(f, Ng.fit(f, name, Math.max(10, rightLimit - (cx + 12))), cx + 12, y + 5, -855638017, false);

         for (ModuleSettingsScreen.SBtn b : btns) {
            boolean danger = b.action.equals("remove");
            boolean hov = Ng.in(mouseX, mouseY, b.x, b.y, b.w, b.h);
            Ng.cardBordered(g, b.x, b.y, b.w, b.h, hov ? 654311423 : 352321535, 352321535);
            g.centeredText(f, b.label, b.x + b.w / 2, b.y + 3, danger ? -1929379841 : -855638017);
         }
      }
   }

   private void socButton(GuiGraphicsExtractor g, Font f, int x, int y, int w, String label, int mouseX, int mouseY) {
      boolean hov = Ng.in(mouseX, mouseY, x, y, w, 16);
      Ng.cardBordered(g, x, y, w, 16, hov ? 654311423 : 352321535, 352321535);
      g.centeredText(f, label, x + w / 2, y + 4, -855638017);
   }

   private void ensureSocialLoaded() {
      if (this.social.get().state == SocialData.State.IDLE) {
         SocialClient.loadAll(this.social);
      }
   }

   private boolean handleSocialClick(double mx, double my) {
      if (Ng.in(mx, my, this.socAddX(), this.socActionY(), 76, 16)) {
         Minecraft.getInstance().setScreen(new AddFriendScreen(this, this.social));
         return true;
      }

      if (Ng.in(mx, my, this.socRefreshX(), this.socActionY(), 52, 16)) {
         SocialClient.loadAll(this.social);
         return true;
      }

      if (this.socBannerShown() && Ng.in(mx, my, this.socEnableX(), this.socBannerY(), 44, 16)) {
         SocialClient.enableFriends(this.social);
         return true;
      }

      int top = this.socBodyTop();
      int bottom = this.socBodyBottom();
      if (this.social.get().state == SocialData.State.OK && my >= top && my < bottom) {
         List<ModuleSettingsScreen.SRow> rows = this.buildRows(this.social.get());
         int y = top - Math.round(this.socScroll);

         for (ModuleSettingsScreen.SRow r : rows) {
            int h = this.rowH(r.type);
            if (r.type == ModuleSettingsScreen.RT.ITEM && my >= y && my < y + h) {
               for (ModuleSettingsScreen.SBtn b : this.itemButtons(r, y)) {
                  if (Ng.in(mx, my, b.x, b.y, b.w, b.h)) {
                     if (b.action.equals("accept")) {
                        SocialClient.accept(this.social, b.pid);
                     } else {
                        SocialClient.remove(this.social, b.pid);
                     }

                     return true;
                  }
               }
            }

            y += h;
         }
      }

      return true;
   }

   private int modalW() {
      return 244;
   }

   private int optH(Opt o) {
      return o.kind == Opt.Kind.SLIDER ? 32 : 22;
   }

   private int optsH() {
      int h = 0;

      for (Opt o : this.modalOpts) {
         h += this.optH(o);
      }

      return h;
   }

   private List<String> modalDesc() {
      if (this.modalDescFor != this.modal) {
         this.modalDesc = this.modal < 0 ? List.of() : Ng.wrap(this.font, this.modules.get(this.modal).desc, 216, 4);
         this.modalDescFor = this.modal;
      }

      return this.modalDesc;
   }

   private int headH() {
      return 66 + Math.max(0, this.modalDesc().size() - 1) * 10;
   }

   private int modalFoot() {
      return this.modal >= 0 && this.modules.get(this.modal).hasAction() ? 34 : 8;
   }

   private int bodyH() {
      return this.modalOpts.isEmpty() ? 24 : this.optsH();
   }

   private int modalH() {
      return Math.min(this.height - 36, this.headH() + this.bodyH() + this.modalFoot() + 4);
   }

   private int modalX() {
      return (this.width - this.modalW()) / 2;
   }

   private int modalY() {
      return (this.height - this.modalH()) / 2;
   }

   private int msx() {
      return this.modalX() + 16;
   }

   private int msw() {
      return this.modalW() - 32;
   }

   private int headRowY() {
      return this.modalY() + 42 + Math.max(0, this.modalDesc().size() - 1) * 10;
   }

   private int favX() {
      return this.modalX() + (this.modal >= 0 && this.modules.get(this.modal).hasToggle() ? 46 : 14);
   }

   private int badgeX(Font f, String badge) {
      return this.modalX() + this.modalW() - 14 - f.width(badge);
   }

   private int bodyTop() {
      return this.modalY() + this.headH();
   }

   private int bodyBottom() {
      return this.modalY() + this.modalH() - this.modalFoot();
   }

   private int maxModalScroll() {
      return Math.max(0, this.optsH() - (this.bodyBottom() - this.bodyTop()));
   }

   private int optY(int i) {
      int y = this.bodyTop() - Math.round(this.modalScroll);

      for (int k = 0; k < i; k++) {
         y += this.optH(this.modalOpts.get(k));
      }

      return y;
   }

   private int useBtnY() {
      return this.modalY() + this.modalH() - 28;
   }

   private void drawModal(GuiGraphicsExtractor g, Font f, int mouseX, int mouseY) {
      ClientModule m = this.modules.get(this.modal);
      int mw = this.modalW();
      int mh = this.modalH();
      int mx0 = this.modalX();
      int my0 = this.modalY();
      g.fill(0, 0, this.width, this.height, -1728053248);
      Ng.cardBordered(g, mx0, my0, mw, mh, -1072951530, 822083583);
      g.fill(mx0 + 3, my0 + 1, mx0 + mw - 3, my0 + 2, 352321535);
      g.text(f, m.name, mx0 + 14, my0 + 12, -218103809, false);
      boolean xHov = Ng.in(mouseX, mouseY, mx0 + mw - 20, my0 + 8, 14, 14);
      g.text(f, "✕", mx0 + mw - 17, my0 + 10, xHov ? -218103809 : -1929379841, false);
      List<String> desc = this.modalDesc();

      for (int i = 0; i < desc.size(); i++) {
         g.text(f, desc.get(i), mx0 + 14, my0 + 26 + i * 10, -1929379841, false);
      }

      if (m.hasToggle()) {
         Ng.toggle(g, mx0 + 14, this.headRowY(), m.isEnabled() ? 1.0F : 0.0F);
      }

      if (m.quickable()) {
         g.text(f, "★", this.favX(), this.headRowY() + 3, m.isInQuick() ? -218103809 : 1442840575, false);
      }

      boolean canBind = KeyBindings.assignable(m.id);
      String badge;
      int badgeColor;
      if (this.awaitKey) {
         badge = "> 키를 누르세요 <";
         badgeColor = -218103809;
      } else if (canBind) {
         String key = KeyBindings.displayOf(m.id);
         badge = "키 " + (key.isEmpty() ? "미지정" : key);
         boolean bHov = Ng.in(mouseX, mouseY, this.badgeX(f, badge), this.headRowY(), f.width(badge) + 4, 12);
         badgeColor = bHov ? -218103809 : -1929379841;
      } else {
         badge = "전용 키 없음";
         badgeColor = 1442840575;
      }

      g.text(f, badge, this.badgeX(f, badge), this.headRowY() + 3, badgeColor, false);
      if (this.awaitKey) {
         g.text(f, "ESC 취소 · Delete 해제", mx0 + 14, this.headRowY() + 22, 1442840575, false);
      } else if (this.keyConflict != null) {
         g.text(f, "⚠ " + this.keyConflict + " 와 겹칩니다", mx0 + 14, this.headRowY() + 22, -34953, false);
      }

      g.fill(mx0 + 14, this.headRowY() + 18, mx0 + mw - 14, this.headRowY() + 19, 352321535);
      this.modalScroll = clamp(this.modalScroll, 0.0F, this.maxModalScroll());
      g.enableScissor(mx0, this.bodyTop(), mx0 + mw, this.bodyBottom());

      for (int i = 0; i < this.modalOpts.size(); i++) {
         Opt o = this.modalOpts.get(i);
         int y = this.optY(i);
         if (y + this.optH(o) > this.bodyTop() && y < this.bodyBottom()) {
            this.drawOpt(g, f, o, y, mouseX, mouseY);
         }
      }

      g.disableScissor();
      if (this.modalOpts.isEmpty()) {
         g.centeredText(f, "조절할 설정이 없습니다", mx0 + mw / 2, (this.bodyTop() + this.bodyBottom()) / 2 - 9 / 2, 1442840575);
      }

      if (m.hasAction()) {
         int bx = mx0 + 16;
         int bw = mw - 32;
         int bty = this.useBtnY();
         boolean bHov = Ng.in(mouseX, mouseY, bx, bty, bw, 20);
         Ng.cardBordered(g, bx, bty, bw, 20, bHov ? 654311423 : 352321535, 352321535);
         g.centeredText(f, m.actionLabel(), bx + bw / 2, bty + 6, -218103809);
      }
   }

   private void drawOpt(GuiGraphicsExtractor g, Font f, Opt o, int y, int mouseX, int mouseY) {
      int mx0 = this.modalX();
      int mw = this.modalW();
      boolean on = o.usable();
      boolean hov = on && Ng.in(mouseX, mouseY, mx0 + 8, y, mw - 16, this.optH(o) - 2);
      if (!on) {
         g.text(f, o.label, mx0 + 14, y + (o.kind == Opt.Kind.SLIDER ? 2 : 6), 1442840575, false);
         if (o.kind == Opt.Kind.SLIDER) {
            String v = o.display();
            g.text(f, v, mx0 + mw - 14 - f.width(v), y + 2, 1442840575, false);
            g.fill(this.msx(), y + 18, this.msx() + this.msw(), y + 22, 352321535);
         }
      } else if (o.kind == Opt.Kind.ACTION) {
         Ng.cardBordered(g, this.msx(), y, this.msw(), 20, hov ? 654311423 : 352321535, 352321535);
         g.centeredText(f, o.label, this.msx() + this.msw() / 2, y + 6, -855638017);
      } else {
         if (hov && o.kind != Opt.Kind.SLIDER) {
            Ng.card(g, mx0 + 8, y, mw - 16, this.optH(o) - 2, 352321535);
         }

         boolean slider = o.kind == Opt.Kind.SLIDER;
         g.text(f, o.label, mx0 + 14, y + (slider ? 2 : 6), -855638017, false);
         switch (o.kind) {
            case TOGGLE:
               Ng.toggle(g, mx0 + mw - 14 - 24, y + 4, (float)o.value());
               break;
            case COLOR:
               Ng.cardBordered(g, mx0 + mw - 14 - 12, y + 4, 12, 12, (int)((long)o.value()), 822083583);
               break;
            case CYCLE: {
               String v = o.display() + " ›";
               g.text(f, v, mx0 + mw - 14 - f.width(v), y + 6, -218103809, false);
               break;
            }
            case SLIDER: {
               String v = o.display();
               g.text(f, v, mx0 + mw - 14 - f.width(v), y + 2, -1929379841, false);
               this.drawSlider(g, this.msx(), y + 18, this.msw(), o.fraction());
            }
         }
      }
   }

   private void drawSlider(GuiGraphicsExtractor g, int sx, int ty, int sw, double t) {
      t = Math.max(0.0, Math.min(1.0, t));
      int kx = sx + (int)Math.round(t * (sw - 8));
      g.fill(sx, ty, sx + sw, ty + 4, 352321535);
      g.fill(sx, ty, kx + 4, ty + 4, Ng.withAlpha(-218103809, 0.45F));
      Ng.card(g, kx, ty - 4, 8, 12, -218103809);
   }

   private void openModal(int index) {
      this.modal = index;
      this.modalOpts = this.modules.get(index).opts();
      this.modalScroll = 0.0F;
      this.draggingOpt = -1;
   }

   private void finishAssign(Key key) {
      ClientModule m = this.modules.get(this.modal);
      this.keyConflict = KeyBindings.conflictLabel(m.id, key);
      KeyBindings.assign(m.id, key);
      this.awaitKey = false;
   }

   private void closeModal() {
      this.modal = -1;
      this.modalOpts = List.of();
      this.draggingOpt = -1;
      this.awaitKey = false;
      this.keyConflict = null;
      Config.get().save();
   }

   private int activeCount() {
      int n = 0;

      for (ClientModule m : this.modules) {
         if (this.isActive(m)) {
            n++;
         }
      }

      return n;
   }

   private boolean isActive(ClientModule m) {
      return switch (m.id) {
         case "brightness" -> BrightnessController.isActive();
         case "autosprint" -> ToggleSprintController.isActive();
         case "camera" -> PhotoModeController.isActive();
         case "calc", "timer", "whisper", "zoom" -> false;
         default -> m.isEnabled();
      };
   }

   private void tickAnim(int mouseX, int mouseY) {
      long now = System.nanoTime();
      if (this.openAt == 0L) {
         this.openAt = now;
         this.lastFrame = now;
      }

      float dt = Math.min(0.05F, (float)(now - this.lastFrame) / 1.0E9F);
      this.lastFrame = now;
      this.openP = Ng.easeOut(Math.min(1.0F, (float)(now - this.openAt) / 1.9E8F));
      float rate = Math.min(1.0F, dt * 14.0F);

      for (int i = 0; i < this.modules.size(); i++) {
         this.favP[i] = this.favP[i] + ((this.modules.get(i).isInQuick() ? 1 : 0) - this.favP[i]) * rate;
      }

      for (int k = 0; k < SECTIONS.length; k++) {
         boolean hov = this.modal < 0 && Ng.in(mouseX, mouseY, this.panelX() + 8, this.navY(k), 90, 21);
         this.navHoverP[k] = this.navHoverP[k] + ((hov ? 1 : 0) - this.navHoverP[k]) * rate;
      }

      if (this.section == 1) {
         Font f = this.font;
         if (this.cats.get(this.selectedCat).equals("사용 중") && this.filtered.length != this.activeCount()) {
            this.rebuildFilter();
         }

         for (int k = 0; k < this.cats.size(); k++) {
            boolean hov = this.modal < 0 && Ng.in(mouseX, mouseY, this.chipX(f, k), this.panelY() + 11, this.chipW(f, k), 15);
            this.chipHoverP[k] = this.chipHoverP[k] + ((hov ? 1 : 0) - this.chipHoverP[k]) * rate;
         }

         for (int k = 0; k < this.filtered.length; k++) {
            int i = this.filtered[k];
            boolean hov = this.modal < 0
               && mouseY >= this.gridTop()
               && mouseY < this.gridBottom()
               && Ng.in(mouseX, mouseY, this.cardX(k), this.cardY(k), 142, 58);
            this.hoverP[i] = this.hoverP[i] + ((hov ? 1 : 0) - this.hoverP[i]) * rate;
         }
      }
   }

   private void drawNav(GuiGraphicsExtractor g, Font f, int k) {
      int nx = this.panelX() + 8;
      int ny = this.navY(k);
      boolean sel = k == this.section;
      Ng.card(g, nx, ny, 90, 21, sel ? 587202559 : Ng.lerpColor(16777215, 352321535, this.navHoverP[k]));
      if (sel) {
         g.fill(nx + 1, ny + 3, nx + 3, ny + 24 - 6, -218103809);
      }

      int col = sel ? -218103809 : (READY[k] ? -1929379841 : 1442840575);
      g.text(f, SECTIONS[k], nx + 9, ny + 6, col, false);
   }

   public boolean mouseScrolled(double mx, double my, double dx, double dy) {
      if (this.modal >= 0) {
         this.modalScroll = clamp(this.modalScroll - (float)dy * 16.0F, 0.0F, this.maxModalScroll());
      } else if (this.section == 1) {
         this.scroll = clamp(this.scroll - (float)dy * 20.0F, 0.0F, this.maxScroll);
      } else if (this.modal < 0 && this.section == 0 && READY[0]) {
         this.socScroll = clamp(this.socScroll - (float)dy * 20.0F, 0.0F, this.socMaxScroll);
      } else if (this.modal < 0 && this.section == 2) {
         this.macScroll = clamp(this.macScroll - (float)dy * 20.0F, 0.0F, this.macMaxScroll);
      }

      return true;
   }

   public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
      if (this.modal >= 0 && this.awaitKey) {
         this.finishAssign(Type.MOUSE.getOrCreate(event.button()));
         return true;
      }

      if (event.button() != 0) {
         return super.mouseClicked(event, doubleClick);
      }

      double mx = event.x();
      double my = event.y();
      if (this.modal >= 0) {
         ClientModule m = this.modules.get(this.modal);
         if (Ng.in(mx, my, this.modalX() + this.modalW() - 20, this.modalY() + 8, 14, 14)) {
            this.closeModal();
            return true;
         }

         if (m.hasToggle() && Ng.in(mx, my, this.modalX() + 14, this.headRowY(), 24, 13)) {
            m.toggleEnabled();
            return true;
         }

         if (m.quickable() && Ng.in(mx, my, this.favX() - 3, this.headRowY(), 14, 13)) {
            m.toggleInQuick();
            return true;
         }

         if (KeyBindings.assignable(m.id)) {
            String badge = "키 " + (m.keyDisplay().isEmpty() ? "미지정" : m.keyDisplay());
            if (Ng.in(mx, my, this.badgeX(this.font, badge), this.headRowY(), this.font.width(badge) + 4, 12)) {
               this.awaitKey = true;
               this.keyConflict = null;
               return true;
            }
         }

         if (my >= this.bodyTop() && my < this.bodyBottom() && this.handleOptClick(mx, my)) {
            return true;
         }

         if (m.hasAction() && Ng.in(mx, my, this.modalX() + 16, this.useBtnY(), this.modalW() - 32, 20)) {
            m.runAction();
            return true;
         }

         if (!Ng.in(mx, my, this.modalX(), this.modalY(), this.modalW(), this.modalH())) {
            this.closeModal();
         }

         return true;
      } else {
         Font f = this.font;

         for (int k = 0; k < SECTIONS.length; k++) {
            if (Ng.in(mx, my, this.panelX() + 8, this.navY(k), 90, 21)) {
               this.section = k;
               if (k == 0 && READY[0]) {
                  this.ensureSocialLoaded();
               }

               return true;
            }
         }

         if (this.section == 2) {
            return this.handleMacroClick(mx, my);
         }

         if (this.section == 0 && READY[0]) {
            return this.handleSocialClick(mx, my);
         }

         if (this.section == 1) {
            for (int k = 0; k < this.cats.size(); k++) {
               if (Ng.in(mx, my, this.chipX(f, k), this.panelY() + 11, this.chipW(f, k), 15)) {
                  if (k != this.selectedCat) {
                     this.selectedCat = k;
                     this.rebuildFilter();
                  }

                  return true;
               }
            }

            if (my >= this.gridTop() && my < this.gridBottom()) {
               for (int k = 0; k < this.filtered.length; k++) {
                  if (this.handleCardClick(k, mx, my)) {
                     return true;
                  }
               }
            }
         }

         if (this.section == 5 && Ng.in(mx, my, this.setX(), this.hudBtnY(), this.setW(), 20)) {
            Minecraft.getInstance().setScreen(new HudLayoutScreen(this));
            return true;
         } else if (this.section == 5 && Ng.in(mx, my, this.setX(), this.resetBtnY(), this.setW(), 20)) {
            Config.reset();
            KeyBindings.reapply();
            this.resetToastUntil = System.currentTimeMillis() + 2000L;
            return true;
         } else {
            return super.mouseClicked(event, doubleClick);
         }
      }
   }

   private boolean handleOptClick(double mx, double my) {
      for (int i = 0; i < this.modalOpts.size(); i++) {
         Opt o = this.modalOpts.get(i);
         if (o.usable()) {
            int y = this.optY(i);
            if (!(my < y) && !(my >= y + this.optH(o))) {
               if (o.kind == Opt.Kind.SLIDER) {
                  o.setFraction((mx - this.msx()) / (this.msw() - 8));
                  this.draggingOpt = i;
               } else if (o.kind == Opt.Kind.ACTION) {
                  o.action.run();
               } else {
                  o.advance();
                  Config.get().save();
               }

               return true;
            }
         }
      }

      return false;
   }

   public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
      if (this.draggingOpt >= 0 && this.draggingOpt < this.modalOpts.size()) {
         this.modalOpts.get(this.draggingOpt).setFraction((event.x() - this.msx()) / (this.msw() - 8));
         return true;
      } else {
         return super.mouseDragged(event, dx, dy);
      }
   }

   @Override
   public boolean mouseReleased(MouseButtonEvent event) {
      if (this.draggingOpt >= 0) {
         this.draggingOpt = -1;
         Config.get().save();
      }

      return super.mouseReleased(event);
   }

   private boolean handleCardClick(int k, double mx, double my) {
      int i = this.filtered[k];
      ClientModule m = this.modules.get(i);
      int x = this.cardX(k);
      int y = this.cardY(k);
      if (!Ng.in(mx, my, x, y, 142, 58)) {
         return false;
      } else if (m.quickable() && Ng.in(mx, my, x + 10 - 3, y + 58 - 19, 16, 16)) {
         m.toggleInQuick();
         return true;
      } else {
         this.openModal(i);
         return true;
      }
   }

   public boolean keyPressed(KeyEvent event) {
      try {
         if (this.modal >= 0 && this.awaitKey) {
            if (event.key() == 256) {
               this.awaitKey = false;
            } else if (event.key() != 261 && event.key() != 259) {
               this.finishAssign(InputConstants.getKey(event));
            } else {
               this.finishAssign(InputConstants.UNKNOWN);
            }

            return true;
         }

         if (this.modal >= 0) {
            if (event.key() != 256 && !KeyBindings.matchesSettings(event)) {
               return true;
            }

            this.closeModal();
            return true;
         }

         if (KeyBindings.matchesSettings(event)) {
            this.onClose();
            return true;
         }
      } catch (Throwable var3) {
      }

      return super.keyPressed(event);
   }

   public void onClose() {
      Config.get().save();
      Minecraft.getInstance().setScreen(null);
   }

   private static float clamp(float v, float lo, float hi) {
      return v < lo ? lo : (v > hi ? hi : v);
   }

   private enum RT {
      HEADER,
      ITEM,
      EMPTY;
   }

   private record SBtn(String label, String action, String pid, int x, int y, int w, int h) {
   }

   private record SRow(ModuleSettingsScreen.RT type, String text, SocialData.Friend friend, String kind) {
   }
}
