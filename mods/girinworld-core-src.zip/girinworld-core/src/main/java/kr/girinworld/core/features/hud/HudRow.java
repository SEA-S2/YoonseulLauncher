package kr.girinworld.core.features.hud;

import net.minecraft.world.item.ItemStack;

public record HudRow(ItemStack icon, String text, int rgb) {
   private static final int DEFAULT_RGB = 16777215;

   public HudRow(ItemStack icon, String text) {
      this(icon, text, 16777215);
   }

   public static HudRow of(String text) {
      return new HudRow(null, text, 16777215);
   }
}
