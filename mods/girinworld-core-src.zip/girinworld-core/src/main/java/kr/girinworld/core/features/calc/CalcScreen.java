package kr.girinworld.core.features.calc;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import kr.girinworld.core.Config;
import kr.girinworld.core.features.CoreScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public final class CalcScreen extends CoreScreen {
   private static final int GLFW_KEY_ENTER = 257;
   private static final int GLFW_KEY_KP_ENTER = 335;
   private static final String[][] KEYPAD = new String[][]{
      {"7", "8", "9", "/"}, {"4", "5", "6", "*"}, {"1", "2", "3", "-"}, {"0", ".", "(", "+"}, {")", "%", "C", "="}
   };
   private final Screen parent;
   private EditBox input;
   private String currentExpr = "";
   private String errorText = "";
   private int inputTop;

   public CalcScreen(Screen parent) {
      super(Component.literal("계산기"));
      this.parent = parent;
   }

   protected void init() {
      int panelW = 200;
      int left = this.width / 2 - panelW / 2;
      int top = this.height / 2 - 60;
      this.inputTop = top;
      this.input = new EditBox(this.font, left, top, panelW, 20, Component.literal("수식"));
      this.input.setMaxLength(256);
      this.input.setHint(Component.literal("예: 1.5M*3"));
      this.input.setResponder(s -> {
         this.currentExpr = s;
         this.errorText = "";
      });
      this.input.setValue(this.currentExpr);
      this.addRenderableWidget(this.input);
      this.setInitialFocus(this.input);
      int gap = 4;
      int cols = 4;
      int btnW = (panelW - gap * (cols - 1)) / cols;
      int btnH = 20;
      int gridTop = top + 26;

      for (int r = 0; r < KEYPAD.length; r++) {
         for (int c = 0; c < cols; c++) {
            String label = KEYPAD[r][c];
            int x = left + c * (btnW + gap);
            int y = gridTop + r * (btnH + gap);
            this.addRenderableWidget(Button.builder(Component.literal(label), b -> this.onKey(label)).bounds(x, y, btnW, btnH).build());
         }
      }

      int closeY = gridTop + KEYPAD.length * (btnH + gap);
      this.addRenderableWidget(Button.builder(Component.literal("닫기"), b -> this.onClose()).bounds(left, closeY, panelW, btnH).build());
   }

   private void onKey(String label) {
      switch (label) {
         case "C":
            this.input.setValue("");
            this.errorText = "";
            break;
         case "=":
            this.compute();
            break;
         default:
            this.input.setValue(this.input.getValue() + label);
      }
   }

   @Override
   public boolean mouseReleased(MouseButtonEvent event) {
      boolean handled = super.mouseReleased(event);
      this.setFocused(this.input);
      return handled;
   }

   private void compute() {
      CalcResult r = CalcEngine.evaluate(this.input.getValue());
      if (r.ok) {
         this.input.setValue(this.format(r.value));
         this.errorText = "";
      } else {
         this.errorText = r.errorMessage;
      }
   }

   private String format(BigDecimal value) {
      BigDecimal v = value.stripTrailingZeros();
      return !Config.get().calc.thousandsSeparator ? v.toPlainString() : new DecimalFormat("#,##0.##############").format(v);
   }

   public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
      super.extractRenderState(graphics, mouseX, mouseY, partialTick);
      Font f = this.font;
      String title = this.getTitle().getString();
      graphics.text(f, title, this.width / 2 - f.width(title) / 2, this.height / 2 - 88, -1);
      if (!this.errorText.isEmpty()) {
         graphics.text(f, this.errorText, this.width / 2 - f.width(this.errorText) / 2, this.inputTop - 14, -43691);
      }
   }

   public boolean keyPressed(KeyEvent event) {
      int key = event.key();
      if (key != 257 && key != 335) {
         return super.keyPressed(event);
      }

      this.compute();
      return true;
   }

   public void onClose() {
      Minecraft.getInstance().setScreen(this.parent);
   }
}
