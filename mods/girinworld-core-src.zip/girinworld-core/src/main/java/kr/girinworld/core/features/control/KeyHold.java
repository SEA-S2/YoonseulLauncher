package kr.girinworld.core.features.control;

import java.util.function.BooleanSupplier;

final class KeyHold {
   private KeyHold() {
   }

   static void hold(BooleanSupplier isDown, KeyHold.Setter setDown, boolean want) {
      if (isDown.getAsBoolean() != want) {
         setDown.set(true);
         if (isDown.getAsBoolean() != want) {
            setDown.set(want);
         }
      }
   }

   interface Setter {
      void set(boolean var1);
   }
}
