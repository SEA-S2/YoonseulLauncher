package kr.girinworld.core.features.hud;

import kr.girinworld.core.Config;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public final class HudUtil {
   public static final int MARGIN = 6;
   public static final float BASE_SCALE = 0.8F;
   private static final double[] ANCHORS = new double[]{0.0, 0.5, 1.0};
   public static final int SNAP_PX = 8;
   public static final int BG_PAD = 3;
   private static final int[] CORNER = new int[]{2, 1};

   private HudUtil() {
   }

   public static int anchorX(int screenW, int contentW, double x) {
      return 6 + (int)Math.round(clamp01(x) * span(screenW, contentW));
   }

   public static int anchorY(int screenH, int contentH, double y) {
      return 6 + (int)Math.round(clamp01(y) * span(screenH, contentH));
   }

   public static int span(int screen, int content) {
      return Math.max(0, screen - content - 12);
   }

   public static double clamp01(double v) {
      return Math.max(0.0, Math.min(1.0, v));
   }

   public static double snapToAnchor(double v, int span) {
      if (span > 0) {
         for (double a : ANCHORS) {
            if (Math.abs(v - a) * span <= 8.0) {
               return a;
            }
         }
      }

      return clamp01(v);
   }

   public static double clampOpacity(double v) {
      return Math.max(0.1, Math.min(1.0, v));
   }

   public static double clampScale(double v) {
      return Math.max(0.5, Math.min(3.0, v));
   }

   public static void roundedRect(GuiGraphicsExtractor g, int x, int y, int w, int h, int argb) {
      int r = CORNER.length;
      if (w > 2 * r && h > 2 * r) {
         g.fill(x, y + r, x + w, y + h - r, argb);

         for (int i = 0; i < r; i++) {
            int in = CORNER[i];
            g.fill(x + in, y + i, x + w - in, y + i + 1, argb);
            g.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, argb);
         }
      } else {
         g.fill(x, y, x + w, y + h, argb);
      }
   }

   public static void background(GuiGraphicsExtractor g, Config.Hud.Elem cfg, int x, int y, int w, int h) {
      if (cfg.bgEnabled && !(cfg.bgOpacity <= 0.0)) {
         int a = (int)Math.round(Math.max(0.0, Math.min(1.0, cfg.bgOpacity)) * 255.0);
         roundedRect(g, x - 3, y - 3, w + 6, h + 6, a << 24);
      }
   }
}
