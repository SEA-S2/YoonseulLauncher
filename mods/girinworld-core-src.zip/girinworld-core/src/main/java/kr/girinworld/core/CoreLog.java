package kr.girinworld.core;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;

public final class CoreLog {
   private static final Object LOCK = new Object();
   private static Path logFile;
   private static volatile boolean initAttempted = false;

   private CoreLog() {
   }

   public static void init() {
      initAttempted = true;

      try {
         Path base = baseDir();
         Files.createDirectories(base);
         logFile = base.resolve("girinworld-core.log");
         write("==== ClientCore session " + Instant.now() + " ====");
      } catch (Throwable t) {
         System.err.println("[ClientCore] log init failed: " + t);
      }
   }

   public static Path baseDir() {
      String prop = System.getProperty("girinworld.dir");
      if (prop != null && !prop.isBlank()) {
         return Path.of(prop);
      }

      Path run = Path.of("run");
      return Files.isDirectory(run) ? run : Path.of(".");
   }

   public static void info(String message) {
      write("[INFO] " + message);
   }

   public static void error(String message, Throwable t) {
      String trace = "";
      if (t != null) {
         StringWriter sw = new StringWriter();
         t.printStackTrace(new PrintWriter(sw));
         trace = System.lineSeparator() + sw;
      }

      write("[ERROR] " + message + trace);
   }

   private static void write(String line) {
      System.out.println("[ClientCore] " + line);
      if (logFile == null && !initAttempted) {
         init();
      }

      synchronized (LOCK) {
         if (logFile != null) {
            try {
               Files.writeString(logFile, line + System.lineSeparator(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            } catch (Throwable var4) {
            }
         }
      }
   }
}
