package kr.girinworld.core.features.whisper;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import kr.girinworld.core.CoreLog;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;

public final class WhisperService {
   private static final long PENDING_WINDOW_MS = 5000L;
   private static final String FAIL_LINE = "전송 실패 — 상대가 접속 중이 아님";
   private static final String UNSAFE_LINE = "전송 불가 — 대상 이름에 공백/특수문자가 있음";
   private static final int LOOKUP_MAX_PER_WINDOW = 10;
   private static final long LOOKUP_WINDOW_MS = 60000L;
   private static final WhisperStore STORE = new WhisperStore();
   private static final NameRegistry NAMES = new NameRegistry();
   private static final Deque<WhisperService.Pending> PENDING = new ArrayDeque<>();
   private static final Set<String> NAME_LOOKUPS = new HashSet<>();
   private static final Deque<Long> LOOKUP_TIMES = new ArrayDeque<>();
   private static volatile String openKey;
   private static boolean loaded = false;

   private WhisperService() {
   }

   public static WhisperStore store() {
      return STORE;
   }

   public static NameRegistry names() {
      return NAMES;
   }

   private static synchronized void ensureLoaded() {
      if (!loaded) {
         loaded = true;
         NAMES.load();
      }
   }

   public static synchronized void setOpen(String key) {
      openKey = key;
      if (key != null) {
         STORE.clearUnread(key);
      }
   }

   public static synchronized void clearOpen(String key) {
      if (Objects.equals(openKey, key)) {
         openKey = null;
      }
   }

   public static synchronized void onChatLine(String raw) {
      ensureLoaded();
      long now = System.currentTimeMillis();
      switch (WhisperParser.parse(raw)) {
         case WhisperParser.Whisper w:
            handleWhisper(w, now);
            break;
         case WhisperParser.NameReveal nr:
            handleNameReveal(nr);
            break;
         case WhisperParser.SendFail sf:
            handleSendFail(sf, now);
            break;
         case WhisperParser.Ignored var8:
            break;
         default:
            throw new MatchException(null, null);
      }
   }

   private static void handleWhisper(WhisperParser.Whisper w, long now) {
      String partner = w.partner();
      if (w.direction() == Direction.OUTGOING) {
         reconcileEcho(partner);
      }

      String key = NAMES.identityKey(partner);
      boolean muted = Objects.equals(openKey, key);
      STORE.add(key, NAMES.displayFor(key), w.direction(), w.text(), now, muted);
      if (NameRegistry.isKorean(partner) && NAMES.englishFor(partner) == null) {
         dispatchNameLookup(partner);
      }
   }

   private static void handleNameReveal(WhisperParser.NameReveal nr) {
      boolean isNew = NAMES.register(nr.korean(), nr.english());
      String key = NAMES.identityKey(nr.korean());
      STORE.merge(nr.korean(), key, NAMES.displayFor(key));
      if (Objects.equals(openKey, nr.korean()) || Objects.equals(openKey, key)) {
         openKey = key;
      }

      if (isNew) {
         NAMES.save();
      }
   }

   private static void handleSendFail(WhisperParser.SendFail sf, long now) {
      WhisperService.Pending pd = latestPending(now);
      if (pd != null) {
         STORE.addSystem(pd.roomKey(), "전송 실패 — 상대가 접속 중이 아님", now);
      }
   }

   private static void reconcileEcho(String echoPartner) {
      WhisperService.Pending pd = latestPending(System.currentTimeMillis());
      if (pd != null && !pd.sentName().equalsIgnoreCase(echoPartner)) {
         boolean learned = false;
         if (NameRegistry.isKorean(echoPartner) && !NameRegistry.isKorean(pd.sentName())) {
            learned = NAMES.register(echoPartner, pd.sentName());
         } else if (NameRegistry.isKorean(pd.sentName()) && !NameRegistry.isKorean(echoPartner)) {
            learned = NAMES.register(pd.sentName(), echoPartner);
         }

         String key = NAMES.identityKey(echoPartner);
         if (!pd.roomKey().equals(key)) {
            STORE.merge(pd.roomKey(), key, NAMES.displayFor(key));
            if (Objects.equals(openKey, pd.roomKey())) {
               openKey = key;
            }
         }

         if (learned) {
            NAMES.save();
         }
      }
   }

   public static synchronized void send(String roomKey, String text) {
      if (text != null) {
         String msg = text.strip();
         if (!msg.isEmpty()) {
            if (unsafeName(roomKey)) {
               STORE.addSystem(roomKey, "전송 불가 — 대상 이름에 공백/특수문자가 있음", System.currentTimeMillis());
            } else {
               ClientPacketListener conn = connection();
               if (conn == null) {
                  CoreLog.error("whisper send skipped: no connection", null);
               } else {
                  try {
                     conn.sendCommand("w " + roomKey + " " + msg);
                  } catch (Throwable t) {
                     CoreLog.error("whisper send failed", t);
                     return;
                  }

                  long now = System.currentTimeMillis();
                  prune(now);
                  PENDING.addLast(new WhisperService.Pending(roomKey, roomKey, now));
               }
            }
         }
      }
   }

   public static boolean sendable(String name) {
      return !unsafeName(name);
   }

   private static boolean unsafeName(String s) {
      if (s != null && !s.isEmpty()) {
         for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isWhitespace(c) || c == '|' || c == 8594 || c < ' ') {
               return true;
            }
         }

         return false;
      } else {
         return true;
      }
   }

   public static synchronized String canonicalKey(String enteredName) {
      ensureLoaded();
      String key = NAMES.identityKey(enteredName);
      if (!NameRegistry.isKorean(NAMES.displayFor(key))) {
         dispatchNameLookup(enteredName);
      }

      WhisperStore.Conversation c = STORE.get(key);
      if (c != null) {
         c.displayName = NAMES.displayFor(key);
      }

      return key;
   }

   public static synchronized String resolveKey(String name) {
      return NAMES.identityKey(name);
   }

   private static void dispatchNameLookup(String name) {
      if (!unsafeName(name) && !NAME_LOOKUPS.contains(name)) {
         long now = System.currentTimeMillis();
         pruneLookups(now);
         if (LOOKUP_TIMES.size() < 10) {
            ClientPacketListener conn = connection();
            if (conn != null) {
               try {
                  conn.sendCommand("이름 " + name);
                  NAME_LOOKUPS.add(name);
                  LOOKUP_TIMES.addLast(now);
               } catch (Throwable t) {
                  CoreLog.error("name lookup dispatch failed", t);
               }
            }
         }
      }
   }

   private static WhisperService.Pending latestPending(long now) {
      prune(now);
      return PENDING.peekLast();
   }

   private static void prune(long now) {
      while (!PENDING.isEmpty() && now - PENDING.peekFirst().time() > 5000L) {
         PENDING.pollFirst();
      }
   }

   private static void pruneLookups(long now) {
      while (!LOOKUP_TIMES.isEmpty() && now - LOOKUP_TIMES.peekFirst() > 60000L) {
         LOOKUP_TIMES.pollFirst();
      }
   }

   private static ClientPacketListener connection() {
      Minecraft mc = Minecraft.getInstance();
      return mc != null && mc.player != null ? mc.player.connection : null;
   }

   private record Pending(String roomKey, String sentName, long time) {
   }
}
