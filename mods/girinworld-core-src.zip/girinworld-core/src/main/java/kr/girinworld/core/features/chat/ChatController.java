package kr.girinworld.core.features.chat;

import kr.girinworld.core.Config;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.network.chat.Component;

public final class ChatController {
   private static final int MIN_WIDTH = 40;
   private static final int MIN_HEIGHT = 20;

   private ChatController() {
   }

   private static Config.Chat cfg() {
      return Config.get().chat;
   }

   public static boolean enabled() {
      return cfg().enabled;
   }

   private static boolean focused() {
      Minecraft mc = Minecraft.getInstance();
      return mc != null && kr.girinworld.core.ClientCompat.screen(mc) instanceof ChatScreen;
   }

   public static int width(int vanilla) {
      return !enabled() ? vanilla : Math.max(40, (int)Math.round(vanilla * cfg().width));
   }

   public static int height(int vanilla) {
      if (!enabled()) {
         return vanilla;
      }

      double f = focused() ? cfg().heightFocused : cfg().heightUnfocused;
      return Math.max(20, (int)Math.round(vanilla * f));
   }

   public static double scale(double vanilla) {
      return !enabled() ? vanilla : Math.max(0.1, vanilla * cfg().scale);
   }

   public static Component decorate(Component line) {
      Config.Chat c = cfg();
      return (Component)(line != null && c.enabled && c.timestamp
         ? Component.empty().append(Component.literal(ChatStamp.prefix(c.timeFormat)).withStyle(ChatFormatting.DARK_GRAY)).append(line)
         : line);
   }

   public static String undecorate(String text) {
      return text != null && cfg().enabled && cfg().timestamp ? ChatStamp.strip(text) : text;
   }
}
