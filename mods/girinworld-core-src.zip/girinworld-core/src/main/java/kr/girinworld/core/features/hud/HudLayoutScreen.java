package kr.girinworld.core.features.hud;

import java.util.List;
import kr.girinworld.core.Config;
import kr.girinworld.core.features.CoreScreen;
import kr.girinworld.core.features.settings.ModuleSettingsScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public final class HudLayoutScreen extends CoreScreen {
   private static final int PAD = 3;
   private static final int HANDLE = 2;
   private static final int GLFW_KEY_R = 82;
   private static final long CONFIRM_MS = 3000L;
   private final Screen parent;
   private final List<HudTarget> targets = Widgets.all();
   private HudTarget dragging;
   private double dragOffX;
   private double dragOffY;
   private HudTarget resizing;
   private double resFixedX;
   private double resFixedY;
   private int resSignX;
   private int resSignY;
   private double resStartScale;
   private double resStartDist;
   private long resetConfirmUntil;

   public HudLayoutScreen(Screen parent) {
      super(Component.literal("HUD 배치"));
      this.parent = parent;
   }

   protected void init() {
      this.addRenderableWidget(
         Button.builder(Component.literal("변경 완료"), b -> this.onClose()).bounds(this.width / 2 - 50, this.height / 2 + 20, 100, 20).build()
      );
   }

   private int[] bounds(HudTarget t) {
      int[] size = t.size(this.font);
      return new int[]{HudUtil.anchorX(this.width, size[0], t.x()), HudUtil.anchorY(this.height, size[1], t.y()), size[0], size[1]};
   }

   private boolean hit(int[] b, double mx, double my) {
      return mx >= b[0] - 3 && mx <= b[0] + b[2] + 3 && my >= b[1] - 3 && my <= b[1] + b[3] + 3;
   }

   public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
      if (event.button() == 1) {
         for (HudTarget t : this.targets) {
            if (t.enabled() && this.hit(this.bounds(t), event.x(), event.y())) {
               Config.get().save();
               Minecraft.getInstance().setScreen(new ModuleSettingsScreen(t.moduleId()));
               return true;
            }
         }
      }

      if (event.button() == 0) {
         for (HudTarget t : this.targets) {
            if (t.enabled() && this.startResizeIfCorner(t, event.x(), event.y())) {
               return true;
            }
         }

         for (HudTarget t : this.targets) {
            if (t.enabled() && this.hit(this.bounds(t), event.x(), event.y())) {
               int[] b = this.bounds(t);
               this.dragging = t;
               this.dragOffX = event.x() - b[0];
               this.dragOffY = event.y() - b[1];
               return true;
            }
         }
      }

      return super.mouseClicked(event, doubleClick);
   }

   private boolean startResizeIfCorner(HudTarget t, double mx, double my) {
      int[] b = this.bounds(t);
      int[][] corner = new int[][]{{b[0], b[1]}, {b[0] + b[2], b[1]}, {b[0], b[1] + b[3]}, {b[0] + b[2], b[1] + b[3]}};

      for (int i = 0; i < 4; i++) {
         if (mx >= corner[i][0] - 2 && mx <= corner[i][0] + 2 && my >= corner[i][1] - 2 && my <= corner[i][1] + 2) {
            int[] fixed = corner[3 - i];
            this.resizing = t;
            this.resFixedX = fixed[0];
            this.resFixedY = fixed[1];
            this.resSignX = fixed[0] == b[0] + b[2] ? 1 : 0;
            this.resSignY = fixed[1] == b[1] + b[3] ? 1 : 0;
            this.resStartScale = t.scale();
            this.resStartDist = Math.max(2.0, Math.hypot(mx - this.resFixedX, my - this.resFixedY));
            return true;
         }
      }

      return false;
   }

   public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
      if (this.resizing != null) {
         double dist = Math.hypot(event.x() - this.resFixedX, event.y() - this.resFixedY);
         this.resizing.setScale(HudUtil.clampScale(this.resStartScale * dist / this.resStartDist));
         int[] s = this.resizing.size(this.font);
         double topLeftX = this.resFixedX - this.resSignX * s[0];
         double topLeftY = this.resFixedY - this.resSignY * s[1];
         this.resizing
            .setPos(
               HudUtil.clamp01((topLeftX - 6.0) / Math.max(1, HudUtil.span(this.width, s[0]))),
               HudUtil.clamp01((topLeftY - 6.0) / Math.max(1, HudUtil.span(this.height, s[1])))
            );
         return true;
      } else if (this.dragging != null) {
         int[] b = this.bounds(this.dragging);
         int spanX = Math.max(1, HudUtil.span(this.width, b[2]));
         int spanY = Math.max(1, HudUtil.span(this.height, b[3]));
         this.dragging
            .setPos(
               HudUtil.snapToAnchor((event.x() - this.dragOffX - 6.0) / spanX, spanX), HudUtil.snapToAnchor((event.y() - this.dragOffY - 6.0) / spanY, spanY)
            );
         return true;
      } else {
         return super.mouseDragged(event, dragX, dragY);
      }
   }

   @Override
   public boolean mouseReleased(MouseButtonEvent event) {
      if (this.resizing != null) {
         this.resizing = null;
         Config.get().save();
         return true;
      } else if (this.dragging != null) {
         this.dragging = null;
         Config.get().save();
         return true;
      } else {
         return super.mouseReleased(event);
      }
   }

   public boolean keyPressed(KeyEvent event) {
      if (event.key() != 82) {
         return super.keyPressed(event);
      }

      long now = System.currentTimeMillis();
      if (now < this.resetConfirmUntil) {
         for (HudTarget t : this.targets) {
            t.resetLayout();
         }

         Config.get().save();
         this.resetConfirmUntil = 0L;
      } else {
         this.resetConfirmUntil = now + 3000L;
      }

      return true;
   }

   public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
      super.extractRenderState(graphics, mouseX, mouseY, partialTick);
      Font f = this.font;
      boolean any = false;

      for (HudTarget t : this.targets) {
         if (t.enabled()) {
            any = true;
            int[] b = this.bounds(t);
            graphics.fill(b[0] - 3, b[1] - 3, b[0] + b[2] + 3, b[1] + b[3] + 3, 872415231);
            t.draw(graphics, f, b[0], b[1]);
            this.drawHandles(graphics, b, t == this.resizing);
         }
      }

      String hint;
      if (this.resizing != null) {
         hint = "크기 " + Math.round(this.resizing.scale() * 100.0) + "%";
      } else if (System.currentTimeMillis() < this.resetConfirmUntil) {
         hint = "R 을 한 번 더 누르면 기본 배치로 되돌립니다";
      } else if (!any) {
         hint = "켜져 있는 HUD가 없습니다 — 허브의 모드 탭에서 먼저 켜주세요";
      } else {
         hint = "드래그=위치(앵커 흡착) · 모서리=크기 · 우클릭=설정 · R=기본 배치 · ESC=완료";
      }

      graphics.text(f, hint, this.width / 2 - f.width(hint) / 2, this.height / 2 - 10, -1);
   }

   private void drawHandles(GuiGraphicsExtractor g, int[] b, boolean active) {
      int col = active ? -1 : -1426063361;
      int[][] corner = new int[][]{{b[0], b[1]}, {b[0] + b[2], b[1]}, {b[0], b[1] + b[3]}, {b[0] + b[2], b[1] + b[3]}};

      for (int[] c : corner) {
         g.fill(c[0] - 2, c[1] - 2, c[0] + 2, c[1] + 2, col);
      }
   }

   public void onClose() {
      Config.get().save();
      Minecraft.getInstance().setScreen(this.parent);
   }
}
