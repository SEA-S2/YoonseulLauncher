package kr.girinworld.core.features.hud;

import kr.girinworld.core.Config;
import kr.girinworld.core.KeyBindings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix3x2fStack;

public final class InventoryHud {
   private static final int SLOT = 18;
   private static final int COLS = 9;
   private static final int ROWS = 3;
   private static final int FIRST = 9;

   private InventoryHud() {
   }

   public static boolean hidden() {
      return Config.get().hud.invHoldOnly && !KeyBindings.invHoldActive();
   }

   static int emptySlots(Inventory inv) {
      int limit = Math.min(36, inv.getContainerSize());
      int n = 0;

      for (int i = 0; i < limit; i++) {
         if (inv.getItem(i).isEmpty()) {
            n++;
         }
      }

      return n;
   }

   static int arrows(Inventory inv) {
      int n = 0;

      for (int i = 0; i < inv.getContainerSize(); i++) {
         ItemStack s = inv.getItem(i);
         if (!s.isEmpty() && s.getItem() instanceof ArrowItem) {
            n += s.getCount();
         }
      }

      return n;
   }

   static final class Grid extends Widget {
      @Override
      protected Config.Hud.Elem cfg(Config.Hud hud) {
         return hud.inventory;
      }

      @Override
      public String label() {
         return "인벤토리 27칸";
      }

      @Override
      public String moduleId() {
         return "inventory";
      }

      @Override
      public boolean visibleNow() {
         return !InventoryHud.hidden();
      }

      @Override
      public int[] size(Font font) {
         float s = this.drawScale();
         return new int[]{Math.round(162.0F * s), Math.round(54.0F * s)};
      }

      @Override
      public void draw(GuiGraphicsExtractor graphics, Font font, int x, int y) {
         Minecraft mc = Minecraft.getInstance();
         if (mc != null && mc.player != null) {
            Inventory inv = mc.player.getInventory();
            int[] size = this.size(font);
            HudUtil.background(graphics, this.cfg(), x, y, size[0], size[1]);
            Matrix3x2fStack pose = graphics.pose();
            pose.pushMatrix();
            pose.translate(x, y);
            float s = this.drawScale();
            if (s != 1.0F) {
               pose.scale(s);
            }

            for (int i = 0; i < 27; i++) {
               this.slotBevel(graphics, i % 9 * 18, i / 9 * 18);
            }

            int limit = Math.min(27, Math.max(0, inv.getContainerSize() - 9));

            for (int i = 0; i < limit; i++) {
               ItemStack stack = inv.getItem(9 + i);
               if (!stack.isEmpty()) {
                  int cx = i % 9 * 18;
                  int cy = i / 9 * 18;
                  graphics.item(stack, cx + 1, cy + 1);
                  graphics.itemDecorations(font, stack, cx + 1, cy + 1);
               }
            }

            pose.popMatrix();
         }
      }

      private void slotBevel(GuiGraphicsExtractor g, int cx, int cy) {
         int a = this.bgAlpha();
         if (a > 0) {
            int shadow = Math.min(255, a + 40) << 24;
            int light = a * 2 / 3 << 24 | 16777215;
            g.fill(cx, cy, cx + 18, cy + 1, shadow);
            g.fill(cx, cy, cx + 1, cy + 18, shadow);
            g.fill(cx, cy + 18 - 1, cx + 18, cy + 18, light);
            g.fill(cx + 18 - 1, cy, cx + 18, cy + 18, light);
         }
      }
   }
}
