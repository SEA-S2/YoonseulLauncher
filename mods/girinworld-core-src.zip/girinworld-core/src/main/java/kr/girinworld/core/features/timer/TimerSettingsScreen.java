package kr.girinworld.core.features.timer;

import kr.girinworld.core.Config;
import kr.girinworld.core.features.CoreScreen;
import kr.girinworld.core.features.hud.HudLayoutScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class TimerSettingsScreen extends CoreScreen {
   private final Screen parent;
   private Button hudToggle;

   public TimerSettingsScreen(Screen parent) {
      super(Component.literal("타이머 설정"));
      this.parent = parent;
   }

   protected void init() {
      int w = 200;
      int left = this.width / 2 - w / 2;
      int y = this.height / 2 - 66;
      this.hudToggle = Button.builder(this.hudToggleLabel(), b -> this.toggleHud()).bounds(left, y, w, 20).build();
      this.addRenderableWidget(this.hudToggle);
      this.addRenderableWidget(new TimerSettingsScreen.OpacitySlider(left, y + 24, w, 20));
      this.addRenderableWidget(new TimerSettingsScreen.ScaleSlider(left, y + 48, w, 20));
      this.addRenderableWidget(
         Button.builder(Component.literal("위치 변경"), b -> kr.girinworld.core.ClientCompat.setScreen(Minecraft.getInstance(), new HudLayoutScreen(this))).bounds(left, y + 72, w, 20).build()
      );
      this.addRenderableWidget(Button.builder(Component.literal("초기화"), b -> this.resetTimerSettings()).bounds(left, y + 96, w, 20).build());
      this.addRenderableWidget(Button.builder(Component.literal("뒤로"), b -> this.onClose()).bounds(left, y + 120, w, 20).build());
   }

   private void resetTimerSettings() {
      Config c = Config.get();
      Config.Timer def = new Config.Timer();
      c.timer.recents.clear();
      c.timer.hudX = def.hudX;
      c.timer.hudY = def.hudY;
      c.timer.hudOpacity = def.hudOpacity;
      c.timer.hudScale = def.hudScale;
      c.save();
      kr.girinworld.core.ClientCompat.setScreen(Minecraft.getInstance(), new TimerSettingsScreen(this.parent));
   }

   private void toggleHud() {
      Config c = Config.get();
      c.timer.hudEnabled = !c.timer.hudEnabled;
      c.save();
      this.hudToggle.setMessage(this.hudToggleLabel());
   }

   private Component hudToggleLabel() {
      return Component.literal("HUD 표시: " + (Config.get().timer.hudEnabled ? "켜짐" : "꺼짐"));
   }

   public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
      super.extractRenderState(graphics, mouseX, mouseY, partialTick);
      Font f = this.font;
      String title = this.getTitle().getString();
      graphics.text(f, title, this.width / 2 - f.width(title) / 2, this.height / 2 - 78, -1);
   }

   public void onClose() {
      Config.get().save();
      kr.girinworld.core.ClientCompat.setScreen(Minecraft.getInstance(), this.parent);
   }

   private static final class OpacitySlider extends AbstractSliderButton {
      OpacitySlider(int x, int y, int w, int h) {
         super(x, y, w, h, Component.empty(), Math.max(0.0, Math.min(1.0, (Config.get().timer.hudOpacity - 0.1) / 0.9)));
         this.updateMessage();
      }

      private double opacity() {
         return 0.1 + this.value * 0.9;
      }

      protected void updateMessage() {
         this.setMessage(Component.literal("투명도: " + (int)Math.round(this.opacity() * 100.0) + "%"));
      }

      protected void applyValue() {
         Config.get().timer.hudOpacity = this.opacity();
      }
   }

   private static final class ScaleSlider extends AbstractSliderButton {
      ScaleSlider(int x, int y, int w, int h) {
         super(x, y, w, h, Component.empty(), Math.max(0.0, Math.min(1.0, (Config.get().timer.hudScale - 0.5) / 2.5)));
         this.updateMessage();
      }

      private double scale() {
         return 0.5 + this.value * 2.5;
      }

      protected void updateMessage() {
         this.setMessage(Component.literal("크기: " + (int)Math.round(this.scale() * 100.0) + "%"));
      }

      protected void applyValue() {
         Config.get().timer.hudScale = this.scale();
      }
   }
}
