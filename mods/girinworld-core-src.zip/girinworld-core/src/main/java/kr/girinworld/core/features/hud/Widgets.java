package kr.girinworld.core.features.hud;

import java.util.ArrayList;
import java.util.List;
import kr.girinworld.core.Config;
import kr.girinworld.core.CoreLog;
import kr.girinworld.core.HookProfiler;
import kr.girinworld.core.features.camera.PhotoModeController;
import kr.girinworld.core.features.timer.TimerHud;
import kr.girinworld.core.features.world.ItemBeamController;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public final class Widgets {
   private static final List<HudTarget> CUSTOM = List.of(new KeystrokesWidget(), new InventoryHud.Grid());
   private static List<HudTarget> all;

   private Widgets() {
   }

   public static List<HudTarget> all() {
      if (all == null) {
         List<HudTarget> t = new ArrayList<>();

         for (InfoElement e : InfoElement.values()) {
            t.add(new InfoTarget(e));
         }

         t.addAll(CUSTOM);
         t.add(new TimerTarget());
         all = List.copyOf(t);
      }

      return all;
   }

   public static void tick() {
      try {
         if (InfoElement.SYSTEM.cfg().enabled) {
            long a = HookProfiler.start();
            SystemStats.tick();
            HookProfiler.end("tick.system", a);
         }

         if (InfoElement.SPEED.cfg().enabled) {
            long a = HookProfiler.start();
            SpeedTracker.tick();
            HookProfiler.end("tick.speed", a);
         }

         if (InfoElement.HELD_COUNT.cfg().enabled) {
            long a = HookProfiler.start();
            HeldCountTracker.tick();
            HookProfiler.end("tick.heldCount", a);
         }

         long a = HookProfiler.start();
         ItemBeamController.tick();
         HookProfiler.end("tick.itemBeam", a);
      } catch (Throwable t) {
         CoreLog.error("widget tick failed", t);
      }
   }

   public static void renderAll(GuiGraphicsExtractor graphics) {
      if (PhotoModeController.isActive()) {
         if (Config.get().photo.hideHud) {
            return;
         }
      } else {
         Minecraft mc = Minecraft.getInstance();
         if (mc != null && mc.options != null && kr.girinworld.core.ClientCompat.hideGui(mc.options)) {
            return;
         }
      }

      render(graphics, "H3.timerHud", TimerHud::render);
      render(graphics, "H3.infoHud", InfoHud::render);
      render(graphics, "H3.custom", Widgets::renderCustom);
   }

   private static void renderCustom(GuiGraphicsExtractor graphics) {
      Minecraft mc = Minecraft.getInstance();
      if (mc != null && mc.player != null && mc.level != null && !(kr.girinworld.core.ClientCompat.screen(mc) instanceof HudLayoutScreen)) {
         int screenW = mc.getWindow().getGuiScaledWidth();
         int screenH = mc.getWindow().getGuiScaledHeight();

         for (HudTarget t : CUSTOM) {
            if (t.enabled() && t.visibleNow()) {
               long a = HookProfiler.start();

               try {
                  int[] size = t.size(mc.font);
                  t.draw(graphics, mc.font, HudUtil.anchorX(screenW, size[0], t.x()), HudUtil.anchorY(screenH, size[1], t.y()));
               } catch (Throwable th) {
                  CoreLog.error("widget render failed: " + t.moduleId(), th);
               } finally {
                  HookProfiler.end(t.moduleId(), a);
               }
            }
         }
      }
   }

   private static void render(GuiGraphicsExtractor graphics, String label, Widgets.Draw draw) {
      long t0 = HookProfiler.start();

      try {
         draw.run(graphics);
      } catch (Throwable t) {
         CoreLog.error(label + " render failed", t);
      } finally {
         HookProfiler.end(label, t0);
      }
   }

   private interface Draw {
      void run(GuiGraphicsExtractor var1);
   }
}
