package kr.girinworld.core.features.chat;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

final class ChatStamp {
   private static final DateTimeFormatter[] FORMATS = new DateTimeFormatter[]{
      DateTimeFormatter.ofPattern("HH:mm"), DateTimeFormatter.ofPattern("HH:mm:ss"), DateTimeFormatter.ofPattern("a h:mm")
   };
   private static final Pattern STAMP = Pattern.compile("^\\[(?:오전 |오후 |AM |PM )?\\d{1,2}:\\d{2}(?::\\d{2})?\\] ");

   private ChatStamp() {
   }

   static String prefix(int format) {
      return "[" + LocalTime.now().format(FORMATS[Math.max(0, Math.min(2, format))]) + "] ";
   }

   static String strip(String text) {
      return text == null ? null : STAMP.matcher(text).replaceFirst("");
   }
}
