package kr.girinworld.core.features.world;

final class BeamFilter {
   private static final String VANILLA = "minecraft:";

   private BeamFilter() {
   }

   static boolean matches(String filter, String id) {
      if (filter != null && !filter.isBlank() && id != null && !id.isEmpty()) {
         String full = id.toLowerCase();
         String shortId = full.startsWith("minecraft:") ? full.substring("minecraft:".length()) : full;

         for (String raw : filter.split(",")) {
            String s = raw.trim().toLowerCase();
            if (!s.isEmpty() && (s.equals(full) || s.equals(shortId))) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }
}
