package kr.girinworld.core.features.visual;

import java.time.LocalTime;
import kr.girinworld.core.Config;

public final class CustomTimeController {
   public static final int DAY = 24000;
   public static final String[] PRESET_NAMES = new String[]{"일출", "정오", "일몰", "자정"};
   public static final int[] PRESET_TICKS = new int[]{0, 6000, 12000, 18000};
   private static int timedDepth;
   private static int overrides;

   private CustomTimeController() {
   }

   private static Config.Time cfg() {
      return Config.get().time;
   }

   public static boolean enabled() {
      return cfg().enabled;
   }

   public static void beginTimedRender() {
      timedDepth++;
   }

   public static void endTimedRender() {
      if (timedDepth > 0) {
         timedDepth--;
      }
   }

   public static void clearFlag() {
      timedDepth = 0;
   }

   public static int overrideCount() {
      return overrides;
   }

   public static void resetOverrideCount() {
      overrides = 0;
   }

   public static long clockTime(long vanillaTotalTicks) {
      if (timedDepth > 0 && enabled()) {
         overrides++;
         long day = Math.floorDiv(vanillaTotalTicks, 24000);
         return day * 24000L + targetTimeOfDay();
      } else {
         return vanillaTotalTicks;
      }
   }

   public static int targetTimeOfDay() {
      Config.Time c = cfg();
      return c.mode == 1 ? realWorldTicks() : Math.floorMod(c.fixed, 24000);
   }

   static int realWorldTicks() {
      LocalTime now = LocalTime.now();
      int secondsOfDay = now.toSecondOfDay();
      long ticks = Math.round(secondsOfDay / 86400.0 * 24000.0);
      return (int)Math.floorMod(ticks - 6000L, 24000L);
   }

   public static void cyclePreset() {
      Config c = Config.get();
      if (!c.time.enabled) {
         c.time.enabled = true;
         c.time.mode = 0;
         c.time.fixed = PRESET_TICKS[0];
      } else {
         c.time.mode = 0;
         c.time.fixed = PRESET_TICKS[(presetIndex() + 1) % PRESET_TICKS.length];
      }

      c.save();
   }

   public static int presetIndex() {
      int t = Math.floorMod(cfg().fixed, 24000);

      for (int i = 0; i < PRESET_TICKS.length; i++) {
         if (PRESET_TICKS[i] == t) {
            return i;
         }
      }

      return -1;
   }

   public static String display() {
      int t = targetTimeOfDay();
      int hour = (int)((t / 1000L + 6L) % 24L);
      int minute = (int)(t % 1000L * 60L / 1000L);
      return String.format("%02d:%02d", hour, minute);
   }
}
