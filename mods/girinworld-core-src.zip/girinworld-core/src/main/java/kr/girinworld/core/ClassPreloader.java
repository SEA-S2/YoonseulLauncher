package kr.girinworld.core;

import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Enumeration;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

final class ClassPreloader {
   private static volatile boolean done = false;

   private ClassPreloader() {
   }

   static void ensurePreloaded() {
      if (!done) {
         done = true;

         try {
            ClassLoader loader = ClassPreloader.class.getClassLoader();
            URL loc = ClassPreloader.class.getProtectionDomain().getCodeSource().getLocation();
            if (loc == null) {
               return;
            }

            Path jar = Path.of(loc.toURI());
            if (!Files.isRegularFile(jar)) {
               return;
            }

            int ok = 0;
            int skipped = 0;

            try (JarFile jf = new JarFile(jar.toFile())) {
               Enumeration<JarEntry> entries = jf.entries();

               while (entries.hasMoreElements()) {
                  String name = entries.nextElement().getName();
                  if (name.startsWith("kr/girinworld/")
                     && name.endsWith(".class")
                     && !name.endsWith("module-info.class")
                     && !name.endsWith("package-info.class")) {
                     String className = name.substring(0, name.length() - 6).replace('/', '.');

                     try {
                        Class.forName(className, false, loader);
                        ok++;
                     } catch (Throwable t) {
                        skipped++;
                     }
                  }
               }
            }

            CoreLog.info("class preload complete: " + ok + " loaded, " + skipped + " skipped");
         } catch (Throwable t) {
            CoreLog.error("class preload failed (falling back to lazy loading)", t);
         }
      }
   }
}
