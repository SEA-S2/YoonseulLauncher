package kr.girinworld.core.features.hud;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import kr.girinworld.core.Config;
import kr.girinworld.core.CoreLog;
import kr.girinworld.core.HookProfiler;
import kr.girinworld.core.features.timer.TimerHud;
import kr.girinworld.core.features.timer.TimerManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.joml.Matrix3x2fStack;

public final class InfoHud {
   private static final int ICON = 16;
   private static final int ICON_GAP = 2;
   private static final int H_GAP = 6;
   private static final float ICON_TEXT_SCALE = 0.75F;
   private static final long CACHE_NANOS = 200000000L;
   private static final Map<InfoElement, InfoHud.Cached> CACHE = new EnumMap<>(InfoElement.class);
   private static final InfoElement[] ELEMENTS = InfoElement.values();
   private static final String[] PROFILE_LABELS = profileLabels();

   private static String[] profileLabels() {
      String[] out = new String[ELEMENTS.length];

      for (int i = 0; i < ELEMENTS.length; i++) {
         out[i] = "hud." + ELEMENTS[i].name();
      }

      return out;
   }

   private InfoHud() {
   }

   private static List<HudRow> cachedRows(InfoHud.Cached c, InfoElement e, Minecraft mc, long now) {
      if (c.rows == null || now - c.at >= 200000000L) {
         c.rows = e.rows(mc);
         c.at = now;
         c.size = null;
      }

      return c.rows;
   }

   private static int[] cachedSize(InfoHud.Cached c, Font font, float scale, boolean horiz) {
      if (c.size == null || c.sizeScale != scale || c.sizeHoriz != horiz) {
         c.size = contentSize(font, c.rows, scale, horiz);
         c.sizeScale = scale;
         c.sizeHoriz = horiz;
      }

      return c.size;
   }

   public static void render(GuiGraphicsExtractor graphics) {
      Minecraft mc = Minecraft.getInstance();
      if (mc != null && mc.player != null && mc.level != null) {
         if (!(kr.girinworld.core.ClientCompat.screen(mc) instanceof HudLayoutScreen)) {
            int screenW = mc.getWindow().getGuiScaledWidth();
            int screenH = mc.getWindow().getGuiScaledHeight();
            long now = System.nanoTime();

            for (InfoElement e : ELEMENTS) {
               Config.Hud.Elem cfg = e.cfg();
               if (cfg.enabled && (!e.inInventoryGroup() || !InventoryHud.hidden())) {
                  long t0 = HookProfiler.start();

                  try {
                     renderOne(graphics, mc, e, cfg, screenW, screenH, now);
                  } catch (Throwable t) {
                     CoreLog.error("info hud element failed: " + e.name(), t);
                  } finally {
                     HookProfiler.end(PROFILE_LABELS[e.ordinal()], t0);
                  }
               }
            }
         }
      }
   }

   private static void renderOne(GuiGraphicsExtractor graphics, Minecraft mc, InfoElement e, Config.Hud.Elem cfg, int screenW, int screenH, long now) {
      InfoHud.Cached c = CACHE.computeIfAbsent(e, k -> new InfoHud.Cached());
      List<HudRow> rows = cachedRows(c, e, mc, now);
      if (!rows.isEmpty()) {
         float scale = scaleOf(cfg);
         boolean horiz = e.horizontal();
         int[] size = cachedSize(c, mc.font, scale, horiz);
         int x = HudUtil.anchorX(screenW, size[0], cfg.x);
         int y = HudUtil.anchorY(screenH, size[1], cfg.y);
         HudUtil.background(graphics, cfg, x, y, size[0], size[1]);
         draw(graphics, mc.font, rows, x, y, scale, alphaOf(cfg), horiz);
      }
   }

   static List<HudRow> previewRows(InfoElement e, Minecraft mc) {
      if (!e.iconBased()) {
         return List.of(HudRow.of(e.label()));
      }

      List<HudRow> rows = mc != null && mc.player != null && mc.level != null ? e.rows(mc) : List.of();
      return rows.isEmpty() ? e.placeholderRows() : rows;
   }

   public static void autoPlace(InfoElement e) {
      Config.Hud.Elem cfg = e.cfg();
      cfg.x = 0.0;
      cfg.y = 0.0;
      Minecraft mc = Minecraft.getInstance();
      if (mc != null && mc.getWindow() != null) {
         Font font = mc.font;
         int screenH = mc.getWindow().getGuiScaledHeight();
         int bottom = -1;

         for (InfoElement other : ELEMENTS) {
            if (other != e) {
               Config.Hud.Elem oc = other.cfg();
               if (oc.enabled && !(oc.x > 0.25) && !(oc.y > 0.7)) {
                  int[] size = contentSize(font, previewRows(other, mc), scaleOf(oc), other.horizontal());
                  bottom = Math.max(bottom, HudUtil.anchorY(screenH, size[1], oc.y) + size[1]);
               }
            }
         }

         Config.Timer tc = Config.get().timer;
         if (tc.hudEnabled && tc.hudX <= 0.25 && tc.hudY <= 0.7 && !TimerManager.timers().isEmpty()) {
            int[] size = TimerHud.contentSize(font, TimerManager.timers(), TimerHud.effectiveScale());
            bottom = Math.max(bottom, HudUtil.anchorY(screenH, size[1], tc.hudY) + size[1]);
         }

         if (bottom >= 0) {
            int[] mySize = contentSize(font, previewRows(e, mc), scaleOf(cfg), e.horizontal());
            int span = HudUtil.span(screenH, mySize[1]);
            if (span > 0) {
               cfg.y = HudUtil.clamp01((double)(bottom + 4 - 6) / span);
            }
         }
      }
   }

   static float scaleOf(Config.Hud.Elem cfg) {
      return (float)HudUtil.clampScale(cfg.scale) * 0.8F;
   }

   static int alphaOf(Config.Hud.Elem cfg) {
      return (int)Math.round(HudUtil.clampOpacity(cfg.opacity) * 255.0);
   }

   private static int rowW(Font font, HudRow r) {
      return r.icon() != null ? 18 + Math.round(font.width(r.text()) * 0.75F) : font.width(r.text());
   }

   private static int rowH(Font font, HudRow r) {
      return r.icon() != null ? 16 : 9;
   }

   static int[] contentSize(Font font, List<HudRow> rows, float scale, boolean horizontal) {
      int w = 0;
      int h = 0;
      if (horizontal) {
         for (HudRow r : rows) {
            w += rowW(font, r);
            h = Math.max(h, rowH(font, r));
         }

         w += 6 * Math.max(0, rows.size() - 1);
      } else {
         for (HudRow r : rows) {
            w = Math.max(w, rowW(font, r));
            h += rowH(font, r);
         }
      }

      return new int[]{Math.round(w * scale), Math.round(h * scale)};
   }

   static void draw(GuiGraphicsExtractor graphics, Font font, List<HudRow> rows, int x, int y, float scale, int alpha, boolean horizontal) {
      Matrix3x2fStack pose = graphics.pose();
      pose.pushMatrix();
      pose.translate(x, y);
      if (scale != 1.0F) {
         pose.scale(scale);
      }

      int cx = 0;
      int cy = 0;

      for (HudRow r : rows) {
         drawRow(graphics, font, r, cx, cy, alpha << 24 | r.rgb() & 16777215, pose);
         if (horizontal) {
            cx += rowW(font, r) + 6;
         } else {
            cy += rowH(font, r);
         }
      }

      pose.popMatrix();
   }

   private static void drawRow(GuiGraphicsExtractor graphics, Font font, HudRow r, int cx, int cy, int argb, Matrix3x2fStack pose) {
      if (r.icon() == null) {
         graphics.text(font, r.text(), cx, cy, argb);
      } else {
         graphics.item(r.icon(), cx, cy);
         pose.pushMatrix();
         pose.translate(cx + 16 + 2, cy + (16.0F - 9.0F * 0.75F) / 2.0F);
         pose.scale(0.75F);
         graphics.text(font, r.text(), 0, 0, argb);
         pose.popMatrix();
      }
   }

   private static final class Cached {
      List<HudRow> rows;
      long at;
      int[] size;
      float sizeScale = -1.0F;
      boolean sizeHoriz;
   }
}
