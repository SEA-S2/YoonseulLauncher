package kr.girinworld.core.features.macro;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.InputConstants.Key;
import com.mojang.blaze3d.platform.InputConstants.Type;
import java.util.List;
import kr.girinworld.core.Config;
import kr.girinworld.core.CoreLog;
import kr.girinworld.core.KeyMods;
import net.minecraft.client.Minecraft;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.multiplayer.ClientPacketListener;

public final class MacroController {
   public static final int MAX = 30;
   public static final int MAX_LEN = 256;
   private static final long COOLDOWN_MS = 500L;
   private static long lastSend;

   private MacroController() {
   }

   public static List<Config.Macro.Entry> list() {
      return Config.get().macro.list;
   }

   public static boolean tryRun(KeyEvent event) {
      if (event == null) {
         return false;
      }

      for (Config.Macro.Entry e : list()) {
         if (matches(e, event)) {
            run(e);
            return true;
         }
      }

      return false;
   }

   private static boolean matches(Config.Macro.Entry e, KeyEvent event) {
      Key k = parse(e.key);
      return k != null && k.getType() == Type.KEYSYM && k.getValue() == event.key() && KeyMods.matches(e.mods, event.modifiers());
   }

   public static Key parse(String saved) {
      if (saved != null && !saved.isBlank()) {
         try {
            Key k = InputConstants.getKey(saved);
            return k != null && !k.equals(InputConstants.UNKNOWN) ? k : null;
         } catch (Throwable t) {
            return null;
         }
      } else {
         return null;
      }
   }

   public static boolean run(Config.Macro.Entry e) {
      return e != null && send(e.text);
   }

   public static boolean send(String raw) {
      String s = normalize(raw);
      if (!s.isEmpty() && !s.equals("/")) {
         Minecraft mc = Minecraft.getInstance();
         if (mc != null && mc.player != null) {
            ClientPacketListener conn = mc.player.connection;
            if (conn == null) {
               return false;
            }

            long now = System.currentTimeMillis();
            if (now - lastSend < 500L) {
               return false;
            }

            lastSend = now;

            try {
               if (s.charAt(0) == '/') {
                  conn.sendCommand(s.substring(1));
               } else {
                  conn.sendChat(s);
               }

               return true;
            } catch (Throwable t) {
               CoreLog.error("macro send failed", t);
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   static String normalize(String raw) {
      if (raw == null) {
         return "";
      }

      StringBuilder sb = new StringBuilder(raw.length());
      boolean space = false;

      for (int i = 0; i < raw.length(); i++) {
         char c = raw.charAt(i);
         if (Character.isWhitespace(c)) {
            space = !sb.isEmpty();
         } else if (c != 167 && c >= ' ' && c != 127) {
            if (space) {
               sb.append(' ');
               space = false;
            }

            sb.append(c);
         }
      }

      if (sb.length() <= 256) {
         return sb.toString();
      }

      int cut = Character.isHighSurrogate(sb.charAt(255)) ? 255 : 256;
      return sb.substring(0, cut);
   }
}
