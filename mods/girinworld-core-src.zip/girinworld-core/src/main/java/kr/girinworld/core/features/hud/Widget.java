package kr.girinworld.core.features.hud;

import kr.girinworld.core.Config;

public abstract class Widget implements HudTarget {
   protected abstract Config.Hud.Elem cfg(Config.Hud var1);

   protected Config.Hud.Elem cfg() {
      return this.cfg(Config.get().hud);
   }

   @Override
   public boolean enabled() {
      return this.cfg().enabled;
   }

   @Override
   public void setEnabled(boolean on) {
      this.cfg().enabled = on;
   }

   @Override
   public double x() {
      return this.cfg().x;
   }

   @Override
   public double y() {
      return this.cfg().y;
   }

   @Override
   public void setPos(double x, double y) {
      Config.Hud.Elem c = this.cfg();
      c.x = x;
      c.y = y;
   }

   @Override
   public double scale() {
      return this.cfg().scale;
   }

   @Override
   public void setScale(double scale) {
      this.cfg().scale = HudUtil.clampScale(scale);
   }

   @Override
   public void resetLayout() {
      Config.Hud.Elem def = this.cfg(new Config.Hud());
      Config.Hud.Elem c = this.cfg();
      c.x = def.x;
      c.y = def.y;
      c.scale = def.scale;
      c.opacity = def.opacity;
   }

   protected float drawScale() {
      return (float)HudUtil.clampScale(this.cfg().scale) * 0.8F;
   }

   protected int alpha() {
      return (int)Math.round(HudUtil.clampOpacity(this.cfg().opacity) * 255.0);
   }

   protected int bgAlpha() {
      Config.Hud.Elem c = this.cfg();
      return !c.bgEnabled ? 0 : (int)Math.round(Math.max(0.0, Math.min(1.0, c.bgOpacity)) * 255.0);
   }
}
